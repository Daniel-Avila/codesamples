from django.conf.urls import patterns, url
from views.zone_views import CreateZone
from views.zone_views import EditZone
from views.zone_management_views import ZoneManagement
from views.whitelist_view import AdvertiserWhitelist


urlpatterns = patterns('',
                       url('^new', CreateZone.as_view()),
                       url('^edit', EditZone.as_view()),
                       url('^whitelist', AdvertiserWhitelist.as_view()),
                       url('^manage', ZoneManagement.as_view())

                       )
