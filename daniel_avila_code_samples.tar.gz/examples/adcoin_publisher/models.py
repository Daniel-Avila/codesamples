from django.db import models
from django.conf import settings
from adcoin_user.models import AdcoinUser
import datetime


class Zone(models.Model):

    class Meta:
        app_label = 'adcoin_publisher'

    FORMATS = (
        ('1x1', '1x1'),
        ('2x1', '2x1'),
        ('3x1', '3x1'),
    )
    CATEGORIES = (
        ('code1', 'Spam'),
        ('code2', 'Hovercraft'),
        ('code3', 'Eels'),
        ('code4', 'Knights who say "Ni"'),
        ('code5', 'Completely Different'),
    )
    STATE = (
        ('active', 'Active'),
        ('inactive', 'Inactive'),
    )

    name = models.CharField(max_length=256)
    zone_format = models.CharField(max_length=9,
                                   choices=FORMATS,
                                   default=FORMATS[0])
    border_color = models.CharField(max_length=6)
    text_color = models.CharField(max_length=6)
    font = models.CharField(max_length=256)
    category = models.CharField(max_length=5,
                                choices=CATEGORIES,
                                default=CATEGORIES[0])
    tags = models.CharField(max_length=256)
    location = models.CharField(max_length=256)
    gender = models.CharField(max_length=1)
    min_age = models.IntegerField()
    max_age = models.IntegerField()
    reward_url = models.URLField()
    min_cpe = models.FloatField()
    owner = models.ForeignKey(settings.AUTH_USER_MODEL)
    status = models.CharField(max_length=9,
                              choices=STATE,
                              default=STATE[0])
    summary = models.CharField(max_length=1024)
    last_edit = models.DateTimeField(default=datetime.date.today)


class WhitelistEntry(models.Model):

    advertiser = models.ForeignKey(AdcoinUser)
    zone = models.ForeignKey(Zone)
