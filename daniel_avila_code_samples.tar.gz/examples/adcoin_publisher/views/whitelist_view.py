from django.views.generic import View
from django.shortcuts import render_to_response, redirect
from adcoin_user.models import AdcoinUser
from adcoin_publisher.models import Zone
from adcoin_common.mixins import ViewUtils
from adcoin_publisher.models import WhitelistEntry


class AdvertiserWhitelist(View, ViewUtils):

    def get(self, request):

        display_name = self.get_display_name(request.user)
        user_id = request.user.id
        user = AdcoinUser.objects.get(pk=user_id)
        zones = self.get_zones_by_user(user)
        result = []
        for zone in zones:
            name = zone['fields']['name']
            zone_format = zone['fields']['zone_format']
            whitelist = WhitelistEntry.objects.filter(zone=Zone.objects.get(pk=zone['pk']))
            zone_id = zone['pk']
            result.append([name, zone_format, whitelist, zone_id])
            return render_to_response('adcoin_publisher/whitelist.html',
                                      {'data': result,
                                       'display_name': display_name})

    def post(self, request):

        zone_id = request.POST.get('zone_id', None)
        advertiser_id = request.POST.get('advertiser_id', None)
        zone = Zone.objects.get(pk=zone_id)
        advertiser = AdcoinUser.objects.get(pk=advertiser_id)

        WhitelistEntry.objects.get_or_create(zone=zone, advertiser=advertiser)
        return redirect('/whitelist')
