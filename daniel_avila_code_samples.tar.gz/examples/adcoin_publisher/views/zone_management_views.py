from django.views.generic import View
from django.core.paginator import Paginator, EmptyPage, PageNotAnInteger
from django.shortcuts import render_to_response
from django.template import RequestContext
from adcoin_common.mixins import ViewUtils
from adcoin_publisher.models import Zone


class ZoneManagement(View, ViewUtils):

    def get(self, request):

        display_name = self.get_display_name(request.user)
        zone_list = self.get_zones_by_user(request.user)
        zone_final = []
        for zone in zone_list:
            zone_final.append(zone['fields']['name'],
                              zone['pk'],
                              zone['fields']['summary'],
                              zone['fields']['last_edited'],
                              zone['fields']['status'][0])

        paginator = Paginator(zone_final, 25)
        page = request.GET.get('page')

        try:
            zone_page = paginator.page(page)
        except PageNotAnInteger:
                # If page is not an integer, deliver first page.
            zone_page = paginator.page(1)
        except EmptyPage:
                # If page is out of range (e.g. 9999), deliver
                # last page of results.
            zone_page = paginator.page(paginator.num_pages)
        context = RequestContext(request)
        return render_to_response("adcoin_publisher/zone_list.html",
                                  {"zone_list": zone_page,
                                   "display_name": display_name},
                                  context)

    def dup_zone(self, zone_id):
        zon = Zone.objects.get_queryset().filter(id=zone_id)
        zone = zon[0]
        self.new_zone = Zone()
        self.new_zone.name = zone.name
        self.new_zone.zone_format = zone.zone_format
        self.new_zone.border_color = zone.border_color
        self.new_zone.text_color = zone.text_color
        self.new_zone.font = zone.font
        self.new_zone.category = zone.category
        self.new_zone.tags = zone.tags
        self.new_zone.location = zone.location
        self.new_zone.gender = zone.gender
        self.new_zone.min_age = zone.min_age
        self.new_zone.max_age = zone.max_age
        self.new_zone.reward_url = zone.reward_url
        self.new_zone.min_cpe = zone.min_cpe
        self.new_zone.owner = zone.owner
        self.new_zone.status = zone.status
        self.new_zone.summary = zone.summary
        self.new_zone.last_edit = zone.last_edit
        return self.new_zone
