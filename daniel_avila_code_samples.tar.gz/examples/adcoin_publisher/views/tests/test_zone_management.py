from django import test
from adcoin_user.models import AdcoinUser
from model_mommy import mommy
from adcoin_publisher.views.zone_management_views import ZoneManagement
from adcoin_publisher.models import Zone


class TestZoneManagement(test.TestCase):

    def test_get_zones_for_user(self):
        """Can we get all of the zones for only a specific user?"""

        user1 = AdcoinUser(email='bob@test.com', password="asdf",
                           account_type='publisher')
        user2 = AdcoinUser(email='boba@test.com', password="asdf",
                           account_type='publisher')
        user1.save()
        user2.save()
        zone1 = mommy.make(Zone, name="one",summary="summary",owner=user1)
        zone2 = mommy.make(Zone, owner=user2)
        zone3 = mommy.make(Zone, name="three",summary="summary",owner=user1)
        zone1.save()
        zone2.save()
        zone3.save()

        # code under test
        zm = ZoneManagement()

        zones = zm.get_zones_by_user(user1)
        # test results

        self.assertEqual(len(zones), 2)
        self.assertEqual(zones[0]['fields']['name'], "one")

    def test_dup_zone(self):
        """Can we deuplicate a zone?"""


        user1 = AdcoinUser(email='bob@test.com', password="asdf",
                           account_type='publisher')
        user1.save()
        zone1 = mommy.make(Zone, name="one",summary="summary",owner=user1)
        zm = ZoneManagement()

        # code under test
        zone = zm.dup_zone(zone1.id)

        self.assertEqual(zone1.summary, zone.summary)
