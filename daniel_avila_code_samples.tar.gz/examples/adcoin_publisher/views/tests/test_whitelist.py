from django.test import TestCase, RequestFactory, Client
from model_mommy import mommy
from adcoin_user.models import AdcoinUser
from adcoin_publisher.models import Zone
from adcoin_publisher.views.whitelist_view import AdvertiserWhitelist
from adcoin_publisher.models import WhitelistEntry

class TestAdvertiserWhitelist(TestCase):

    def setUp(self):
        self.factory = RequestFactory()
        self.user = AdcoinUser.objects.create_user('bob fullname',
                                                   'bob@bob.com',
                                                   'publisher',
                                                   password='pass')
        for i in range(5):
            mommy.make(Zone, owner=self.user)

        self.advertiser = AdcoinUser.objects.create_user('bob fullname',
                                                   'bob@notbob.com',
                                                   'advertiser',
                                                   password='pass')
    def test_get(self):
        """can we render the whitelist page?"""
        request = self.factory.get('/publisher/whitelist')
        request.user = self.user
        wlv = AdvertiserWhitelist()
        result = wlv.get(request)
        self.assertEquals(result.status_code, 200)

    def test_template(self):
        client = Client()
        result = client.login(email=self.user.email, password='pass')
        self.assertTrue(result)
        response = client.get('/publisher/whitelist')
        expected = "<td>1 this is where the form goes</td>"
        self.assertInHTML(expected, response.content, count=1)

    def test_post(self):
        zone_id = Zone.objects.all()[0].pk
        advertiser_id = self.advertiser.pk
        request = self.factory.post('/publisher/whitelist', {'zone_id': zone_id, 'advertiser_id': advertiser_id})
        request.user = self.user
        wlv = AdvertiserWhitelist()
        result = wlv.post(request)

        zone = Zone.objects.all()[0]
        result = WhitelistEntry.objects.filter(zone=zone, advertiser=self.advertiser)
        self.assertEquals(len(result), 1)
        result = wlv.post(request)
        zone = Zone.objects.all()[0]
        result = WhitelistEntry.objects.filter(zone=zone, advertiser=self.advertiser)
        self.assertEquals(len(result), 1)


#    def test_add_to_whitelist(self):
#        """Code we are testing"""
#        self.aw.add_to_whitelist(1, 2)
#
#        """assertions"""
#        self.assertEqual(self.aw.approved_advertisers[0], (1, 2))
#
#    def test_get_approved_by_zone(self):
#
#        self.aw.add_to_whitelist(1, 1)
#        self.aw.add_to_whitelist(2, 2)
#        self.aw.add_to_whitelist(1, 3)
#        self.aw.add_to_whitelist(2, 4)
#        self.aw.add_to_whitelist(1, 5)
#        """Code we are testing"""
#        self.aw.get_approved_by_zone(1)
#        """assertions"""
#        self.assertEqual(len(self.aw.current_advertisers), 3)
