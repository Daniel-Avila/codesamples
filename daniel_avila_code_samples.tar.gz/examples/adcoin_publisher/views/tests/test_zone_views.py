from django import test
from django.test import Client
from model_mommy import mommy
from adcoin_user.models import AdcoinUser
from adcoin_publisher.views.zone_views import EditZone
from adcoin_publisher.models import Zone


class TestZoneEdit(test.TestCase):

    def test_zone_edit(self):
        """Can we edit and existing zone?"""

        user1 = AdcoinUser.objects.create_user('full name', 'bob@test.com',
                                               'publisher',
                                               password="asdf")
        user1.save()
        zone1 = mommy.make(Zone, name="one", summary="summary", owner=user1)
        zone1.save()

        client = Client()
        result = client.login(email=user1.email, password='asdf')
        self.assertTrue(result)
        # code under test
        response = client.get('/adcoin/edit/', {'zone_id': zone1.id})

        # test results
