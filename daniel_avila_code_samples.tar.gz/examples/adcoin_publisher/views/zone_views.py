from django.views.generic.edit import CreateView, UpdateView
from django.shortcuts import render_to_response, redirect
from django.contrib.auth import get_user_model
from django.template import RequestContext
from adcoin_publisher.models import Zone
from adcoin_publisher.forms.zoneforms import ZoneForm


class AuthMixin(object):

    def is_valid_publisher(self, request):
        if not request.user.is_authenticated():
            return False
        if not request.user.is_publisher:
            return False
        return True

    def make_zone(self, request):
        um = get_user_model()
        user = um.objects.get(pk=request.POST['owner'])
        zone = Zone(owner=user,
                    name=request.POST.get('name', None),
                    zone_format=request.POST.get('zone_format', None),
                    border_color=request.POST.get('border_color', None),
                    text_color=request.POST.get('text_color', None),
                    font=request.POST.get('font', None),
                    category=request.POST.get('category', None),
                    tags=request.POST.get('tags', None),
                    location=request.POST.get('location', None),
                    gender=request.POST.get('gender', None),
                    min_age=request.POST.get('min_age', None),
                    max_age=request.POST.get('max_age', None),
                    reward_url=request.POST.get('reward_url', None),
                    min_cpe=request.POST.get('min_cpe', None))
        zone.save()


class CreateZone(AuthMixin, CreateView):

    model = Zone
    fields = ['name', 'zone_format', 'border_color', 'text_color', 'font',
              'category', 'tags', 'location', 'gender', 'min_age', 'max_age',
              'reward_url', 'min_cpe']

    def get(self, request):

        if not self.is_valid_publisher(request):
            return redirect("/login/")

        form = ZoneForm()
        context = RequestContext(request)
        owner_id = request.user.id
        return render_to_response("adcoin_publisher/zone_form.html",
                                  {"form": form, 'owner_id': owner_id},
                                  context)

        form = ZoneForm()
        context = RequestContext(request)
        return render_to_response("adcoin_publisher/zone_form.html",
                                  {"form": form},
                                  context)

    def post(self, request):

        if not self.is_valid_publisher(request):
            return redirect("/login/")
        self.make_zone(request)
        return redirect('adcoin/zone_management/')


class EditZone(AuthMixin, UpdateView):
    model = Zone
    fields = ['name', 'zone_format', 'border_color', 'text_color', 'font',
              'category', 'tags', 'location', 'gender', 'min_age', 'max_age',
              'reward_url', 'min_cpe']

    def get(self, request):

        if not self.is_valid_publisher(request):
            return redirect("/login/")

        zone_id = request.GET.get('zone_id', None)
        owner_id = request.user.id
        zone_inst = Zone.objects.get(pk=zone_id)
        form = ZoneForm(instance=zone_inst)
        context = RequestContext(request)
        return render_to_response("adcoin_publisher/zone_form.html",
                                  {"form": form, 'owner_id': owner_id,
                                   'zone_id': zone_id},
                                  context)

    def post(self, request):

        if not self.is_valid_publisher(request):
            return redirect("/login/")
        self.update_zone(request)
        return redirect('adcoin/zone_management/')
