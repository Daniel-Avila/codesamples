from django.forms import ModelForm
from adcoin_publisher.models import Zone


class ZoneForm(ModelForm):
    class Meta:
        model = Zone
        fields = ['name', 'zone_format', 'border_color', 'text_color', 'font',
                  'category', 'tags', 'location', 'gender', 'min_age',
                  'max_age', 'reward_url', 'min_cpe']
