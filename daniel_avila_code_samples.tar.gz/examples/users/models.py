"""User Models for NowU"""

from __future__ import absolute_import, division

import datetime
import logging
import uuid

from django.conf import settings
from django.contrib.auth.models import (AbstractBaseUser, AnonymousUser, BaseUserManager,
                                        Group, PermissionsMixin)
from django.contrib.sessions.backends.db import SessionStore
from django.db import models
from django.utils import timezone
from social.apps.django_app.default.models import UserSocialAuth


from boomers.apps.paywall.billing.models import OnlinePayments, AmazonPaymentInfo
from boomers.apps.paywall.metering.models import MeteringGroup

import logging

import uuid

from boomers.apps.paywall.billing.models import OnlinePayments
from boomers.apps.config import models as config_models
from boomers.apps.users import firefly
from guardian.shortcuts import assign_perm

logger = logging.getLogger('boomers')


class NowUUserManager(BaseUserManager):

    def get(self, *args, **kwargs):
        if 'username' in kwargs:
            kwargs['email'] = kwargs['username']
            del kwargs['username']
        return super(NowUUserManager, self).get(*args, **kwargs)

    def create(self, **kwargs):
        if 'username' in kwargs:
            kwargs['email'] = kwargs['username']
            del kwargs['username']
        return super(NowUUserManager, self).create(**kwargs)

    def get_or_create(self, **kwargs):
        if 'username' in kwargs:
            kwargs['email'] = kwargs['username']
            del kwargs['username']
        return super(NowUUserManager, self).get_or_create(**kwargs)

    def create_user_in_atypon(self, email, **kwargs):
        json_data = firefly.create_user(email, **kwargs)

        # does the user already exist in atypon?
        if firefly.get_response_status(json_data) == firefly.EMAIL_ALREADY_EXISTS:
            json_data = firefly.get_user(email=email)
            if firefly.is_successful_response(json_data):
                return json_data['response']
            else:
                logger.warning('error retrieving user %s from atypon' % email)
                return

        # did the request fail for some other reason?
        if not firefly.is_successful_response(json_data):
            logger.warning('error creating user %s in atypon' % email)
            return

        return json_data['response']['user']

    def create_user(self, email, password=None, commit=True, **kwargs):
        user = self.model(email=self.normalize_email(email))
        atypon_user_data = {}

        if 'backend' in kwargs and kwargs['backend'].name == 'facebook':
            atypon_user_data = self.create_user_in_atypon(
                user.email,
                firstName=kwargs.get('first_name', ''),
                lastName=kwargs.get('last_name', ''),
                credentialType='Facebook',
                socialProvider='Facebook',
                accessToken=kwargs['request'].session['fb_access_token'])
        else:
            atypon_user_data = self.create_user_in_atypon(user.email, password=password)

        if atypon_user_data:
            user.atypon_user_id = atypon_user_data['userId']
            user.verification_code = uuid.uuid4().get_hex()
            user.is_active = True
            if commit:
                user.save()
            return user

        else:
            logger.warning('account %s could not be linked with atypon' % email)

        return

    def create_superuser(self, email, password):
        user = self.model(email=self.normalize_email(email))
        atypon_user_data = self.create_user_in_atypon(user.email,
                                                      password=password,
                                                      firstName='NowU',
                                                      lastName='User')

        if atypon_user_data:
            user.atypon_user_id = atypon_user_data['userId']
            user.is_admin = True
            user.is_staff = True
            user.is_superuser = True
            user.is_active = True
            user.is_verified = True
            user.is_csr = True
            user.verification_code = uuid.uuid4().get_hex()
            user.save()
            return user

        else:
            logger.warning('account %s could not be linked with atypon' % user.email)

        return

class NowUAnonymousUser(AnonymousUser):

    metering_group = None

    def __init__(self, metering_group_id=None):
        super(NowUAnonymousUser, self).__init__()
        if metering_group_id:
            try:
                self.metering_group = MeteringGroup.objects.get(
                    id=int(metering_group_id))
            except MeteringGroup.DoesNotExist:
                try:
                    self.metering_group = MeteringGroup.objects.get(
                        default=True)
                except MeteringGroup.DoesNotExist:
                    self.metering_group = None


class NowUUser(AbstractBaseUser, PermissionsMixin):
    """This is the user class where the glorious functionality will be"""

    #Boomers fields
    email = models.EmailField(
            verbose_name='Email Address',
            max_length=255,
            unique=True)
    verification_code = models.CharField(max_length=32, default='')
    signup_time = models.DateTimeField(auto_now_add=True)
    profile_pic = models.ImageField(upload_to='profile_pics/', max_length=255, null=True, blank=True)
    email_pref = models.BooleanField(default=True)
    newsletter_pref = models.BooleanField(default=True)
    login_method = models.CharField(max_length=255, default='nowu')
    atypon_user_id = models.IntegerField(default=-1)
    is_verified = models.BooleanField(default=False)
    payment_paypal = models.ForeignKey(OnlinePayments, null=True, blank=True)
    payment_amazon = models.ForeignKey(AmazonPaymentInfo, null=True, blank=True)
    metering_group = models.ForeignKey(MeteringGroup, null=True, blank=True)
    #end Boomers fields

    is_csr = models.BooleanField(default=False)
    #required by Django
    is_admin = models.BooleanField(default=False)
    is_staff = models.BooleanField(default=False)
    is_active = models.BooleanField(default=False)
    USERNAME_FIELD = 'email'
    objects = NowUUserManager()
    #End required by Django

    class Meta:
        verbose_name = 'NowU User'
        verbose_name_plural = 'NowU Users'

    def get_short_name(self):
        return self.email

    @property
    def first_name(self):
        # TODO
        return ''

    @property
    def last_name(self):
        # TODO
        return ''

    @property
    def full_name(self):
        # TODO
        return ' '.join(filter(None, [self.first_name, self.last_name]))

    @property
    def has_active_subscription(self):
        # TBD
        return False

    @property
    def has_paid(self):
        """ looks at PayPal, Amazon, and Chase payment objects then determines which is highest.
        Then evaluates whether to return whether the payment is still valid """
        top_status = 'Unpaid'
        # *ORDERED* payment statuses - lowest first
        pm = ['Unpaid','Pending','Paid_initial','Paid_recurring']
        # if neither payment object exists, return False right away
        if not self.payment_paypal and not self.payment_amazon:
            return False
        # check paypal status first, then amazon
        if self.payment_paypal:
            top_status = self.payment_paypal.payment_status
            greater_pmt = self.payment_paypal
        if self.payment_amazon:
            am_status = self.payment_amazon.payment_status
            if pm.index(am_status) > pm.index(top_status):
                top_status = am_status
                greater_pmt = self.payment_amazon
        # TODO: put something here for chase

        # handle different payment statuses
        if top_status == 'Pending':
            if greater_pmt.last_updated_time < timezone.now()-datetime.timedelta(days=30): # Pending statuses are held for 30 days
                return False
            else:
                return True
        elif top_status == 'Paid_once':
            if greater_pmt.last_updated_time < timezone.now()-datetime.timedelta(days=365):
                return False
            else:
                return True
        elif top_status == 'Paid_recurring':
            return True
        # return False for 'Unpaid'
        return False

    def save(self, *args, **kwargs):
        super(NowUUser, self).save(*args, **kwargs)
        if getattr(self, 'is_csr', True):
            assign_perm('users.change_nowuuser',self, None)


    @property
    def get_social_users(self):
        social_public_names = {
            'google-oauth2': 'Google',
            'facebook': 'Facebook',
            'twitter': 'Twitter',
        }
        try:
            linked_social_profiles = ' & '.join([social_public_names[x.provider] for x in UserSocialAuth.objects.filter(user=self)])
        except:
            linked_social_profiles = None
        return linked_social_profiles

    @property
    def profile_pic_url(self):
        return ''


class ActionLogger(models.Model):
    """Keeps track of user logins, password reset requests, confirmation email requests, etc"""

    ip_address = models.IPAddressField(default='', null=True)
    timestamp = models.DateTimeField(auto_now_add=True)
    action_short = models.CharField(max_length=255, default='')
    attempted_user_email = models.CharField(max_length=255, default='')
    user = models.ForeignKey(NowUUser, null=True)

    def __str__(self):
        return self.action_short
