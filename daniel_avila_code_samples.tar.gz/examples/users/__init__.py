from .models import NowUUser

def guardian_init(User):
    user = NowUUser.objects.create_user(email='anon@nowu.com',
                                        password='bx0rTbX35a',
                                        commit=False)
    return user
