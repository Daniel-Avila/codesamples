from django.conf import settings
from rest_framework import serializers

from boomers.apps.users import firefly
from boomers.apps.users.models import NowUUser


class UserSerializer(serializers.ModelSerializer):
    licenses = serializers.SerializerMethodField('get_licenses')

    class Meta:
        model = NowUUser
        fields = ('id', 'atypon_user_id', 'email', 'licenses',)

    def get_licenses(self, obj):
        json_data = firefly.get_user(email=obj.email)

        if firefly.is_successful_response(json_data):
            license_data = json_data['response']['licenses']
            if license_data:
                return [{
                    'description': license_data[0]['description'],
                }]

        return []
