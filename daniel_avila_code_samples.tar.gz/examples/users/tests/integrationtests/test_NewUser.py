"""A test case class for the new user view"""
import mock
from django.http import HttpResponse
from django.test import TestCase
from django.test.client import Client, RequestFactory
from model_mommy import mommy
from social.apps.django_app.default.models import UserSocialAuth

from boomers.apps.users.forms import NewUserForm
from boomers.apps.users.models import NowUUser
from boomers.apps.users.views.NewUser import NewUser


class TestNewUserForm(TestCase):
    """Some tests for our form"""

    def test_is_valid(self):
        """Our form should be all happy if the the values are all valid"""

        #Normally we don't write a test for this but is_valid is overridden

        data = {'email':'test@test.com', 'password':'pass', 'password2':'pass'}
        f = NewUserForm.NewUserForm(data)
        self.assertTrue(f.is_valid())
        self.assertFalse(f.errors)


    def test_barfs_bad_email(self):
        """Our form should complain if we get a bad email"""

        #Normally we don't write a test for this but is_valid is overridden

        data = {'email':'not a valid email', 'password':'pass', 'password2':'pass'}
        f = NewUserForm.NewUserForm(data)
        self.assertFalse(f.is_valid())
        self.assertEqual(u'Enter a valid email address.', f.errors['email'][0])

    def test_barfs_passwords_mismatch(self):
        """Cry if the passwords don't match"""
        data = {'email':'sparky@test.com', 'password':'one', 'password2':'pass'}
        f = NewUserForm.NewUserForm(data)
        self.assertFalse(f.is_valid())

    @mock.patch('boomers.apps.users.forms.NewUserForm.send_verification_email')
    def test__send_verification_email(self, mock_mailer):
        """Do we send a verification email with the proper message?"""
        expected = 'Please check your email for your verification code.'
        mock_mailer.return_value = 'success'
        data = {'email':'sparky.mockingbird@gmail.com', 'password':'pass', 'password2':'pass'}
        f = NewUserForm.NewUserForm(data)
        user = mommy.make(NowUUser, email=data['email'])
        f.is_valid()
        #Code under test
        result = f._send_verification_email(user)
        #Check our result
        self.assertEqual(result.content, expected)

    def test__check_social_logins(self):
        """Do we get back the right stuff for a social login existing
        if we try to create a user that exists via social login?"""
        expected = {'error_msg': u'There is already an account created for email address: sparky.mockingbird@gmail.com',
                   'email': u'sparky.mockingbird@gmail.com'}
        data = {'email':'sparky.mockingbird@gmail.com', 'password':'pass', 'password2':'pass'}
        f = NewUserForm.NewUserForm(data)
        mommy.make(NowUUser, email=data['email'])
        f.is_valid() #sets up the form all nice n seech.

        #Code under test
        result = f._check_social_logins()
        #Do we do what we think?

        self.assertEqual(expected, result)

    def test_check_social_twitter(self):
        """We are signed up via twitter do we get the right answer?"""

        expected = {
                'error_msg': 'You already have an account that you created through Twitter. Please use that/those to log in.',
                'email': u'sparky.mockingbird@gmail.com'}
        data = {'email':'sparky.mockingbird@gmail.com', 'password':'pass', 'password2':'pass'}
        user = mommy.make(NowUUser, email=data['email'])
        mommy.make(UserSocialAuth, user=user, provider='twitter')
        f = NewUserForm.NewUserForm(data)
        f.is_valid() #sets up the form all nice n seech.

        #Code under test
        result = f._check_social_logins()

        self.assertEqual(result, expected)


    def test_check_social_facebook(self):
        """We are signed up via facebook do we get the right answer?"""

        expected = {
                'error_msg': 'You already have an account that you created through Facebook. Please use that/those to log in.',
                'email': u'sparky.mockingbird@gmail.com'}
        data = {'email':'sparky.mockingbird@gmail.com', 'password':'pass', 'password2':'pass'}
        user = mommy.make(NowUUser, email=data['email'])
        mommy.make(UserSocialAuth, user=user, provider='facebook')
        f = NewUserForm.NewUserForm(data)
        f.is_valid() #sets up the form all nice n seech.

        #Code under test
        result = f._check_social_logins()

        self.assertEqual(result, expected)

    def test_check_social_google(self):
        """We are signed up via google do we get the right answer?"""

        expected = {
                'error_msg': 'You already have an account that you created through Google. Please use that/those to log in.',
                'email': u'sparky.mockingbird@gmail.com'}
        data = {'email':'sparky.mockingbird@gmail.com', 'password':'pass', 'password2':'pass'}
        user = mommy.make(NowUUser, email=data['email'])
        mommy.make(UserSocialAuth, user=user, provider='google-oauth2')
        f = NewUserForm.NewUserForm(data)
        f.is_valid() #sets up the form all nice n seech.

        #Code under test
        result = f._check_social_logins()

        self.assertEqual(result, expected)

    @mock.patch('boomers.apps.users.forms.NewUserForm.send_verification_email')
    def test_save_user(self, mock_mailer):
        """Straight up make up and save up a user no social auth issues"""

        expected_content = 'Please check your email for your verification code.'
        mock_mailer.return_value = 'success'
        data = {'email':'sparky.mockingbird@gmail.com', 'password':'passw0rd', 'password2':'passw0rd'}
        f = NewUserForm.NewUserForm(data)
        f.is_valid() #sets up the form all nice n seech.

        #Code under test
        result = f.save_user()
        try:
            NowUUser.objects.get(email='sparky.mockingbird@gmail.com')
        except NowUUser.DoesNotExist:
            self.fail("User not created as expected")
