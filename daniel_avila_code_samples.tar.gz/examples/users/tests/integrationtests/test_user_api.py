import uuid

from django.test import TestCase

from boomers.apps.users import firefly


class UserApiTestCase(TestCase):
    def setUp(self):
        # TODO: create matt.caldwell@gmail.com user if not already there
        self.user1 = 'nowu@merp.com'
        firefly.create_user(email=self.user1, password='test123')

    def tearDown(self):
        # TODO: delete matt.caldwell@gmail.com user?
        pass

    def test_create_user(self):
        """ Tests the successful creation of a user."""
        json_data = firefly.create_user(
            email='matt.caldwell+nowu-test-%s@gmail.com' % uuid.uuid4().hex,
            password='test123')
        self.assertTrue(firefly.is_successful_response(json_data))

    def test_create_user_invalid_email(self):
        """ Tests that a user cannot register with a malformed email."""
        json_data = firefly.create_user(email='merp', password='test123')
        self.assertFalse(firefly.is_successful_response(json_data))

    def test_create_user_no_email(self):
        """ Tests that a user cannot register without entering an email."""
        json_data = firefly.create_user(email='', password='test123')
        self.assertFalse(firefly.is_successful_response(json_data))

    def test_create_user_no_password(self):
        """ Tests that a user cannot register without entering a password."""
        json_data = firefly.create_user('matt.caldwell@gmail.com')
        self.assertFalse(firefly.is_successful_response(json_data))

    def test_login(self):
        """ Tests that a user can log in with valid credentials."""
        json_data = firefly.login(self.user1, 'test123')
        self.assertTrue(firefly.is_successful_response(json_data))

    def test_login_bad_email(self):
        """ Tests that a user can not log in with invalid email."""
        json_data = firefly.login('not.my@email.com', 'test123')
        self.assertFalse(firefly.is_successful_response(json_data))

    def test_login_bad_password(self):
        """ Tests that a user can not log in with invalid password."""
        json_data = firefly.login('matt.caldwell@gmail.com', 'not_my_password')
        self.assertFalse(firefly.is_successful_response(json_data))

    def test_logout(self):
        """ Tests that a user can log out."""
        json_data = firefly.login(self.user1, 'test123')
        session_key = json_data['response']['sessionKey']
        json_data = firefly.logout(session_key)
        self.assertTrue(firefly.is_successful_response(json_data))

    def test_logout_invalid_session_key(self):
        """ Tests that a user can not log out with an invalid session key."""
        session_key = 'slartibartfast'
        firefly.logout(session_key)
        json_data = firefly.logout(session_key)
        self.assertFalse(firefly.is_successful_response(json_data))
