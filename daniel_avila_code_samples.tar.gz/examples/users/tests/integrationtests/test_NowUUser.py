from django.conf import settings
from django.test import TestCase

import mock

from boomers.apps.users.models import NowUUser


class TestNowUUser(TestCase):
    """Does our user do all we ask?"""

    def test_new_user(self):
        """Can we make a new user from our user class?"""

        user = NowUUser.objects.create_user('x@y.com', 'fakepassword')
        all_users = NowUUser.objects.filter(email='x@y.com')
        self.assertTrue(len(all_users) == 1)

    def test_has_active_subscription(self):
        """Is user's subscription status correctly reflected?"""
        # TODO
