from django.conf import settings
from django.contrib.auth import get_user_model
from django.contrib.auth.backends import ModelBackend

from boomers.apps.users import firefly


class FireflyBackend(ModelBackend):

    def authenticate(self, username=None, password=None, **kwargs):

        session = None
        user = None

        # should be a 'request' kwarg available here
        if 'request' in kwargs:
            session = kwargs['request'].session

        # authenticate against atypon
        json_data = firefly.login(username, password)
        if firefly.is_successful_response(json_data):
            UserModel = get_user_model()
            username = username.lower()
            try:
                user = UserModel._default_manager.get(atypon_user_id=json_data['response']['user']['userId'])

            except UserModel.DoesNotExist:
                # Create the user locally (as they authenticated successfully
                # against atypon).
                user = get_user_model()(email=username)
                user.atypon_user_id = json_data['response']['user']['userId']
                user.is_active = True
                user.save()

            # add atypon data to session
            if user and session:
                session['atyponAutoLogin'] = json_data['response']['autologin']
                session['atyponSessionKey'] = json_data['response']['sessionKey']
                session['firstName'] = json_data['response']['user']['firstName']
                session['lastName'] = json_data['response']['user']['lastName']

        return user
