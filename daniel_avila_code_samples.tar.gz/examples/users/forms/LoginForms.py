"""A simple form class for validation"""
import uuid

from django import forms
from django.conf import settings
from django.contrib.auth import views as django_builtin_login
from django.contrib.auth import get_user_model
from django.forms.util import ErrorList
from django.http import HttpResponse, HttpResponseRedirect


NOWUUSER = get_user_model()
class DelayedLoginForm(forms.Form):

    username = forms.CharField()
    password = forms.CharField()


    def validate_login(self, request):

        context = {}
        email_address = self.cleaned_data['username'].lower()
        # sleep and log
        try:
            user = NOWUUSER.objects.get(email=email_address)
            if user.is_verified:
                # change the login method in the database
                user.login_method = 'nowu'
                user.save()
                # send back to django's built-in login method
                return django_builtin_login.login(request, template_name='users/login.html', extra_context=context)
            else:
                return HttpResponse('You must first confirm your email address before you log in.')
        except Exception, e:
            print e
            return HttpResponse('You have not signed up for NowU.')
