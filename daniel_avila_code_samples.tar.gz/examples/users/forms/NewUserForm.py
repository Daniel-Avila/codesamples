import uuid

from django import forms
from django.contrib.auth import get_user_model
from django.db import IntegrityError
from django.forms.util import ErrorList
from django.http import HttpResponse
from guardian.shortcuts import assign_perm

from boomers.apps.users.utils import send_verification_email

NOWUUSER = get_user_model()
class NewUserForm(forms.Form):
    """A new user for to make it easy to validate"""


    email = forms.EmailField()
    password = forms.CharField()
    password2 = forms.CharField()
    is_csr = forms.BooleanField(required=False)
    is_staff = forms.BooleanField(required=False)


    def is_valid(self):
        """We have to check if our two password fields are valid"""
        valid = super(NewUserForm, self).is_valid()
        if not valid:
            return valid
        if not self.cleaned_data['password'] == self.cleaned_data['password2']:
            el = ErrorList(['passwords do not match'])
            self._errors['password'] = el

        if self._errors:
            return False
        return True

    def save_user(self):
        """make the user and save it to the database
           Returns an HTTPResponse object
        """
        try:
            user = NOWUUSER.objects.create_user(self.cleaned_data['email'], self.cleaned_data['password'])
            if self.cleaned_data['is_csr']:
                user.is_csr=True
            if self.cleaned_data['is_staff']:
                user.is_staff=True
            user.save()
            if getattr(user, 'is_csr', True):
                assign_perm('users.change_nowuuser',user, None)

            return user
        except IntegrityError:
            return None

    def save(self, commit=True):
        return self.save_user()


    def _check_social_logins(self):
        """Check and see if they have social a social login"""
        potential_social_logins = NOWUUSER.objects.get(email__iexact=self.cleaned_data['email']).get_social_users
        context = {}
        if potential_social_logins:
            msg = 'You already have an account that you created through %s. Please use that/those to log in.'
            msg %= potential_social_logins
            context['error_msg'] = msg
        else:
            msg = 'There is already an account created for email address: %s' % self.cleaned_data['email']
            context['error_msg'] = msg
        context['email'] = self.cleaned_data['email']
        return context


    def _send_verification_email(self, user):
        """Send an email varification email"""
        # create verification code and save to NOWUUSER object
        verification_code = uuid.uuid4().get_hex()
        user.verification_code = verification_code
        user.is_active = True
        user.save()
        # send verification email
        send_conf_email = send_verification_email(self.cleaned_data['email'], verification_code)
        if send_conf_email == 'success':
            return _send_response('Please check your email for your verification code.')
        else:
            msg = """Email could not be sent
            <br/><br/>to_email = %s
            <br/><br/>url_encoded_email = %s
            <br/><br/>verification_code = %s
            <br/><br/>verification_url = %s
            """ % (send_conf_email[0], send_conf_email[1], send_conf_email[2], send_conf_email[3])

            return _send_response(msg)


def _send_response(msg):
    """Just we we have to reference http response once"""
    return HttpResponse(msg)
