#!/usr/bin/env python
# -*- coding: utf-8 -*-

from __future__ import absolute_import, division

import logging
import urllib

import requests
from django.conf import settings

from boomers.utils import call_api

logger = logging.getLogger('boomers')

#### CONSTANTS ####
EMAIL_ALREADY_EXISTS = 500
OBJECT_NOT_FOUND = 220

#### UTILITY METHODS ####
def is_successful_response(json_data):
    return get_response_status(json_data) == 0  # non-zero status indicates Firefly error

def get_response_message(json_data):
    return json_data.get('meta', {}).get('message', '')

def get_response_status(json_data):
    return json_data.get('meta', {}).get('status', 1)

def build_firefly_url(action):
    return '{firefly_url}/{action}'.format(
        firefly_url=settings.FIREFLY_API,
        action=action)

def call_firefly(action, data={}):

    private = (
        'getUser',
        'sendWelcomeEmail',
    )

    # build the url
    url = build_firefly_url(action)

    # append external secret key, if necessary
    if action in private and 'sessionKey' not in data:
        data['externalSecret'] = settings.FIREFLY_KEY

    # append the market id
    data['marketId'] = settings.FIREFLY_MARKET_ID

    # call api
    with call_api(url, data) as json_data:
        if not is_successful_response(json_data):
            logger.warning('Calling %s returned error: %s' % (
                url, get_response_message(json_data)
            ))
        return json_data


#### API WRAPPER METHODS ####
def create_user(email, **kwargs):
    """ Creates a user via the Firefly/Atypon API."""
    kwargs.update({'email': email})
    kwargs['firstName'] = kwargs.get('firstName', '')
    kwargs['lastName'] = kwargs.get('lastName', '')
    return call_firefly('createUser', data=kwargs)

def reset_password(email):
    """ Resets a user's Atypon password."""
    return call_firefly('resetPassword', {'email': email})

def get_user(user_id=None, email=None, session_key=None):
    """ Retrieves a user by atypon_user_id, email, or sessionKey."""

    data = {}

    if user_id:
        data['userId'] = user_id
    if email:
        data['email'] = email
    if session_key:
        data['sessionKey'] = session_key

    return call_firefly('getUser', data)

def login(email, password=None):
    """ Logs a user in via the Firefly/Atypon API."""

    data = {
        'username': email,
        'password': password,
        'marketId': 'NOWU'
    }

    return call_firefly('login', data)

def logout(session_key):
    """ Logs a user out via the Firefly/Atypon API."""

    url = build_firefly_url('logout')

    data = {
        'sessionKey': session_key,
    }

    return call_firefly('logout', data)
