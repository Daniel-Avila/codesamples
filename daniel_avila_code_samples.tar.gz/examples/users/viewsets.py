#!/usr/bin/env python
# -*- coding: utf-8 -*-

from __future__ import absolute_import, division

from django.contrib.auth import login as auth_login
from django.contrib.auth import logout as auth_logout
from django.contrib.auth import authenticate
from django.http import Http404
from rest_framework import status, viewsets
from rest_framework.decorators import action, link
from rest_framework.response import Response

from boomers.apps.users import firefly
from boomers.apps.users.forms.NewUserForm import NewUserForm
from boomers.apps.users.models import NowUUser
from boomers.apps.users.serializers import UserSerializer
from boomers.utils import call_api


class UserViewSet(viewsets.ViewSet):
    """
    A comprehensive api for NowU user operations.
    """

    queryset = NowUUser.objects.all()

    @action()
    def login(self, request, pk=None):
        password = request.POST['password']
        user = authenticate(username=pk, password=password, request=request)
        if user is not None:
            if user.is_active:
                auth_login(request, user)
            else:
                return Response(
                    {'message': 'user is inactive'},
                    status=status.HTTP_400_BAD_REQUEST)
        else:
            return Response(
                {'message': 'invalid email/password combo'},
                status=status.HTTP_400_BAD_REQUEST)

        # return the serialized user data
        serializer = UserSerializer(user)
        return Response(serializer.data)

    @action()
    def logout(self, request, pk=None):

        auth_logout(request)

        return Response(
            {'message': 'user logged out'},
            status=status.HTTP_200_OK)

    def list(self, request):
        raise NotImplementedError


    def create(self, request):

        # use form to validate the input
        f = NewUserForm(request.POST)
        if not f.is_valid():
            return Response(
                {'message': f.errors},
                status=status.HTTP_400_BAD_REQUEST)

        # save the user
        user = f.save_user()

        # login and return the serialized user
        return self.login(request, user.email)


    def retrieve(self, request, pk=None):
        """ Retrieves a user by atypon_user_id or email address.
            If email address is given, then we're only looking up
            Gannett subscription data... otherwise, get all the
            user's info."""

        kwargs = {}
        user = None

        try:
            atypon_user_id = int(pk)

            # must be an atypon_user_id
            kwargs['user_id'] = atypon_user_id

            # have we seen this user before?
            try:
                user = NowUUser.objects.get(atypon_user_id=atypon_user_id)
            except NowUUser.DoesNotExist:
                pass

        except ValueError:
            # must be an email address
            kwargs['email'] = pk

            # have we seen this user before?
            try:
                user = NowUUser.objects.get(email=pk)
            except NowUUser.DoesNotExist:
                pass

        # call firefly api
        json_data = firefly.get_user(**kwargs)

        # did we find an account?
        if firefly.get_response_status(json_data) == firefly.OBJECT_NOT_FOUND:
            # nope...
            if 'user_id' in kwargs:
                # if we asked for a user by ID, then return an error
                return Response(
                    {'message': 'error retrieving user'},
                    status=status.HTTP_404_NOT_FOUND)
            else:
                # otherwise, we are just trying to look up subscriber status...
                # no big deal...
                user = NowUUser(
                    email=kwargs['email'],
                    atypon_user_id=None)

        # did the call fail for some other reason?
        elif not firefly.is_successful_response(json_data):
            if user:
                # if so, but we know the user, return the serialized user
                serializer = UserSerializer(user)
                return Response(serializer.data)

            # if we don't know the user, return an error
            return Response(
                {'message': 'error retrieving user'},
                status=status.HTTP_400_BAD_REQUEST)

        else:
            # found it!
            if not user:
                user = NowUUser(
                    email=json_data['response']['email'],
                    atypon_user_id=json_data['response']['userId'])
            else:
                # update the user info with latest from atypon
                user.email=json_data['response']['email']
                user.atypon_user_id=json_data['response']['userId']
                user.save() # TODO: do we want this side-effect?

        # and return the serialized user as response
        serializer = UserSerializer(user)
        return Response(serializer.data)

    def update(self, request, pk=None):
        raise NotImplementedError

    def partial_update(self, request, pk=None):
        raise NotImplementedError

    def destroy(self, request, pk=None):
        raise NotImplementedError
