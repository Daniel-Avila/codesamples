"""Confirm our email view"""
from django.conf import settings
from django.contrib.auth import get_user_model
from django.http import HttpResponse
from django.views.generic import View

from .utils import send_verification_email, sleep_and_log_then_continue

NOWUUSER = get_user_model()

class ConfirmEmail(View):
    """Provide an interface to confirm the users email address"""

    def get(self, request, email_address, verification_code):
        """The user clicks a link to confirm the email address so we are a get rather than
        a post"""

        email_address = email_address.lower()
        # sleep and log
        allow = sleep_and_log_then_continue(request, 'confirm_email', email_address)
        if not allow:
            return HttpResponse(settings.THROTTLE_MESSAGE)
        # confirm email
        account_exists = NOWUUSER.objects.filter(email=email_address, verification_code=verification_code).count()
        if account_exists:
            try:
                NOWUUSER.objects.filter(email=email_address,
                        verification_code=verification_code).update(is_verified=True)
                return HttpResponse('Your account has been confirmed!')
            except Exception:
                return HttpResponse('Unknown Error: please try your confirmation URL again')
        else:
            return HttpResponse('Your email or verification code is incorrect.')

class ResendVerificationEmail(View):
    """Sometimes we have to resend the verification email"""

    def get(self, request, email_address):
        ##TODO: This might need to be a post

        email_address = email_address.lower()
        # sleep and log
        allow = sleep_and_log_then_continue(request, 'resend_verification_email', email_address)
        if not allow:
            return HttpResponse(settings.THROTTLE_MESSAGE)
        # send verification email
        try:
            account = NOWUUSER.objects.get(email=email_address)
        except NOWUUSER.DoesNotExist:
            return HttpResponse('There is no registered account for this email address.')
        verification_code = account.verification_code
        send_conf_email = send_verification_email(email_address, verification_code)
        if send_conf_email == 'success':
            return HttpResponse('Please check your email for a verification link.')
        else:
            msg = """Email could not be sent<br/><br/>
                     to_email = %s<br/><br/>url_encoded_email = %s
                     <br/><br/>verification_code = %s <br/><br/>
                     verification_url = %s""" % (send_conf_email[0], send_conf_email[1],
                             send_conf_email[2], send_conf_email[3])
            return HttpResponse(msg)
