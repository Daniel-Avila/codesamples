import uuid

from django.http import HttpResponse, HttpResponseRedirect
from django.views.generic import View


class FacebookLoggedIn(View):
    def get(self, request):
        if request.user.is_authenticated():
            user = request.user
            # set basic user info, if necessary
            user.is_verified = True
            user.login_method = 'facebook' # update the most recent login method
            if not user.verification_code:
                redirect = True
                verification_code = uuid.uuid4().get_hex()
                user.verification_code = verification_code
                user.email_pref = True
                user.newsletter_pref = True
            user.save()
            return HttpResponseRedirect(request.session.get('last_visited', '/'))
        else:
            return HttpResponse('You are not logged in.')

class GoogleLoggedIn(View):
    def get(self, request):
        if request.user.is_authenticated():
            user = request.user
            # set basic user info, if necessary
            user.is_verified = True
            user.login_method = 'google' # update the most recent login method
            if not user.verification_code:
                redirect = True
                verification_code = uuid.uuid4().get_hex()
                user.verification_code = verification_code
                user.email_pref = True
                user.newsletter_pref = True
            user.save()
            return HttpResponseRedirect('/register/my-account')
        else:
            return HttpResponse('You are not logged in.')
