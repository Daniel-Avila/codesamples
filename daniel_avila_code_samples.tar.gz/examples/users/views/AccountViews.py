import json
import urllib2

from django.conf import settings
from django.contrib.auth import authenticate, get_user_model
from django.http import HttpResponse, HttpResponseRedirect
from django.shortcuts import render
from django.views.generic import View
from social.apps.django_app.default.models import UserSocialAuth

from .utils import sleep_and_log_then_continue

NOWUUSER = get_user_model()

class MyAccount(View):
    def get(self, request):
        context = {}
        if not request.user.is_authenticated():
            redirect_src = 'my-account'
            return HttpResponseRedirect('/register/login/?src='+redirect_src)
        if request.user.login_method == 'facebook':
            social_user = UserSocialAuth.objects.filter(user=request.user, provider__startswith='facebook')[0]
            fb_id = social_user.uid
            fb_img_url = 'http://graph.facebook.com/'+ fb_id +'/picture?type=large' #remove ?type=large to get smaller (square) image
            context['profile_pic_url'] = fb_img_url
        elif request.user.login_method == 'google':
            social_user = UserSocialAuth.objects.filter(user=request.user, provider__startswith='google')[0]
            social_token = social_user.extra_data['access_token']
            social_data = json.load(urllib2.urlopen('https://www.googleapis.com/oauth2/v1/userinfo?alt=json&access_token=' + social_token))
            context['google_data'] = social_data
            context['profile_pic_url'] = social_data['picture']
        if request.user.profile_pic:
            context['profile_pic_url'] = request.user.profile_pic.url # if user has uploaded an image, override their FB or google image
        return render(request, 'users/my_account.html', context)


class ChangeSubscriptionType(View):
    def post(self, request):
        if not request.user.is_authenticated():
            return HttpResponse('You must be logged in to change your subscription type.')
        try:
            change_to = request.POST['subscription-type']
            user = NOWUUSER.objects.get(email=request.user.email)
            # TBD
            return HttpResponse('Your subscription type would have been changed to: ' + change_to)
        except Exception:
            return HttpResponse('Database update failed')




class CancelAccount(View):
    def get(self, request):
        if not request.user.is_authenticated():
            redirect_src = 'my-account'
            return HttpResponseRedirect('/register/login/?src='+redirect_src)
        return render(request, 'users/cancel_account.html')
    def post(self, request):
        # sleep and log
        allow = sleep_and_log_then_continue(request, 'cancel_account', request.user.email)
        if not allow:
            return HttpResponse(settings.THROTTLE_MESSAGE)
        # verify password then mark the account as "cancelled" in the database
        user = authenticate(username=request.user.email, password=request.POST['password'])
        if not user:
            return HttpResponse('Your email and password combination are invalid.')
        user.is_active = False
        user.save()
        return HttpResponse('Your user account has been cancelled.')
