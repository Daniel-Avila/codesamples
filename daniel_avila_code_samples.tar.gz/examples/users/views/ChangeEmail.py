"""Email Classes"""

from django.conf import settings
from django.contrib.auth import get_user_model
from django.http import HttpResponse, HttpResponseRedirect
from django.views.generic import View

from .utils import send_reset_email_verification, sleep_and_log_then_continue

NOWUUSER = get_user_model()

class ChangeEmail(View):
    def get(self, request, old_email_address, new_email_address, verification_code):
        # sleep and log
        allow = sleep_and_log_then_continue(request, 'change_email_page', old_email_address)
        if not allow:
            return HttpResponse(settings.THROTTLE_MESSAGE)
        # send email confirmation
        try:
            user = NOWUUSER.objects.get(email=old_email_address, verification_code=verification_code)
        except NOWUUSER.DoesNotExist:
            return HttpResponse('User failed to validate, please make sure your URL is correct and try again. If that fails, click the "forgot password" link again and restart the process. (Error code: 88267)')
        user.email = new_email_address
        user.save()
        return HttpResponse('Your email has successfully been changed! Use this email from now on to log in.')
    def post(self, request):
        # sleep and log
        allow = sleep_and_log_then_continue(request, 'my_account_post', request.user.email)
        if not allow:
            return HttpResponse(settings.THROTTLE_MESSAGE)
        # verify login, post info, and try to reset user email
        if not request.user.is_authenticated():
            redirect_src = 'my-account'
            return HttpResponseRedirect('/register/login/?src='+redirect_src)
        if request.POST['new-email'] and request.POST['new-email-2']:
            new_email = request.POST['new-email']
            new_email_2 = request.POST['new-email-2']
            if new_email != new_email_2:
                return HttpResponse('Your emails do not match')
            verification_code = request.user.verification_code
            reset_email_confirm = send_reset_email_verification(request.user.email, new_email, verification_code)
            if reset_email_confirm == 'success':
                return HttpResponse('We have sent a link to ' + new_email + '. Click the link to reset your account email address.')
            else:
                return HttpResponse('Email reset verification could not be sent<br/><br/>to_email = '+reset_email_confirm[0]+'<br/><br/>url_encoded_email = '+reset_email_confirm[1]+'<br/><br/>verification_code = '+reset_email_confirm[2]+'<br/><br/>verification_url = '+reset_email_confirm[3])
        return HttpResponse('Error: invalid post information. (Error code: 38991)')
