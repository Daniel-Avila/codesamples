"""Create a new user view"""

from django.conf import settings
from django.http import HttpResponse
from django.views.generic.edit import FormView

from boomers.apps.users.forms.NewUserForm import NewUserForm

from .utils import sleep_and_log_then_continue


class NewUser(FormView):
    """Handle requests about creating a new user"""

    template_name = 'users/register.html'
    form_class = NewUserForm
    success_url = '/newuser/success'

    def form_valid(self, form):
        """If our form is valid We run this code"""

        allow = sleep_and_log_then_continue(self.request, 'create_new_user', form.cleaned_data['email'])
        if not allow:
            return HttpResponse(settings.THROTTLE_MESSAGE)

        # create verification code and save to NowUUser object
        user = form.save_user()
        verification_code = uuid.uuid4().get_hex()
        user.verification_code = verification_code
        user.is_active = True
        user.save()

        return user
