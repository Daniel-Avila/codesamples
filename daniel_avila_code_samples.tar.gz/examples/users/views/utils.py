"""Utility functions"""
import time
import urllib
import urllib2
from datetime import datetime, timedelta

from django.conf import settings
from django.core.mail import EmailMultiAlternatives

from boomers.apps.users.models import ActionLogger


def get_client_ip(request):
    """Get the ip address of the web client accessing the site"""

    x_forwarded_for = request.META.get('HTTP_X_FORWARDED_FOR')
    try:
        if x_forwarded_for:
            ip = x_forwarded_for.split(',')[-1].strip()
        else:
            ip = request.META.get('REMOTE_ADDR')
        return ip
    except Exception:
        return ''


def log_action(request, action_short, attempted_user_email='', user=None):
    """Log an action that could be a bot but probably is not. Better safe than sorry"""

    # set variables and check ActionLogger table to see number of attempts in last hour
    ip_address = get_client_ip(request)
    if not user and request.user.is_authenticated():
        user = request.user
    attrs = {
        'ip_address': ip_address,
        'action_short': action_short,
        'attempted_user_email': attempted_user_email,
        'user': user,
    }
    recent_count_action_and_email = ActionLogger.objects.filter(action_short=action_short,
            attempted_user_email=attempted_user_email, timestamp__gt=datetime.now() - timedelta(hours=1)).count()
    # check if we need to throttle the user, else log them in the database and allow them to continue
    if recent_count_action_and_email <= 50:
        try:
            ActionLogger.objects.create(**attrs)
        except Exception:
            pass
        return True #I should allow user to continue
    else:
        return False #I should NOT allow user to continue

def sleep_and_log_then_continue(request, action_short, attempted_user_email=''):
    """Wait then log and continue. We sleep here to prevent bots from slamming us"""
    time.sleep(2)
    log_and_continue = log_action(request, action_short, attempted_user_email)
    return log_and_continue

def send_reset_email_verification(new_email, old_email, verification_code):
    """Verify that we have a valid email reset request"""
    url_encoded_email_new = urllib.quote_plus(new_email)
    url_encoded_email_old = urllib.quote_plus(old_email)
    verification_url = '%s/%s/%s/%s/' % (settings.USER_EMAIL_RESET_URL,
                                         url_encoded_email_new,
                                         url_encoded_email_old,
                                         verification_code)

    email_title = 'Link to reset your account email at NowU'
    email_body_text = settings.USER_EMAIL_RESET_TEXT % verification_url
    email_body_html = settings.USER_EMAIL_RESET_HTML % verification_url
    from_email = settings.NO_REPLY
    to_email = new_email
    kwargs = {'email_title': email_title
            , 'email_body_text':email_body_text
            , 'from_email':from_email
            , 'to_email':to_email
            , 'email_body_html':email_body_html
            , 'url_encoded_email': url_encoded_email_new
            , 'verification_code' : verification_code
            , 'verification_url' : verification_url
            }
    return _send_email(**kwargs)

def send_verification_email(email, verification_code):
    """Send or in some cases resend the verification email for a user"""

    url_encoded_email = urllib.quote_plus(email)
    verification_url = '%s/%s/%s/' % (settings.USER_EMAIL_CONFIRM_URL, url_encoded_email, verification_code)
    email_title = 'Confirm your new email for NowU!'
    email_body_text = '%s%s' % (settings.USER_EMAIL_CONFIRM_TEXT, verification_url)
    email_body_html = '%s%s' % (settings.USER_EMAIL_CONFIRM_HTML, verification_url)
    from_email = settings.NO_REPLY
    to_email = email
    kwargs = {'email_title': email_title
            , 'email_body_text':email_body_text
            , 'from_email':from_email
            , 'to_email':to_email
            , 'email_body_html':email_body_html
            , 'url_encoded_email': url_encoded_email
            , 'verification_code' : verification_code
            , 'verification_url' : verification_url
            }
    return _send_email(**kwargs)

def send_forgotten_password_email(email, verification_code):
    url_encoded_email = urllib.quote_plus(email)
    verification_url = '%s/%s/%s/' % (settings.USER_PASSWORD_RESET_URL, url_encoded_email, verification_code)
    email_title = 'Link to reset your password at NowU'
    email_body_text = settings.USER_PASSWORD_RESET_TEXT % verification_url
    email_body_html = settings.USER_PASSWORD_RESET_HTML % verification_url
    from_email = settings.NO_REPLY
    to_email = email
    kwargs = {'email_title': email_title
            , 'email_body_text':email_body_text
            , 'from_email':from_email
            , 'to_email':to_email
            , 'email_body_html':email_body_html
            , 'url_encoded_email': url_encoded_email
            , 'verification_code' : verification_code
            , 'verification_url' : verification_url
            }

    return _send_email(**kwargs)

def _send_email(**kwargs):
    try:
        msg = EmailMultiAlternatives(kwargs.get('email_title'),
                kwargs.get('email_body_text'),
                kwargs.get('from_email'),
                [kwargs.get('to_email')])
        #TODO: must test this on live server and/or replace with in-house SMTP
        msg.attach_alternative(kwargs.get('email_body_html'), "text/html")
        msg.send()
        return 'success'
    except Exception:
        return [kwargs.get('to_email')
                , kwargs.get('url_encoded_email')
                , kwargs.get('verification_code')
                , kwargs.get('verification_url')
               ]
