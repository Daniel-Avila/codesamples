from IndexView import index
from NewUser import NewUser
from ConfirmEmail import (ConfirmEmail,
                          ResendVerificationEmail)
from ResetPassword import (ResetPassword,
                           ForgottenPassword,
                           ForgottenPasswordReset)

from ChangeEmail import ChangeEmail
from LoginViews import (SuccessfulLoginPage,
                        DelayedLogin)

from AccountViews import (MyAccount,
                         ChangeSubscriptionType,
                         CancelAccount)

from PreferenceViews import (toggle_email_prefs,
                             toggle_newsletter_prefs
                            )

from JQueryViews import upload_pic, delete_pic

from SocialAuthViews import FacebookLoggedIn, GoogleLoggedIn
