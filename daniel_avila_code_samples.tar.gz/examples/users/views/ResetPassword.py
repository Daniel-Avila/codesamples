
from django.conf import settings
from django.contrib.auth import authenticate, get_user_model
from django.http import HttpResponse
from django.shortcuts import render
from django.views.generic import View
from datetime import datetime
from .utils import (send_forgotten_password_email, send_verification_email,
                    sleep_and_log_then_continue)
from boomers.apps.users.utils import get_client_ip
import logging
logger2 = logging.getLogger('Audit_Logger')

NOWUUSER = get_user_model()

class ResetPassword(View):
    def get(self, request):
        context = {}
        return render(request, 'users/reset_password.html', context)
    def post(self, request):
        email = request.POST['email']
        email = email.lower()
        # sleep and log
        allow = sleep_and_log_then_continue(request, 'reset_password', email)
        if not allow:
            return HttpResponse(settings.THROTTLE_MESSAGE)
        # reset password
        email = request.POST['email']
        email = email.lower()
        cur_password = request.POST['cur_password']
        new_password = request.POST['new_password']
        new_password_2 = request.POST['new_password_2']
        if new_password != new_password_2:
            return HttpResponse('Your passwords do not match, please try again')
        user = authenticate(email=email, password=cur_password)
        if user is not None:  # this user is in our database and the current password is correct
            if user.is_active and user.is_verified:
                user.set_password(new_password)
                user.save()
                return HttpResponse('Your new password has been saved!')
            else:
                return HttpResponse('Before you can reset your password, please validate your account by clicking the confirmation link we sent to your email (' + email + ') when you signed up.')
        else:
            email_exists = NOWUUSER.objects.filter(email=email).count()
            if email_exists:
                return HttpResponse('Your current password was incorrect, please try again.')
            else:
                return HttpResponse('This email address does not exist in our database')

class ForgottenPassword(View):
    def get(self, request):
        context = {}
        return render(request, 'users/forgotten_password.html', context)
    def post(self, request):
        email = request.POST['email']
        email = email.lower()
        # sleep and log
        allow = sleep_and_log_then_continue(request, 'forgot_password_start', email)
        if not allow:
            return HttpResponse(settings.THROTTLE_MESSAGE)
        # send forgot password email
        try:
            user = NOWUUSER.objects.get(email=email)
        except NOWUUSER.DoesNotExist:
            return HttpResponse('This user does not exist')
        verification_code = user.verification_code
        forgotten_pw_email = send_forgotten_password_email(email, verification_code)
        if forgotten_pw_email == 'success':
            logger2.info('[Result=Reset Password Mail Sent]')
            logger2.info('[%s][CSR=%s][CSR IP=%s][Result=Password Reset email sent successfully][UserEmail=%s]',datetime.now(), request.user, get_client_ip(request), email)
            return HttpResponse('We have sent a link to ' + email + '. Click the link to reset your password.')
        else:
            logger2.info('[%s][CSR=%s][CSR IP=%s][Result=Password Reset email could not be sent][UserEmail=%s]',datetime.now(), request.user, get_client_ip(request), email)
            return HttpResponse('Password Reset email could not be sent<br/><br/>to_email = '+forgotten_pw_email[0]+'<br/><br/>url_encoded_email = '+forgotten_pw_email[1]+'<br/><br/>verification_code = '+forgotten_pw_email[2]+'<br/><br/>verification_url = '+forgotten_pw_email[3])
            # TODO: ^^ change this HttpResponse after we are done debugging so we don't show the verification URL

class ForgottenPasswordReset(View):
    def get(self, request, email_address, verification_code):
        email_address = email_address.lower()
        # sleep and log
        allow = sleep_and_log_then_continue(request, 'forgot_password_reset_get', email_address)
        if not allow:
            return HttpResponse(settings.THROTTLE_MESSAGE)
        # check url credentials/verification code, then display password reset form
        account_exists = NOWUUSER.objects.filter(email=email_address, verification_code=verification_code).count()
        if account_exists:
            context = {}
            context['email'] = email_address
            context['verification_code'] = verification_code
            return render(request, 'users/forgotten_password_reset.html', context)
        else:
            return HttpResponse('Your email or verification code is incorrect.')
    def post(self, request, email_address, verification_code):
        email_address = email_address.lower()
        # sleep and log
        allow = sleep_and_log_then_continue(request, 'forgot_password_reset_post', email_address)
        if not allow:
            return HttpResponse(settings.THROTTLE_MESSAGE)
        # save new password
        new_password = request.POST['new_password']
        new_password_2 = request.POST['new_password_2']
        if new_password != new_password_2:
            return HttpResponse('Your passwords do not match, please go back and try again.')
        try:
            user = NOWUUSER.objects.get(email=email_address, verification_code=verification_code)
        except NOWUUSER.DoesNotExist:
            return HttpResponse('User failed to validate, please make sure your URL is correct and try again. If that fails, click the "forgot password" link again and restart the process. (Error code: 88267)')
        user.set_password(new_password)
        user.save()
        return HttpResponse('Your password has been updated!')
