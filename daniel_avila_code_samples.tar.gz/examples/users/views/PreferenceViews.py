from django.contrib.auth import get_user_model
from django.http import HttpResponse, HttpResponseRedirect
from django.views.generic import View

NOWUUSER = get_user_model()
def toggle_email_prefs(request):
    if not request.user.is_authenticated():
        return HttpResponse('You are not logged in.')
    user = NOWUUSER.objects.get(email=request.user.email)
    if user.email_pref == False:
        new_pref = True
    elif user.email_pref == True:
        new_pref = False
    user.email_pref = new_pref
    user.save()
    return HttpResponseRedirect('/register/my-account/')


def toggle_newsletter_prefs(request):
    if not request.user.is_authenticated():
        return HttpResponse('You are not logged in.')
    user = NOWUUSER.objects.get(email=request.user.email)
    if user.newsletter_pref == False:
        new_pref = True
    elif user.newsletter_pref == True:
        new_pref = False
    user.newsletter_pref = new_pref
    user.save()
    return HttpResponseRedirect('/register/my-account/')
