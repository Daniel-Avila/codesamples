import os
import time
import urllib2
import uuid

from django.conf import settings
from django.contrib.auth import get_user_model
from django.core.files import File
from django.core.files.temp import NamedTemporaryFile
from django.http import HttpResponse, HttpResponseRedirect
from PIL import Image  # sudo apt-get build-dep python-imaging # sudo apt-get install libjpeg62 libjpeg62-dev # sudo pip install Pillow

NOWUUSER = get_user_model()
def upload_pic(request, upload_type):
    if not request.user.is_authenticated():
        return HttpResponse('not logged in')
    if upload_type == 'preview':
        if request.method == 'POST' and 'url-pic' in request.POST and request.POST['url-pic']:
            pic_url = request.POST['url-pic']
            img_temp = NamedTemporaryFile(delete=True)
            img_temp.write(urllib2.urlopen(pic_url).read())
            img_temp.flush()
            pic_id = str(uuid.uuid4().get_hex())
            try:
                f = File(img_temp)
                with open(settings.MEDIA_ROOT + '/temp_images/temp-pic-'+pic_id+'.png', 'wb+') as destination:
                    for chunk in f.chunks():
                        destination.write(chunk)
            except IOError:
                return HttpResponse('failed')
            return HttpResponse(pic_id)
        elif request.method == 'POST' and 'profile-pic' in request.FILES and request.FILES['profile-pic']:
            pic_id = str(int(time.time() * 1000000))
            try:
                f = File(request.FILES['profile-pic'])
                print(settings.MEDIA_ROOT)
                with open(settings.MEDIA_ROOT + '/temp_images/temp-pic-'+pic_id+'.png', 'wb+') as destination:
                    for chunk in f.chunks():
                        destination.write(chunk)
                return HttpResponse(pic_id)
            except IOError:
                return HttpResponse('failed')
        else:
            return HttpResponse('no post')
    elif upload_type == 'final':
        try:
            f = File(request.FILES['profile-pic'])
        except:
            try:
                pic_url = request.POST['url-pic']
                ending = pic_url.rfind('.')
                file_type = pic_url[ending:]
                if file_type != '.png' and file_type != '.jpg' and file_type != '.jpeg' and file_type != '.bmp' and file_type != '.gif':
                    file_type = '.png'
                img_temp = NamedTemporaryFile(delete=True)
                img_temp.write(urllib2.urlopen(pic_url).read())
                img_temp.flush()
                f = File(img_temp)
                if f.name[-4] != '.' and f.name[-5] != '.':
                    f.name = f.name + file_type
            except:
                return HttpResponse('Upload failed, please try again')
        user = NOWUUSER.objects.get(email=request.user.email)
        if user.profile_pic:
            try:
                pic_url = settings.MEDIA_ROOT + str(user.profile_pic.url).replace('/media', '')
                os.remove(pic_url)
            except:
                img_path = settings.MEDIA_ROOT + str(user.profile_pic.url).replace('/media', '')
                if str(img_path)[-4] != '.' and str(img_path)[-5] != '.':
                    img_path = img_path + '.png'
                pic_url = img_path
                os.remove(pic_url)
        user.profile_pic = f
        user.save()

        # Take the uploaded image and crop it:
        profilePic = NOWUUSER.objects.get(email=request.user.email).profile_pic
        thisImage = Image.open(profilePic)
        try:
            if thisImage.mode != "RGB":
                thisImage = thisImage.convert("RGB") # if color mode is not RGB it will throw an error and not save
        except:
            return HttpResponse('Invalid file type')
        uploadedWidth, uploadedHeight = thisImage.size
        picTop = int(float(request.POST['photo-top']))
        picLeft = int(float(request.POST['photo-left']))
        picDimension = int(float(request.POST['photo-height-width']))
        scale = uploadedWidth / 200.0
        if picTop < 0: picTop = 0
        if picLeft < 0: picLeft = 0
        if picDimension < 50: picDimension = 50
        elif picDimension > 198: picDimension = 200
        if picTop < 0: picTop = 0
        if picLeft < 0: picLeft = 0
        edgeLeft = picLeft * scale
        edgeTop = picTop * scale
        edgeWidth = picDimension * scale
        edgeHeight = picDimension * scale

        edgeRight = edgeLeft + edgeWidth
        edgeBottom = edgeTop + edgeHeight

        # some additional precautions so crop size stays within image bounds
        if edgeWidth > uploadedWidth: edgeWidth = int(float(uploadedWidth))
        if edgeHeight > uploadedHeight: edgeHeight = int(float(uploadedHeight))
        if edgeLeft < 0: edgeLeft = 0
        if edgeTop < 0: edgeTop = 0
        if edgeRight > uploadedWidth: edgeRight = uploadedWidth
        if edgeBottom > uploadedHeight: edgeBottom = uploadedHeight

        # crop profilepic
        box = (int(float(edgeLeft)), int(float(edgeTop)), int(float(edgeRight)), int(float(edgeBottom)))
        thisImage = thisImage.crop(box)
        newWidth, newHeight = thisImage.size
        thisImage = thisImage.resize((200,200), Image.ANTIALIAS)

        #   save profile pic
        img_save_path = settings.MEDIA_ROOT + str(user.profile_pic.url).replace('/media', '')
        if str(img_save_path)[-4] != '.' and str(img_save_path)[-5] != '.':
            img_save_path = img_save_path + '.png'
        thisImage.save(img_save_path)

        return HttpResponseRedirect('/register/my-account/')
    return HttpResponse('Error 93889. Please contact the administrator.')



def delete_pic(request, pic_id):
    temp_images_folder = settings.MEDIA_ROOT + '/temp_images/'
    for file_name in os.listdir(temp_images_folder):
        try:
            os.remove(temp_images_folder + file_name)
        except:
            pass
    return HttpResponse('True')
