from django.conf import settings
from django.contrib.auth import views as django_builtin_login
from django.contrib.auth import get_user_model
from django.contrib.auth.views import logout as auth_logout
from django.http import HttpResponse, HttpResponseRedirect
from django.shortcuts import redirect
from django.views.generic import View
from django.views.generic.edit import FormView
from social.apps.django_app.default.models import UserSocialAuth

from boomers.apps.users.forms.LoginForms import DelayedLoginForm

from .utils import sleep_and_log_then_continue

NOWUUSER = get_user_model()


class SuccessfulLoginPage(View): #TODO: remove and replace with real redirect page


    def get(self, request):
        if request.user.is_authenticated():
            try:
                social_user = UserSocialAuth.objects.filter(user=request.user)[0]
                social_token = social_user.extra_data['access_token']
                return HttpResponse('User IS authenticated<br/>' + str(request.user.email) + '<br/>access_token: ' + social_token)
            except Exception:
                return HttpResponse('User IS authenticated<br/>' + str(request.user.email))
        else:
            return HttpResponse('User is NOT authenticated')

class DelayedLogin(FormView):

    template_name = 'users/login.html'
    form_class = DelayedLoginForm
    success_url = '/register/successful-login-page/'

    def get(self, request):
        """We are redoing get here so we can check some extra stuff and do things the boomers way"""
        #if a user authenticated via a social network they stay logged even if they logged out
        #of the social network.
        if request.user.is_authenticated():
            #Just succeed them.
            return HttpResponseRedirect(self.success_url)

        context = {}
        context['redirect_to_url'] = self.success_url
        try:
            redirect_src = request.GET['src']
            if redirect_src == 'my-account':
                context['redirect_message'] = 'You must log in to view your account page.'
                context['redirect_to_url'] = '/register/my-account/'
        except Exception:
            pass
        return django_builtin_login.login(request, template_name='users/login.html', extra_context=context)

    def form_valid(self, form):
        """If our post is valid do some extra checking then log our person in"""

        allow = sleep_and_log_then_continue(self.request, 'login_attempt', form.cleaned_data['username'])

        #What are they doing here?
        if self.request.user.is_authenticated():
            return HttpResponse('You are already logged in.')

        if not allow:
            return HttpResponse(settings.THROTTLE_MESSAGE)

        return form.validate_login(self.request)
