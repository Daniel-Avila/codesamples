# -*- coding: utf-8 -*-

from __future__ import absolute_import, division

import uuid
from datetime import datetime

from django import forms
from django.contrib import admin
from django.contrib.auth.admin import UserAdmin
from django.contrib.auth.forms import ReadOnlyPasswordHashField
from django.contrib.auth.models import Group, User
from django.forms.widgets import PasswordInput

from boomers.apps.users.models import NowUUser
from .forms.NewUserForm import NewUserForm

from django.http import HttpResponseRedirect
from boomers.apps.users.utils import get_client_ip
import logging
logger2=logging.getLogger('Audit_Logger')
from .forms.NewUserForm import NewUserForm


# Register your models here.


class UserCreationForm(NewUserForm):
    """Our user Creation form"""

    class Meta:
        widgets = {
            'password': PasswordInput,
            'password2': PasswordInput,
        }

    def __init__(self, *args, **kwargs):
        super(UserCreationForm, self).__init__(*args, **kwargs)

    def save_m2m(self):
        pass

    def save(self, commit=True):
        """Make a user and save it to the DB"""
        user = super(UserCreationForm, self).save(commit=True)
        return user

class UserChangeForm(forms.ModelForm):
    """In case we have to change our user"""

    password = ReadOnlyPasswordHashField()

    class Meta:
        model = NowUUser
        fields = ('email', 'password')

    def clean_password(self):
        """The field does not have access to the initial value"""

        return self.initial['password']

def reset_password(modeladmin, request, queryset):
    logger2.info('[%s][CSR=%s][CSR IP=%s][Action=ResetPassword][UserEmail=%s]',
        datetime.now(), request.user,get_client_ip(request), queryset[0].email)
    return HttpResponseRedirect('/register/forgotten-password?q='+queryset[0].email)

class NowUUserAdmin(UserAdmin):

    form = UserChangeForm
    add_form = UserCreationForm
    filter_horizontal = ('groups',)
    readonly_fields = ('atypon_user_id', 'has_active_subscription', )

    list_display = ('atypon_user_id', 'email', 'metering_group', 'is_staff','is_csr',
                    'is_superuser', 'has_active_subscription',)

    fieldsets = (
                    (None, {'fields': ('atypon_user_id', 'email', 'password', 'metering_group', 'verification_code',
                                       'is_verified', 'is_active', 'is_staff','is_csr', 'is_superuser',
                                       'has_active_subscription', 'profile_pic', 'login_method', 'payment_paypal',
                                       'payment_amazon')}),
                )

    add_fieldsets = (
                        (None, {
                                'classes': (),

                                'fields':('email', 'password', 'password2','is_csr','is_staff'),
                               }
                        ),
                    )
    actions= [reset_password]
    search_fields = ('email',)

    ordering = ('email', 'verification_code', 'is_verified', 'is_active', 'is_staff', 'is_superuser',
                'profile_pic', 'login_method', 'payment_paypal', 'payment_amazon')


admin.site.register(NowUUser, NowUUserAdmin)
