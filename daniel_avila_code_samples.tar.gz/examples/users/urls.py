# -*- coding: utf-8 -*-

from __future__ import absolute_import, division

from django.conf.urls import patterns, url

from boomers.apps.users import views

urlpatterns = patterns('',
    url(r'^$', views.index),
    url(r'^new-user/$', views.NewUser.as_view(), name='new_user'),
    url(r'^new-user/confirm-email/(?P<email_address>.[^/]+)/(?P<verification_code>[A-Za-z0-9]{32})/', views.ConfirmEmail.as_view(), name='confirm_email'),
    url(r'^new-user/resend-verification-email/(?P<email_address>.[^/]+)/', views.ResendVerificationEmail.as_view(), name='resend_verification_email'),
    url(r'^reset-password/', views.ResetPassword.as_view(), name='reset_password'),
    url(r'^forgotten-password/', views.ForgottenPassword.as_view(), name='forgotten_password'),
    url(r'^forgotten-password-reset/(?P<email_address>.[^/]+)/(?P<verification_code>[A-Za-z0-9]{32})/', views.ForgottenPasswordReset.as_view(), name='forgotten_password_reset'),
    url(r'^reset-email/', views.ChangeEmail.as_view(), name='reset_email_post'),
    url(r'^reset-email/(?P<old_email_address>.[^/]+)/(?P<new_email_address>.[^/]+)/(?P<verification_code>[A-Za-z0-9]{32})/', views.ChangeEmail.as_view(), name='reset_email'),
    url(r'^successful-login-page/', views.SuccessfulLoginPage.as_view(), name='successful_login_page'), #TODO: remove/replace with real redirect
    url(r'^login/$', views.DelayedLogin.as_view(), name='delayed_login'),
    url(r'^my-account/$', views.MyAccount.as_view(), name='my_account'),
    url(r'^change-subscription-type/$', views.ChangeSubscriptionType.as_view(), name='change_subscription_type'),
    url(r'^cancel-account/$', views.CancelAccount.as_view(), name='cancel_account'),
    url(r'^logout/$', 'django.contrib.auth.views.logout', {'next_page': '/'}),
    url(r'^toggle-email-prefs/$', views.toggle_email_prefs, name='toggle_email_prefs'),
    url(r'^toggle-newsletter-prefs/$', views.toggle_newsletter_prefs, name='toggle_newsletter_prefs'),
    url(r'^upload-pic/(?P<upload_type>[\w]+)/$', views.upload_pic, name='upload_pic'),
    url(r'^delete-pic/(?P<pic_id>.[^/]+)/', views.delete_pic, name='delete_pic'),

    # social
    url(r'^facebook-logged-in/$', views.FacebookLoggedIn.as_view(), name='facebook_logged_in'),
    url(r'^google-logged-in/$', views.GoogleLoggedIn.as_view(), name='google_logged_in'),
)
