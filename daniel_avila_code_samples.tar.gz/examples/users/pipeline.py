def get_fb_access_token(strategy, request, response, *args, **kwargs):
    request.session['fb_access_token'] = response['access_token']
