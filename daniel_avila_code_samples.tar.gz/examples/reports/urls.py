from django.conf.urls import url
from .views import (collision_report,
                    finalized_report,
                    generic_reports,
                    match_report,
                    participation_report,
                    report_dashboard,
                    duplicate_report)

urlpatterns = [
    url(r'^$', report_dashboard.ReportsDashboardView.as_view()),
    url(r'^final/view/$', generic_reports.FinalReportView.as_view()),
    url(r'^matched/finalize/$', finalized_report.FinalizeView.as_view()),
    url(r'^collisions/view/$', collision_report.CollisionReportView.as_view()),
    url(r'^duplicates/view/$', duplicate_report.DuplicateReportView.as_view()),
    url(r'^matched/view/$', match_report.MatchedReportView.as_view()),
    url(r'^participation/view/$', participation_report.ParticipationReportView.as_view()),
    url(r'^participation/pdf/$', participation_report.ParticipationReportPDF.as_view()),
    url(r'^pending/view/$', generic_reports.PendingReportView.as_view()),
    url(r'^orphan/view/$', generic_reports.OrphanReportView.as_view()),
]
