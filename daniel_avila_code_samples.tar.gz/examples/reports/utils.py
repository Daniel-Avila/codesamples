from transactions.models import (BaseMemberTransaction, Year,
                                 InterAreaTransaction, IntraAreaTransaction, MemberIntraAreaTransaction,
                                 MemberInterAreaTransaction)


def get_all_matching(which_state, year=None, org=None):
    data = {'year': Year.objects.get(current=True), 'state': which_state}
    if org is not None:
        data['member_entity'] = org
    records = []
    for klass in BaseMemberTransaction.get_subclasses():
        records += klass.objects.filter(**data)
    pairs = []
    for r in records:
        if [r, r.get_matching] in pairs or [r.get_matching, r] in pairs:
            pass
        else:
            pairs.append([r, r.get_matching])
    return pairs


def get_all_duplicates(org=None):
    duplicates = []
    duplicates += _get_master_inter_duplicates(org=org)
    duplicates += _get_master_intra_duplicates(org=org)

    duplicates += _get_member_inter_duplicates(org=org)
    duplicates += _get_member_intra_duplicates(org=org)

    return duplicates


def compare_series(record, candidate):
    if [x['data'] for x in record.series_data] == [x['data'] for x in candidate.series_data]:
        return True
    return False


def _get_master_intra_duplicates(org=None):
    current_year = Year.objects.get(current=True)
    data = {'year': current_year, 'count_id__gt': 1}
    if org is not None:
        data['member_entity'] = org
    master_intras = IntraAreaTransaction.objects.values('pk',
                                                        'from_area_id',
                                                        'to_area_id',
                                                        'oasis_number',
                                                        'plant',
                                                        'comments',
                                                        'capacity').filter(year=current_year)
    master_intra_dups = []
    for rec in master_intras:

        if IntraAreaTransaction.objects.filter(from_area__id=rec['from_area_id'],
                                               oasis_number=rec['oasis_number'],
                                               capacity=rec['capacity'],
                                               comments=rec['comments'],
                                               plant=rec['plant'],
                                               year=current_year,
                                               to_area__id=rec['to_area_id']).count() > 1:

            records = IntraAreaTransaction.objects.filter(from_area__id=rec['from_area_id'],
                                                          oasis_number=rec['oasis_number'],
                                                          plant=rec['plant'],
                                                          comments=rec['comments'],
                                                          capacity=rec['capacity'],
                                                          year=current_year,
                                                          to_area__id=rec['to_area_id'])
            rec_object = IntraAreaTransaction.objects.get(pk=rec['pk'])
            for candidate in records:
                if rec_object.id == candidate.id:
                    continue
                if compare_series(rec_object, candidate):
                    if not [rec_object, candidate] in master_intra_dups or not [candidate, rec_object] in master_intra_dups:
                        master_intra_dups.append([rec_object, candidate])

    return master_intra_dups


def _get_master_inter_duplicates(org=None):
    current_year = Year.objects.get(current=True)
    data = {'year': current_year, 'count_id__gt': 1}
    if org is not None:
        data['member_entity'] = org
    master_inters = InterAreaTransaction.objects.values('from_area_id',
                                                        'to_area_id',
                                                        'oasis_number',
                                                        'comments',
                                                        'plant',
                                                        'capacity',
                                                        'transaction_id').filter(year=current_year)
    master_inter_dups = []
    for rec in master_inters:

        if InterAreaTransaction.objects.filter(from_area__id=rec['from_area_id'],
                                               oasis_number=rec['oasis_number'],
                                               capacity=rec['capacity'],
                                               comments=rec['comments'],
                                               plant=rec['plant'],
                                               year=current_year,
                                               to_area__id=rec['to_area_id'],
                                               transaction_id=rec['transaction_id']).count() > 1:

            records = list(InterAreaTransaction.objects.filter(from_area__id=rec['from_area_id'],
                                                               oasis_number=rec['oasis_number'],
                                                               comments=rec['comments'],
                                                               capacity=rec['capacity'],
                                                               plant=rec['plant'],
                                                               year=current_year,
                                                               to_area__id=rec['to_area_id'],
                                                               transaction_id=rec['transaction_id']))
            if not records in master_inter_dups:
                master_inter_dups.append(list(records))

    return master_inter_dups


def _get_member_intra_duplicates(org=None):
    current_year = Year.objects.get(current=True)
    data = {'year': current_year, 'count_id__gt': 1}
    if org is not None:
        data['member_entity'] = org
    master_inters = MemberIntraAreaTransaction.objects.values('from_area_id',
                                                              'to_area_id',
                                                              'plant',
                                                              'oasis_number',
                                                              'comments',
                                                              'capacity').filter(year=current_year)
    master_inter_dups = []
    for rec in master_inters:

        if MemberIntraAreaTransaction.objects.filter(from_area__id=rec['from_area_id'],
                                                     oasis_number=rec['oasis_number'],
                                                     capacity=rec['capacity'],
                                                     plant=rec['plant'],
                                                     comments=rec['comments'],
                                                     year=current_year,
                                                     to_area__id=rec['to_area_id']).count() > 1:

            records = list(MemberIntraAreaTransaction.objects.filter(from_area__id=rec['from_area_id'],
                                                                     oasis_number=rec['oasis_number'],
                                                                     comments=rec['comments'],
                                                                     plant=rec['plant'],
                                                                     capacity=rec['capacity'],
                                                                     year=current_year,
                                                                     to_area__id=rec['to_area_id']))
            if not records in master_inter_dups:
                master_inter_dups.append(list(records))

    return master_inter_dups


def _get_member_inter_duplicates(org=None):
    current_year = Year.objects.get(current=True)
    data = {'year': current_year, 'count_id__gt': 1}
    if org is not None:
        data['member_entity'] = org
    master_inters = MemberInterAreaTransaction.objects.values('from_area_id',
                                                              'to_area_id',
                                                              'oasis_number',
                                                              'comments',
                                                              'plant',
                                                              'capacity',
                                                              'transaction_id').filter(year=current_year)
    master_inter_dups = []
    for rec in master_inters:

        if MemberInterAreaTransaction.objects.filter(from_area__id=rec['from_area_id'],
                                                     oasis_number=rec['oasis_number'],
                                                     capacity=rec['capacity'],
                                                     comments=rec['comments'],
                                                     plant=rec['plant'],
                                                     year=current_year,
                                                     to_area__id=rec['to_area_id'],
                                                     transaction_id=rec['transaction_id']).count() > 1:

            records = list(MemberInterAreaTransaction.objects.filter(from_area__id=rec['from_area_id'],
                                                                     oasis_number=rec['oasis_number'],
                                                                     comments=rec['comments'],
                                                                     capacity=rec['capacity'],
                                                                     plant=rec['plant'],
                                                                     year=current_year,
                                                                     to_area__id=rec['to_area_id'],
                                                                     transaction_id=rec['transaction_id']))
            if not records in master_inter_dups:
                master_inter_dups.append(list(records))

    return master_inter_dups
