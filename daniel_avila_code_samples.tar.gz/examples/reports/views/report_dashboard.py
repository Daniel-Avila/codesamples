from django.shortcuts import render

from common.views.dashboard_view import BaseDashboardView


class ReportsDashboardView(BaseDashboardView):

    template = 'reports/dashboard.html'
    http_method_names = ['get']

    def get_navigation(self, user):

        return []

    def get(self, request):
        nav = self.get_navigation(request.user)
        return render(request, self.template, {'navigation': nav})
