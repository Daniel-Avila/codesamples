from django.shortcuts import render
from django.views.generic import View
from wkhtmltopdf.views import PDFTemplateResponse

from common.views.dashboard_view import BaseDashboardView
from contacts.models.organization import Organization
from transactions.models import BaseMemberTransaction


class ParticipationReportView(BaseDashboardView):

    template = 'reports/participation_report.html'
    http_method_names = ['get']

    def get(self, request):

        sub_klasses = BaseMemberTransaction.get_subclasses()
        expected_members = Organization.objects.filter(is_member=True, is_active=True)
        report_data = []
        for org in expected_members:
            count = 0
            for klass in sub_klasses:
                count += klass.objects.filter(member_entity=org).count()
            report_data.append({'org': org, 'uploaded': count})

        return render(request, self.template, {'members': report_data})


class ParticipationReportPDF(View):
    filename = 'participation_report.pdf'
    template = 'reports/participation_pdf.html'

    def get(self, request, *args, **kwargs):

        sub_klasses = BaseMemberTransaction.get_subclasses()
        expected_members = Organization.objects.filter(is_member=True, is_active=True)
        report_data = []
        for org in expected_members:
            count = 0
            for klass in sub_klasses:
                count += klass.objects.filter(member_entity=org).count()
            report_data.append({'org': org, 'uploaded': count})
        context = {'members': report_data}
        response = PDFTemplateResponse(request,
                                       self.template,
                                       filename =self.filename,
                                       context=context,
                                       show_content_in_browser=False)
        return response
