from django.core.paginator import EmptyPage, Paginator
from django.core.paginator import PageNotAnInteger
from django.shortcuts import render

from common.views.dashboard_view import BaseDashboardView
from contacts.models.organization import Organization
from reports.utils import get_all_duplicates
from transactions.models import ColumnNames, Year


class DuplicateReportView(BaseDashboardView):

    template = 'reports/duplicate_report.html'
    http_method_names = ['get']
    which_state = 'collision'

    def get(self, request, org=None):

        year = Year.objects.get(current=True).id

        try:
            org = int(request.GET.get('org'))
        except ValueError:
            org = None
        except TypeError:
            org = None

        records = get_all_duplicates(org=org)
        series_row = ColumnNames.objects.get(year__current=True).get_series_names

        paginator = Paginator(records, 30)

        page = request.GET.get('page')
        try:
            pairs = paginator.page(page)
        except PageNotAnInteger:
            pairs = paginator.page(1)
        except EmptyPage:
            pairs = paginator.num_pages
        organizations = Organization.objects.filter(is_active=True).order_by('code')

        data = {'year': year,
                'transactions': records,
                'series_row': series_row,
                'organizations': organizations,
                'current': org}

        return render(request, self.template, data)

