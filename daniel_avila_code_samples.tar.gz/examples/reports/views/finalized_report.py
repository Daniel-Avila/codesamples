from django.shortcuts import redirect
from django.views.generic import View

from transactions.models import MemberIntraAreaTransaction
from transactions.models import MemberInterAreaTransaction


class FinalizeView(View):

    def post(self, request):
        for data in request.POST.getlist('finalize'):
            id, trans_type = data.split('_')
            if trans_type == 'minter':
                trans = MemberInterAreaTransaction.objects.get(id=int(id))
            elif trans_type == 'mintra':
                trans = MemberIntraAreaTransaction.objects.get(id=int(id))
            match = trans.get_matching
            trans.commit()
            match.commit()

        return redirect('/reports/matched/view/')