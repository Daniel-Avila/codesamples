from reports.views.base_view import GenericReportView


class OrphanReportView(GenericReportView):
    template = 'reports/orphan_report.html'
    which_state = 'orphan'


class PendingReportView(GenericReportView):

    template = 'reports/pending_report.html'
    which_state = 'pending'


class FinalReportView(GenericReportView):

    template = 'reports/final_report.html'
    which_state = 'committed'


