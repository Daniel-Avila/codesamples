from django.core.paginator import EmptyPage, Paginator
from django.core.paginator import PageNotAnInteger
from django.shortcuts import render

from common.views.dashboard_view import BaseDashboardView
from contacts.models.organization import Organization
from transactions.models import ColumnNames, BaseMemberTransaction, Year


class GenericReportView(BaseDashboardView):
    template = None
    http_method_names = ['get']
    which_state = None

    def get(self, request):
        org_id = request.GET.get('org')
        year = Year.objects.get(current=True)
        sub_klasses = BaseMemberTransaction.get_subclasses()
        transactions = []
        filter = {'year': year, 'state': self.which_state}
        if org_id:
            filter['member_entity'] = Organization.objects.get(id=int(org_id))
        for klass in sub_klasses:
            transactions = transactions + list(klass.objects.filter(**filter).order_by('id'))
        organizations = Organization.objects.filter(is_member=True, is_active=True).order_by('code')
        try:
            series_row = ColumnNames.objects.get(year__current=True).get_series_names
        except ColumnNames.DoesNotExist:
            series_row = []
        paginator = Paginator(transactions, 30)
        page = request.GET.get('page')
        try:
            transactions = paginator.page(page)
        except PageNotAnInteger:
            transactions = paginator.page(1)
        except EmptyPage:
            transactions = paginator.num_pages

        data = {'year': year,
                'organizations': organizations,
                'transactions': transactions,
                'series_row': series_row}

        return render(request, self.template, data)
