from django import forms

from transactions.models import Year, ColumnNames


class YearForm(forms.ModelForm):

    class Meta:
        model = Year
        fields = ['current', 'year']


class ColumnsForm(forms.ModelForm):

    class Meta:
        model = ColumnNames
        fields = ['series_columns', 'year']
