from django import forms 
from transactions.models import SeriesElement, Year, InterAreaTransaction, IntraAreaTransaction, NetTransaction
from contacts.models.organization import Organization
orgs = Organization.objects.filter(is_active=True).order_by('code')
years = Year.objects.all()


class IntraAreaTransactionForm(forms.ModelForm):
    class Meta:
        model = IntraAreaTransaction
        exclude = ['match_type', 'year', 'matching_record']


class InterAreaTransactionForm(forms.ModelForm):

    class Meta:
        model = InterAreaTransaction
        exclude = ['match_type', 'year', 'matching_record']


class NetTransactionForm(forms.ModelForm):

    class Meta:
        model = NetTransaction
        exclude = ['match_type']


class SeriesElementForm(forms.ModelForm):

    class Meta:
        model = SeriesElement
        fields = ['data', 'series', 'object_id', 'content_type']