import string
from django.conf import settings
from django.contrib.contenttypes.models import ContentType
from django.test import TestCase
from model_mommy import mommy

from transactions.copy_utils import invert_transaction
from transactions.models import MemberIntraAreaTransaction, IntraAreaTransaction, Year
from transactions.series_element import SeriesElement
from transactions.utils import match_series


class TestInverts(TestCase):

    def setUp(self):
        self.year = mommy.make(Year, current=True)
        self.master_intra = mommy.make(IntraAreaTransaction, year=self.year)
        self.master_match = mommy.make(IntraAreaTransaction, year=self.year, matching_record=self.master_intra.id)
        self.master_intra.matching_record = self.master_match.id
        self.master_intra.save()
        self.member_intra = mommy.make(MemberIntraAreaTransaction, year=self.year, master_record=self.master_intra.id)
        content_type = ContentType.objects.get(model=self.member_intra._meta.model_name)
        for i in range(20):
            mommy.make(SeriesElement, object_id=self.member_intra.id, content_type=content_type, data=i, series=string.ascii_lowercase[i])

    def test_invert_intra(self):

        invert_transaction(self.member_intra)

        self.assertEqual(MemberIntraAreaTransaction.objects.all().count(), 2)
        self.assertEqual(SeriesElement.objects.all().count(), 40)
        records = MemberIntraAreaTransaction.objects.all()
        self.assertTrue(match_series(records[0], records[1]))
        self.assertEqual(records[0].state, settings.FSM_STATE['matched'])
        self.assertEqual(records[1].state, settings.FSM_STATE['matched'])
        self.assertEqual(records[0].matching_record, records[1].id)
        self.assertEqual(records[1].matching_record, records[0].id)
