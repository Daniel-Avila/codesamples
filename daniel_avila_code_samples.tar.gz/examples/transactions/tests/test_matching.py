from django.test import TestCase
from django.core.management import call_command
from django.conf import settings
from openpyxl import load_workbook
from model_mommy import mommy
from contacts.models.organization import Organization
from transactions.models import Year, IntraAreaTransaction, InterAreaTransaction

from transactions.master_utils import (_match_inter, _match_intra,
                                       convert_record_to_dict,
                                       ContentType, process_inter_area_transaction,
                                       process_intra_area_transaction,
                                       make_series, make_matches, _insert_series)
from transactions.utils import verify_series_data, calc_headers
import os
import sys


class TestMatchingFunctions(TestCase):


    def setUp(self):
        self.header_row = "16G,16S,16SH,16F,16W,17L,17G,17S,17SH,17F,17W,18G,18S,18W,21L,21S,21W,26S,26W".split(',')
        self.year = mommy.make(Year, current=True)
        target = "{0}/fixtures/initial_orgs".format(os.path.dirname(os.path.realpath(__file__)))
        call_command('loaddata', target)

    def test_make_matches(self):
        '''Are we making the matches correctly?'''
        target = "{0}/new_book.xlsx".format(os.path.dirname(os.path.realpath(__file__)))
        #target = "{0}/weird_test.xlsx".format(os.path.dirname(os.path.realpath(__file__)))

        with open(target, 'r+b') as test_file:
            indexes = settings.WORKBOOK_INDEX['legacy_index']
            legacy = True
            year = self.year
            header_row = self.header_row
            records = load_workbook(test_file).get_sheet_by_name('Transactions')
            headers, raw_headers, series_start, start = calc_headers(records, self.header_row)
            end = len(headers) - 1
            for record in records.rows[4:]:
                if record[0].value == 'END':
                    break
                result = verify_series_data(record, start, end)
                self.assertTrue(result)
            rel_ref_idx = start - 1
            series_records = []
            errors = []
            for raw_record in records.rows[4:]:
                if str(raw_record[0].value).lower() == 'end':
                    break
                record = convert_record_to_dict(raw_record, raw_headers, series_start)
                try:
                    try:
                        from_org = Organization.objects.get(area_owner=record['from_area_number'],
                                                            code=record['from_area_code'].strip())
                        if not from_org.is_member:
                            continue

                    except Organization.DoesNotExist:
                        message = "From Area Organization does not exist in database. Row {0} Organization {1}:{2}".format(
                            raw_record[0].row, record['from_area_number'], record['from_area_code'])
                        errors.append({'message': message})
                        continue
                    if record['to_area_code'].strip() != 'NET':
                        try:
                            to_org = Organization.objects.get(area_owner=record['to_area_number'],
                                                              code=record['to_area_code'].strip())
                        except Organization.DoesNotExist:
                            message = "To Area Organization does not exist in database. Row {0} Organization {1}:{2}".format(
                                raw_record[0].row, record['from_area_number'], record['from_area_code'])
                            errors.append({'message': message})
                            continue

                    if record['transaction_id'] is not None:

                        content_type_id = ContentType.objects.get(model=InterAreaTransaction._meta.model_name).id
                        record, o_id = process_inter_area_transaction(record, indexes, legacy, year, from_org, to_org,
                                                                      rel_ref_idx)
                        series_records += make_series(start, end, header_row, content_type_id, o_id, raw_record)

                    if record['transaction_id'] is None and record['to_area_code'] != 'NET':
                        content_type_id = ContentType.objects.get(model=IntraAreaTransaction._meta.model_name).id
                        record, o_id = process_intra_area_transaction(record, indexes, legacy, year, from_org, to_org,
                                                                      rel_ref_idx)
                        series_records += make_series(start, end, header_row, content_type_id, o_id, raw_record)
                except Exception as ex:
                    message = sys.exc_info()[1].args[0]
                    error = '%s (%s) Triggerd by row %s --> values (%s)' % (message, type(ex), raw_record[0].row,
                                                                         [(name, value) for name, value in record.items()])
                    errors.append({'message': error})
            if errors:
                self.fail(errors)
            else:
                _insert_series(series_records)
            ##  Code under test

            result = _match_intra(self.year)
            self.assertEqual(len(result), 0)
