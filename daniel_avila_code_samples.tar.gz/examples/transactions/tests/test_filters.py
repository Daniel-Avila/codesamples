from django.test import TestCase
from django.conf import settings

from model_mommy import mommy

from contacts.models.organization import Organization
from transactions.transaction_tests import verify_areas, verify_master_areas


class foo(object):
    def __init__(self, value, row):
            self.value = value
            self.row = row


class bar(object):
    def __init__(self):
        self.rows = [[], [], [], []]

    def add_row(self, row):
        self.rows.append(row)


class TestFilters(TestCase):

    def tearDown(self):
        Organization.objects.all().delete()

    def test_verify_areas(self):
        """Do we return a valid error if the organization is not in the database?"""
        expected = [{'message': 'To Area Organization.DoesNotExist row -> 1 1:b'}]
        test_data = [foo(1, 1), foo(1, 1), foo('a', 1), foo(1, 1), foo('b', 1)]
        b = bar()
        b.add_row(test_data)
        result = verify_areas(b, 1, settings.WORKBOOK_INDEX['legacy_index'])
        self.assertListEqual(expected, result)

    def test_verify_areas_valid(self):
        """Make sure we get a valid result with data"""
        mommy.make(Organization, code='foo', area_owner=1)
        mommy.make(Organization, code='bar', area_owner=2)
        test_data = [foo('1', 1), foo('1', 1), foo('foo', 1), foo('2', 1), foo('bar', 1)]
        b = bar()
        b.add_row(test_data)
        result = verify_areas(b, 1, settings.WORKBOOK_INDEX['legacy_index'])
        self.assertEqual([], result)

    def test_verify_master_areas(self):
        """Make sure we get a valid result with data"""
        mommy.make(Organization, code='foo', area_owner=1)
        mommy.make(Organization, code='bar', area_owner=2)
        test_data = [foo('1', 1), foo('1', 1), foo('foo', 1), foo('2', 1), foo('bar', 1)]
        b = bar()
        b.add_row(test_data)
        result = verify_master_areas(b, settings.WORKBOOK_INDEX['legacy_index'])
        self.assertEqual([], result)

    def test_verify_master_areas_error(self):
        """Make sure we get a valid result with data"""
        expected = [{'message': 'To Area Organization.DoesNotExist row -> 1 2:bar'},
                    {'message': 'From Area Organization.DoesNotExist row -> 1 1:foo'}]
        test_data = [foo('1', 1), foo('1', 1), foo('foo', 1), foo('2', 1), foo('bar', 1)]
        b = bar()
        b.add_row(test_data)
        result = verify_master_areas(b, settings.WORKBOOK_INDEX['legacy_index'])
        self.assertEqual(expected, result)
