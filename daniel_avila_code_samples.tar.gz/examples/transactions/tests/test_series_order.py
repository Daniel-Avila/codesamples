import random

from django.contrib.contenttypes.models import ContentType
from django.test import TestCase
from model_mommy import mommy
from transactions.models import SeriesElement, InterAreaTransaction
from transactions.forms.transactions import SeriesElementForm
from transactions.member_utils import order_element_forms


class TestSeriesElements(TestCase):

    def setUp(self):

        self.transaction = mommy.make(InterAreaTransaction)
        self.expected_order = ['15G', '15S','15SH','15F','15W','16L', '16G', '16S', '16SH', '16F', '16W', '17G', '17S',
                               '17W', '20L', '20S', '20W', '25S', '25W']

        content_type = ContentType.objects.get(model='interareatransaction')
        object_id = self.transaction.id
        for series in self.expected_order:
            mommy.make(SeriesElement, content_type=content_type, object_id=object_id, series=series)

    def test_sort_order(self):

        series_objs = self.transaction.series_objects

        forms = []
        for obj in series_objs:
            f = SeriesElementForm(None, instance=obj)
            f.is_valid()
            forms.append(f)
        random.shuffle(forms)
        result = order_element_forms(forms)
        for i in range(len(self.expected_order)):

            self.assertEqual(result[i].instance.series, self.expected_order[i])

