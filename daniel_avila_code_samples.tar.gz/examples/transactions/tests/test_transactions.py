from django.contrib.auth.models import User
from django.test import TestCase, Client
from model_mommy import mommy
from transactions import models as tm


class TestInterAreaTransactions(TestCase):

    def setUp(self):
        self.transaction = mommy.make(tm.InterAreaTransaction)
        self.user = self.user = User.objects.create_user(
                username='jacob', email='jacob@localhost', password='top_secret')
        self.client = Client()

    def test_edit(self):
        """Can we get the edit form for an interarea transaction from the web"""
        self.client.login(username='jacob', password='top_secret')
        response = self.client.get('/transactions/inter/edit/{0}/'.format(self.transaction.id))
        self.assertEqual(response.status_code, 200)

    def test_logged_in_edit(self):
        """Do we redirect those who are not logged in?"""
        response = self.client.get('/transactions/inter/edit/{0}/'.format(self.transaction.id))
        self.assertEqual(response.status_code, 302)


class TestIntraAreaTransactions(TestCase):
    def setUp(self):
        self.transaction = mommy.make(tm.IntraAreaTransaction)
        self.user = self.user = User.objects.create_user(
                username='jacob', email='jacob@localhost', password='top_secret')
        self.client = Client()

    def test_edit(self):
        """Can we get the edit form for an interarea transaction from the web"""
        self.client.login(username='jacob', password='top_secret')
        response = self.client.get('/transactions/intra/edit/{0}/'.format(self.transaction.id))
        self.assertEqual(response.status_code, 200)

    def test_logged_in_edit(self):
        """Do we redirect those who are not logged in?"""
        response = self.client.get('/transactions/intra/edit/{0}/'.format(self.transaction.id))
        self.assertEqual(response.status_code, 302)


class TestNetAreaTransactions(TestCase):

    def setUp(self):
        self.transaction = mommy.make(tm.NetTransaction)
        self.user = self.user = User.objects.create_user(
                username='jacob', email='jacob@localhost', password='top_secret')
        self.client = Client()

    def test_edit(self):
        """Can we get the edit form for an interarea transaction from the web"""
        self.client.login(username='jacob', password='top_secret')
        response = self.client.get('/transactions/net/edit/{0}/'.format(self.transaction.id))
        self.assertEqual(response.status_code, 200)

    def test_logged_in_edit(self):
        """Do we redirect those who are not logged in?"""
        response = self.client.get('/transactions/net/edit/{0}/'.format(self.transaction.id))
        self.assertEqual(response.status_code, 302)
