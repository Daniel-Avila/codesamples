import os
from django.test import TestCase
from transactions.utils import calc_indexes, convert_record_to_dict

from openpyxl import load_workbook
import datetime


class TestUtilities(TestCase):

    def test_calc_indexes(self):
        header = ['a0', 'a1', 'a2', 'a3', 'a4', 'a5', 'b6', 'b7', 'b8']
        legacy = True
        start = 6

        class foo(object):
            def __init__(self, data):
                self.value = data
        raw_row = [foo('a0'), foo(None), foo('a1'), foo(None), foo('a2'), foo(None), foo('a3'),
                   foo(None), foo('a4'), foo(None), foo('a5'), foo(None), foo('b6'), foo(None),
                   foo('b7'), foo(None), foo('b8')]
        expected = {'a0': 0, 'a1': 2, 'a2':4, 'a3':6, 'a4':8, 'a5':10, 'b6':12, 'b7':14, 'b8':16}
        result = calc_indexes(header, raw_row, start, legacy)
        self.assertEqual(result, expected)

    def test_convert_record_to_dict(self):
        target = "{0}/BalkoWindLLC.xlsx".format(os.path.dirname(os.path.realpath(__file__)))

        with open(target, 'r+b') as test_file:
            records = load_workbook(test_file).get_sheet_by_name('Transactions')
            header_row = ['15G', '15S', '15SH', '15F', '15W', '16L',
                          '16G', '16S', '16SH', '16F', '16W', '17G',
                          '17S', '17W', '20L', '20S', '20W', '25S', '25W']
            raw_headers = [x.value.strip() for x in records.rows[3]]
            series_start = raw_headers.index(header_row[0])
            record = records.rows[4]
            expected = {'oasis': None, 'from_region': 'SPP', 'capacity': 30, 's0_scalable': 'YES',
                        'roll_over_rights': 'YES',
                        'comments': 'Cities of Sharon Springs, St. Francis, Oberlin and Goodland',
                        'plant': None, 'stop': datetime.datetime(2041, 5, 31, 0, 0),
                        'to_area_code': 'TRANSOURCE', 'oasis_number': 78239132, 'link_no': None,
                        'start': datetime.datetime(2013, 5, 31, 0, 0), 'from_area_number': 534, 'related_ref': None,
                        's5_scalable': 'YES', 'to_area_number': 534, 'transaction_id': 1,
                        'firm': None, 'from_area_code': 'BALKO'}

            result = convert_record_to_dict(record, raw_headers, series_start)
            self.assertDictEqual(expected, result)
