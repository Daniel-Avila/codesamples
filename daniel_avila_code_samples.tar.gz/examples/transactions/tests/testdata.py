# BTW these happen to constitute a matching transaction
test_records = [
['SPP', '534', 'SUNC', '534', 'KMEAEMP2.SUNC', '', '78239132', '', '', '5/31/2013', '5/31/2041', '30.0', 'YES', 'YES', 'YES', '', 'Cities of Sharon Springs', 'St. Francis', 'Oberlin and Goodland', '', '', '30', '30', '30', '30', '30', '6', '30', '30', '30', '30', '30', '30', '30', '30', '7', '30', '30', '30', '30'],
['SPP', '534', 'KMEAEMP2.SUNC', '534', 'SUNC', '', '78239132', '', '', '5/31/2013', '5/31/2041', '-30.0', 'YES', 'YES', 'YES', '', 'Cities of Sharon Springs', 'St. Francis', 'Oberlin and Goodland', '', '', '-30', '-30', '-30', '-30', '-30', '-6', '-30', '-30', '-30', '-30', '-30', '-30', '-30', '-30', '-7', '-30', '-30', '-30', '-30']
]
