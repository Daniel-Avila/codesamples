class UploadException(Exception):
    def __init__(self, message, errors):

        super(UploadException, self).__init__(message)
        self.errors = errors
