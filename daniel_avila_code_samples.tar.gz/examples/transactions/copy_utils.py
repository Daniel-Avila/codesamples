import json

from django.conf import settings
from django.contrib.contenttypes.models import ContentType
from django.core import serializers
from django.db import transaction
from contacts.models.organization import Organization
from transactions.series_element import SeriesElement


def _copy_to_master(member_instance, content_model):
    with transaction.atomic():
        mst_instance = content_model.objects.get(id=member_instance.master_record)
        member_series_objects = member_instance.series_objects

        # first we try to find our inverse matching record in the master workbook tables
        if mst_instance.matching_record > 0: # it has a match in the master workbook
            mst_match = content_model.objects.get(matching_record=mst_instance.id)
        # We know we don't have a match so we have to create our inverse in the master database.
        else:
            orig_pk = mst_instance.pk
            mst_match = mst_instance
            mst_match.pk = None
            mst_match.matching_record = mst_instance.pk
            mst_match.from_area = mst_instance.to_area
            mst_match.to_area = mst_instance.from_area
            mst_match.save()
            mst_instance = content_model.objects.get(id=orig_pk)

        # Now we update the data on the match This is all we have to do for our match record since
        # by definition we do not have a member transaction for this.

        for series_obj in member_series_objects:

            mst_inst_elm = SeriesElement.objects.get(series=series_obj.series,
                                                     content_type__model=mst_instance._meta.model_name,
                                                     object_id=mst_instance.id)
            try:
                mst_mtc_elm = SeriesElement.objects.get(series=series_obj.series,
                                                        content_type__model=mst_match._meta.model_name,
                                                        object_id=mst_match.id)
            except SeriesElement.DoesNotExist:
                c_type = ContentType.objects.get(model=mst_match._meta.model_name)

                mst_mtc_elm = SeriesElement.objects.create(series=series_obj.series,
                                                           data=0,
                                                           content_type=c_type,
                                                           object_id=mst_match.id)
            mst_inst_elm.data = series_obj.data
            mst_inst_elm.save()
            mst_mtc_elm.data = -1 * series_obj.data
            mst_mtc_elm.save()


def invert_transaction(member_instance):

    fields = json.loads(serializers.serialize('json', [member_instance]))[0]['fields']
    from_area = Organization.objects.get(id=fields['from_area'])
    to_area = Organization.objects.get(id=fields['to_area'])

    fields['from_area'] = to_area
    fields['to_area'] = from_area
    fields['matching_record'] = member_instance.id
    fields['year'] = member_instance.year
    fields['member_entity'] = member_instance.member_entity
    model_class = ContentType.objects.get(model=member_instance._meta.model_name).model_class()

    inverse_record = model_class.objects.create(**fields)
    member_instance.matching_record = inverse_record.id
    for series_object in member_instance.series_objects:
        data = {'data': -1 * series_object.data, 'series': series_object.series,
                'content_type': ContentType.objects.get(model=member_instance._meta.model_name),
                'object_id': inverse_record.id}
        SeriesElement.objects.create(**data)
    member_instance.state = settings.FSM_STATE['matched']
    inverse_record.state = settings.FSM_STATE['matched']
    member_instance.save()
    inverse_record.save()


def copy_intra_to_master(member_instance):
    _copy_to_master(member_instance, member_instance.master_type)


def copy_inter_to_master(member_instance):
    _copy_to_master(member_instance, member_instance.master_type)


def copy_net_to_master(member_instance):
    # If we are dealing with a net transaction there is no match so we only have
    # to copy the changes to the master database.
    mst_instance = member_instance.master_type.objects.get(id=int(member_instance.master_record))
    with transaction.atomic():
        for series_obj in member_instance.series_objects:
            mst_elm = SeriesElement.objects.get(series=series_obj.series, content_object=mst_instance)
            mst_elm.data = series_obj.data
            mst_elm.save()
        mst_instance.comments = member_instance.comments
        mst_instance.from_region = member_instance.from_region
        mst_instance.save()
