from model_mommy import mommy
from django.contrib.auth.models import User
from django.contrib.contenttypes.models import ContentType
from django.test import (TestCase, RequestFactory)

from contacts.models.organization import Organization
from transactions.views.transaction_views import WorkBookView
from transactions.models import (SeriesElement,
                                 Year,
                                 IntraAreaTransaction,
                                 InterAreaTransaction,
                                 NetTransaction)


class TestWorkBookView(TestCase):

    def setUp(self):
        self.factory = RequestFactory()
        self.year = mommy.make(Year, year=2015, current=True)
        self.org = mommy.make(Organization, area_owner=123, code='abc')
        mommy.make(IntraAreaTransaction, _quantity=20, year=self.year, from_area=self.org, to_area=self.org)
        mommy.make(InterAreaTransaction, _quantity=10, year=self.year, from_area=self.org, to_area=self.org)
        mommy.make(NetTransaction, _quantity=5, from_area=self.org)
        intra_type = ContentType.objects.get(model='intraareatransaction')
        inter_type = ContentType.objects.get(model='interareatransaction')
        net_type = ContentType.objects.get(model='nettransaction')

        for mt in IntraAreaTransaction.objects.all():
            mommy.make(SeriesElement, _quantity=10, content_type=intra_type, object_id=mt.id)
        for mt in InterAreaTransaction.objects.all():
            mommy.make(SeriesElement, _quantity=10, content_type=inter_type, object_id=mt.id)
        for mt in NetTransaction.objects.all():
            mommy.make(SeriesElement, _quantity=10, content_type=net_type, object_id=mt.id)

        self.user = User.objects.create_user(username='sparky',
                                             email='sparky@localhost',
                                             password='top_secret')

    def test_get(self):
        """Does our get load the data it should?"""

        request = self.factory.get('/transactions/workbook/view/')
        request.user = self.user
        view = WorkBookView()
        result = view.get(request)
        self.assertEqual(result.status_code, 200)
