from django.contrib.auth.models import User
from django.forms import model_to_dict
from django.test import TestCase, RequestFactory
from contacts.models.organization import Organization
from transactions.forms.transactions import InterAreaTransactionForm, IntraAreaTransactionForm, NetTransactionForm
from transactions.models import Year, InterAreaTransaction, NetTransaction, IntraAreaTransaction

from model_mommy import mommy

from transactions.views.edit_transactions import EditIntraAreaTransaction, EditNetTransaction, EditInterAreaTransaction


class TestEditRecord(TestCase):

    def setUp(self):

        self.factory = RequestFactory()
        self.year = mommy.make(Year, year=2015, current=True)
        self.org1 = mommy.make(Organization, code='BALKO')
        self.org2 = mommy.make(Organization, code='away')
        gen_data = {'oasis_number': 123456, 'start': '2000-1-1', 'stop': '2050-1-1'}
        self.inter = mommy.make(InterAreaTransaction, transaction_id=1, to_area=self.org2, from_area=self.org1, **gen_data)
        self.user = User.objects.create_user(
                username='jacob', email='jacob@localhost', password='top_secret')
        self.intra = mommy.make(IntraAreaTransaction, from_area=self.org1, to_area=self.org2, **gen_data)
        self.net = mommy.make(NetTransaction, from_area=self.org1, to_area='NET')

    def test_get_net(self):
        """Do we get all the data for our transaction in the form?"""

        get_request = self.factory.get('/net/edit/{0}/'.format(self.net.id))
        get_request.user = self.user
        result = EditNetTransaction().get(get_request, str(self.net.id))
        self.assertEqual(result.status_code, 200)

    def test_get_inter(self):
        """Do we get all the data for our transaction in the form?"""

        get_request = self.factory.get('/inter/edit/{0}/'.format(self.inter.id))
        get_request.user = self.user
        result = EditInterAreaTransaction().get(get_request, str(self.inter.id))
        self.assertEqual(result.status_code, 200)

    def test_get_intra(self):
        """Do we get all the data for our transaction in the form?"""

        get_request = self.factory.get('/intra/edit/{0}/'.format(self.intra.id))
        get_request.user = self.user
        result = EditIntraAreaTransaction().get(get_request, str(self.intra.id))
        self.assertEqual(result.status_code, 200)

    def test_intra_post(self):

        data = model_to_dict(self.intra)

        data['capacity'] = 50
        post_request = self.factory.post('/intra/edit/{0}/'.format(self.intra.id), data)
        post_request.user = self.user
        result = EditIntraAreaTransaction().post(post_request, str(self.intra.id))

        self.assertEqual(result.status_code, 302)
        new_trans = IntraAreaTransaction.objects.get(pk=self.intra.id)
        self.assertEqual(new_trans.capacity, 50)

    def test_inter_post(self):

        data = model_to_dict(self.inter)
        data['from_region'] = 'SPP1'
        data['capacity'] = 50
        post_request = self.factory.post('/inter/edit/{0}/'.format(self.inter.id), data)
        post_request.user = self.user
        result = EditInterAreaTransaction().post(post_request, str(self.inter.id))
        self.assertEqual(result.status_code, 302)
        new_trans = InterAreaTransaction.objects.get(pk=self.inter.id)
        self.assertEqual(new_trans.capacity, 50)

    def test_net_post(self):

        data = model_to_dict(self.net)

        data['from_area'] = self.org2.id
        post_request = self.factory.post('/net/edit/{0}/'.format(self.net.id), data)
        post_request.user = self.user
        result = EditNetTransaction().post(post_request, str(self.net.id))
        self.assertEqual(result.status_code, 302)
        new_trans = NetTransaction.objects.get(pk=self.net.id)
        self.assertEqual(new_trans.from_area.id, self.org2.id)
