from model_mommy import mommy
from django.core.management import call_command
from contacts.models.organization import Organization
from django.test import (TestCase, Client, RequestFactory)

from transactions.member_utils import build_records, verify_transactions
from django.contrib.auth import get_user_model
from transactions import models as t_models
import os


class TestWorkbookUpload(TestCase):

    def setUp(self):
        self.factory = RequestFactory()
        self.client = Client()
        m = get_user_model()
        m.objects.create_user(username='sparky', email='sparky@localhost', password='pass')
        self.user = m.objects.get(username='sparky')
        self.client.login(username='sparky', password='pass')
        self.organization = mommy.make(Organization, area_owner=534, code='BALKO', is_member=True)
        mommy.make(Organization, area_owner=534, code='TRANSOURCE', is_member=True)
        self.year = mommy.make(t_models.Year, year=2015, current=True)
        self.sc = '\r\n'.join(['15G', '15S', '15SH', '15F', '15W', '16L', '16G', '16S', '16SH', '16F',
                         '16W', '17G', '17S', '17W', '20L', '20S', '20W', '25S', '25W'])
        target = "{0}/fixtures/initial_orgs".format(os.path.dirname(os.path.realpath(__file__)))
        call_command('loaddata', target)


    def test_load_member(self):
        """Does load member workbook load the member transactions we need?"""
        self.column_names = mommy.make(t_models.ColumnNames, year=self.year, series_columns=self.sc)

        target = "{0}/BalkoWindLLC.xlsx".format(os.path.dirname(os.path.realpath(__file__)))
        with open(target, 'r+b') as test_file:
            result = verify_transactions(test_file, self.organization.area_owner, True)
            result = build_records(result['records'], self.organization, True)

            self.assertIsNone(result)

        count = t_models.MemberInterAreaTransaction.objects.all().count()
        count += t_models.MemberIntraAreaTransaction.objects.all().count()
        self.assertEqual(count, 1)
        t_models.ColumnNames.objects.all().delete()

    def test_upload_member_workbook(self):
        """Can we upload a member workbook? via a browser?"""

        self.column_names = mommy.make(t_models.ColumnNames, year=self.year, series_columns=self.sc)
        target = "{0}/BalkoWindLLC.xlsx".format(os.path.dirname(os.path.realpath(__file__)))
        with open(target, 'r+b') as test_file:
            result = self.client.post('/transactions/upload/member/', {'legacy': True, 
                                                                       'year': self.year.id,
                                                                       'series_columns': self.sc,
                                                                       'workbook': test_file,
                                                                       'organization': self.organization.id})
            self.assertEqual(result.status_code, 302)
        count = t_models.MemberInterAreaTransaction.objects.all().count()
        count += t_models.MemberIntraAreaTransaction.objects.all().count()
        self.assertEqual(count, 1)

    def test_upload_master_workbook(self):
        """Can we upload a master workbook? via a browser?"""
        target = "{0}/new_book.xlsx".format(os.path.dirname(os.path.realpath(__file__)))
        cn = '\r\n'.join(['15G','15S','15SH','15F','15W','16L','16G','16S','16SH',
                          '16F','16W','17G','17S','17W','20L','20S','20W','25S','25W'])
        with open(target, 'r+b') as test_file:
            result = self.client.post('/transactions/create-new-year/', {'legacy': True,
                                                                         'year': self.year.id,
                                                                         'series_columns': cn,
                                                                         'workbook': test_file,
                                                                         'organization': self.organization.id})
            self.assertEqual(result.status_code, 302)

    def test_upload_reformatted_workbook(self):
        """Can we upload a member workbook? via a browser?"""
        target = "{0}/reformated_master.xlsx".format(os.path.dirname(os.path.realpath(__file__)))
        with open(target, 'r+b') as test_file:
            result = self.client.post('/transactions/create-new-year/', {'legacy': False,
                                                                         'year': self.year.id,
                                                                         'series_columns': self.sc,
                                                                         'workbook': test_file,
                                                                         'organization': self.organization.id})
            self.assertEqual(result.status_code, 302)

    def test_data_columns_set(self):
        target = "{0}/BalkoWindLLC.xlsx".format(os.path.dirname(os.path.realpath(__file__)))
        expected_data_columns = "FROM REGION,From Area #,From Area,To Area #,To Area,ID,Oasis No.,Link No.,Plant,Start,Stop,Capacity,Roll Over Rights,S0 Scalable,S5 Scalable,OASIS,Comments,Other,Related Ref,Firm".split(',')
        with open(target, 'r+b') as test_file:
            result = self.client.post('/transactions/create-new-year/', {'legacy': True,
                                                                         'series_columns': self.sc,
                                                                         'year': self.year.id,
                                                                         'workbook': test_file,
                                                                         'organization': self.organization.id})

            self.assertEqual(result.status_code, 302)
        c_names = t_models.ColumnNames.objects.get(year__current=True)
        self.assertEqual(expected_data_columns, c_names.get_data_columns)

    def test_series_column_set(self):
        target = "{0}/BalkoWindLLC.xlsx".format(os.path.dirname(os.path.realpath(__file__)))
        expected_series_columns = "15G,15S,15SH,15F,15W,16L,16G,16S,16SH,16F,16W,17G,17S,17W,20L,20S,20W,25S,25W".split(',')

        with open(target, 'r+b') as test_file:
            result = self.client.post('/transactions/create-new-year/', {'legacy': True,
                                                                         'series_columns': self.sc,
                                                                         'year': self.year.id,
                                                                         'workbook': test_file,
                                                                         'organization': self.organization.id})
            self.assertEqual(result.status_code, 302)
        c_names = t_models.ColumnNames.objects.get(year__current=True)
        self.assertEqual(expected_series_columns, c_names.get_series_names)



