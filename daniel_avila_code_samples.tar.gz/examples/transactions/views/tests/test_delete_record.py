from django.contrib.contenttypes.models import ContentType
from model_mommy import mommy
from django.test import (TestCase, Client, RequestFactory)
from django.contrib.auth import get_user_model
from transactions import models as t_models


class TestDeleteRecord(TestCase):

    def setUp(self):

        self.client = Client()
        self.factory = RequestFactory
        m = get_user_model()
        self.user = m.objects.create(username='sparky', password='pass')
        self.user.set_password('pass')
        self.user.save()
        self.year = mommy.make(t_models.Year, current=True)

    def test_delete_interarea(self):

        record = mommy.make(t_models.InterAreaTransaction)
        for i in range(10):
            c_type = ContentType.objects.get(model=t_models.InterAreaTransaction._meta.model_name)
            mommy.make(t_models.SeriesElement, object_id=record.id, content_type=c_type)
        self.assertEqual(t_models.InterAreaTransaction.objects.all().count(), 1)
        self.assertEqual(t_models.SeriesElement.objects.all().count(), 10)
        self.client.login(username='sparky', password='pass')
        response = self.client.post('/transactions/{0}/delete/{1}/'.format(record.content_type, record.id))
        self.assertEqual(response.status_code, 302)
        self.assertEqual(t_models.InterAreaTransaction.objects.all().count(), 0)
        self.assertEqual(t_models.SeriesElement.objects.all().count(), 0)

    def test_delete_intraarea(self):

        record = mommy.make(t_models.IntraAreaTransaction)
        for i in range(10):
            c_type = ContentType.objects.get(model=t_models.IntraAreaTransaction._meta.model_name)
            mommy.make(t_models.SeriesElement, object_id=record.id, content_type=c_type)
        self.assertEqual(t_models.IntraAreaTransaction.objects.all().count(), 1)
        self.assertEqual(t_models.SeriesElement.objects.all().count(), 10)
        self.client.login(username='sparky', password='pass')
        response = self.client.post('/transactions/{0}/delete/{1}/'.format(record.content_type, record.id))
        self.assertEqual(response.status_code, 302)
        self.assertEqual(t_models.IntraAreaTransaction.objects.all().count(), 0)
        self.assertEqual(t_models.SeriesElement.objects.all().count(), 0)

    def test_delete_netarea(self):

        record = mommy.make(t_models.NetTransaction)
        for i in range(10):
            c_type = ContentType.objects.get(model=t_models.NetTransaction._meta.model_name)
            mommy.make(t_models.SeriesElement, object_id=record.id, content_type=c_type)
        self.assertEqual(t_models.NetTransaction.objects.all().count(), 1)
        self.assertEqual(t_models.SeriesElement.objects.all().count(), 10)
        url = '/transactions/{0}/delete/{1}/'.format(record.content_type, record.id)
        self.client.login(username='sparky', password='pass')
        response = self.client.post(url)
        self.assertEqual(response.status_code, 302)
        self.assertEqual(t_models.NetTransaction.objects.all().count(), 0)
        self.assertEqual(t_models.SeriesElement.objects.all().count(), 0)
