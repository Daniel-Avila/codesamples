from django.shortcuts import render, redirect
from django.views.generic import View

from transactions.models import Year
from transactions.forms.uploadworkbooks import YearForm


class YearView(View):

    def get(self, request):

        year_form = YearForm()

        return render(request, 'transactions/year_update_form.html', {'form': year_form})

    def post(self, request):

        year = Year.objects.get(current=True)
        year.current = False
        year.save()
        new_year = Year.objects.get(year=int(request.POST.get('year')))
        new_year.current = True
        new_year.save()
        return redirect('/transactions/year/update/')
