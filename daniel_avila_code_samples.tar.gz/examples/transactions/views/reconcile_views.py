from django.contrib.contenttypes.models import ContentType
from django.shortcuts import render, redirect
from django.views.generic import View
from transactions.copy_utils import (copy_intra_to_master,
                                     copy_inter_to_master,
                                     copy_net_to_master, invert_transaction)


class ForceReconcileView(View):

    http_method_names = ['get', 'post']

    def get(self, request):

        data = {'record_id': request.GET.get('mrid'), 'rec_type': request.GET.get('mrt'),
                'next': request.GET.get('next')}
        return render(request, 'transactions/force_reconcile.html', data)

    def post(self, request):

        rec_mem_model = ContentType.objects.get(model=request.POST.get('rec_type')).model_class()
        instance = rec_mem_model.objects.get(id=int(request.POST.get('rec_id')))

        if rec_mem_model._meta.model_name == 'memberintraareatransaction':
            invert_transaction(instance)

        if rec_mem_model._meta.model_name == 'memberinterareatransaction':
            invert_transaction(instance)

        if rec_mem_model._meta.model_name == 'membernettransaction':
            copy_net_to_master(instance)
            instance.commit()
        return redirect(request.POST.get('next_page'))
