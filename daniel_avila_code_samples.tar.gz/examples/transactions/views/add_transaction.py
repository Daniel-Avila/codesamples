from django.conf import settings
from django.contrib.auth.decorators import login_required
from django.contrib.contenttypes.models import ContentType

from django.http import HttpResponseRedirect
from django.shortcuts import render
from django.utils.decorators import method_decorator

from transactions.models import (ColumnNames,
                                 IntraAreaTransaction,
                                 NetTransaction,
                                 InterAreaTransaction,
                                 Year)
from transactions.forms.transactions import (SeriesElementForm,
                                             InterAreaTransactionForm,
                                             IntraAreaTransactionForm,
                                             NetTransactionForm)
from contacts.models.organization import Organization
from common.views.dashboard_view import BaseDashboardView
from transactions.member_utils import order_element_forms, update_state


class BaseAddTransaction(BaseDashboardView):
    allowed_methods = ['get', 'post']

    def _series_elements(self):
        column_names = ColumnNames.objects.get(year__current=True).get_series_names
        return column_names

    @method_decorator(login_required(redirect_field_name='next', login_url=settings.LOGIN_URL))
    def get(self, request):
        organizations = Organization.objects.filter(is_active=True).order_by('code')
        form = self.form_class()
        location = request.META.get('HTTP_REFERER', '/')
        context = {'series_names': self._series_elements(),
                   'form': form, 'location': location,
                   'organizations': organizations}
        return render(request, self.template, context)

    @method_decorator(login_required(redirect_field_name='next', login_url=settings.LOGIN_URL))
    def post(self, request):

        request.POST['year'] = Year.objects.get(current=True).id
        form = self.form_class(request.POST)
        valid = [form.is_valid()]
        element_forms = []
        location = request.POST.get('location')

        if form.is_valid():
            trans = form.save()
            for data_key in request.POST.keys():
                if data_key.startswith('data_'):
                    data = request.POST.get(data_key)
                    series = data_key.split('_')[1]
                    content_type = ContentType.objects.get(model=trans._meta.model_name)
                    f = SeriesElementForm({'data':data, 'series':series,
                                           'object_id': trans.id,
                                           'content_type': content_type.id})
                    valid.append(f.is_valid())
                    element_forms.append(f)

            if not all(valid):
                has_errors = True
                element_forms = order_element_forms(element_forms)
                years = Year.objects.all()
                organizations = Organization.objects.filter(is_active=True).order_by('code')
                startdate = ''
                stopdate = ''
                if hasattr(trans, 'start') and trans.start:
                    startdate = "{0}/{1}/{2}".format(trans.start.month,
                                                     trans.start.day,
                                                     trans.start.year)
                if hasattr(trans, 'stop') and trans.stop:
                    stopdate = "{0}/{1}/{2}".format(trans.stop.month,
                                                    trans.stop.day,
                                                    trans.stop.year)
                context = {'form': form, 'startdate': startdate, 'stopdate': stopdate, 'series_elements': element_forms,
                           'years':years, 'location': location, 'organizations': organizations, 'cancel_url': location, 'has_errors': has_errors}
                return render(request, self.template, context)
            for form in element_forms:
                form.save()
        update_state()
        return HttpResponseRedirect(request.POST.get('location', '/'))


class AddIntraAreaTransaction(BaseAddTransaction):

    model = IntraAreaTransaction
    form_class = IntraAreaTransactionForm
    template = 'transactions/edit_intratransaction.html'


class AddInterAreaTransaction(BaseAddTransaction):

    model = InterAreaTransaction
    form_class = InterAreaTransactionForm
    template = 'transactions/edit_intertransaction.html'


class AddNetTransaction(BaseAddTransaction):

    model = NetTransaction
    form_class = NetTransactionForm
    template = 'transactions/edit_nettransaction.html'
