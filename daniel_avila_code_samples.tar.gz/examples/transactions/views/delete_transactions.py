from django.conf import settings
from django.contrib.auth.decorators import login_required
from django.contrib.contenttypes.models import ContentType
from django.shortcuts import redirect, render
from django.utils.decorators import method_decorator
from django.views.generic import View

from transactions.member_utils import update_state
from transactions.models import (SeriesElement,
                                 InterAreaTransaction,
                                 IntraAreaTransaction,
                                 NetTransaction,
                                 MemberIntraAreaTransaction,
                                 MemberInterAreaTransaction)


class DeleteTransactionView(View):

    @method_decorator(login_required(redirect_field_name='next', login_url=settings.LOGIN_URL))
    def get(self, request, name, pk):
        return render(request, 'transactions/delete_modal.html', {'content_type': name, 'object_id': pk})

    @method_decorator(login_required(redirect_field_name='next', login_url=settings.LOGIN_URL))
    def post(self, request, name, pk):
        if name == 'memberinterareatransaction':
            klass = MemberInterAreaTransaction
        elif name == 'memberintraareatransaction':
            klass = MemberIntraAreaTransaction
        elif name == 'interareatransaction':
            klass = InterAreaTransaction
        elif name == 'intraareatransaction':
            klass = IntraAreaTransaction
        elif name == 'nettransaction':
            klass = NetTransaction

        obj_id = klass.objects.get(id=pk).id
        content_type = ContentType.objects.get(model=klass._meta.model_name)
        SeriesElement.objects.filter(object_id=obj_id, content_type=content_type).delete()
        klass.objects.filter(id=pk).delete()
        update_state()
        return redirect(request.META.get('HTTP_REFERER', '/transactions/workbook/view/'))
