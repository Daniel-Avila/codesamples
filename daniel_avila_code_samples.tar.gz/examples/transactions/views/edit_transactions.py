from django.conf import settings
from django.contrib.auth.decorators import login_required
from django.contrib.contenttypes.models import ContentType
from django.http import HttpResponseRedirect
from django.shortcuts import render, get_object_or_404
from common.views.dashboard_view import BaseDashboardView
from django.utils.decorators import method_decorator
from transactions.forms.transactions import (SeriesElementForm,
                                             IntraAreaTransactionForm,
                                             InterAreaTransactionForm,
                                             NetTransactionForm)
from transactions.models import (SeriesElement,
                                 Year, InterAreaTransaction, IntraAreaTransaction, NetTransaction,
                                 MemberInterAreaTransaction, MemberIntraAreaTransaction)
from transactions.member_utils import order_element_forms, update_state
from contacts.models.organization import Organization


class BaseEditTransaction(BaseDashboardView):
    allowed_methods = ['get', 'post']
    model = None

    def _series_elements(self):
        series_elements = self.instance.series_objects
        element_forms = []
        for element in series_elements:
            element_forms.append(SeriesElementForm(None, instance=element))
        return order_element_forms(element_forms)

    @method_decorator(login_required(redirect_field_name='next', login_url=settings.LOGIN_URL))
    def get(self, request, pk):
        self.instance = get_object_or_404(self.model, id=pk)
        element_forms = self._series_elements()
        years = Year.objects.all()
        organizations = Organization.objects.filter(is_active=True).order_by('code')
        startdate = ''
        stopdate = ''
        if hasattr(self.instance, 'start') and self.instance.start:
            startdate = "{0}/{1}/{2}".format(self.instance.start.month,
                                             self.instance.start.day,
                                             self.instance.start.year)
        if hasattr(self.instance, 'stop') and self.instance.stop:
            stopdate = "{0}/{1}/{2}".format(self.instance.stop.month,
                                            self.instance.stop.day,
                                            self.instance.stop.year)
        form = self.form_class(None, instance=self.instance)
        location = request.META.get('HTTP_REFERER', '/')
        context = {'location': location, 'form': form, 'startdate': startdate, 'stopdate': stopdate,
                   'cancel_url': location, 'series_elements': element_forms, 'years':years,
                   'organizations': organizations}
        return render(request, self.template, context)

    @method_decorator(login_required(redirect_field_name='next', login_url=settings.LOGIN_URL))
    def post(self, request, pk):

        self.instance = get_object_or_404(self.model, id=pk)
        extra = {'instance': self.instance}
        request.POST['year'] = Year.objects.get(current=True).id
        request.POST['matching_record'] = self.instance.matching_record
        form = self.form_class(request.POST or None, **extra)
        valid = [form.is_valid()]
        element_forms = []
        location = request.POST.get('location')
        for data_key in request.POST.keys():
            if data_key.startswith('data_'):
                data = request.POST.get(data_key)
                series = data_key.split('_')[1]

                content_type = ContentType.objects.get(model=self.instance._meta.model_name)
                element = SeriesElement.objects.get(content_type=content_type, object_id=self.instance.id, series=series)
                f = SeriesElementForm({'data':data, 'series':series,
                                       'object_id': self.instance.id,
                                       'content_type': content_type.id},
                                      instance=element)
                valid.append(f.is_valid())
                element_forms.append(f)

        if not all(valid):
            has_errors = True
            element_forms = order_element_forms(element_forms)
            years = Year.objects.all()
            organizations = Organization.objects.filter(is_active=True).order_by('code')
            startdate = ''
            stopdate = ''
            if hasattr(self.instance, 'start') and self.instance.start:
                startdate = "{0}/{1}/{2}".format(self.instance.start.month,
                                                 self.instance.start.day,
                                                 self.instance.start.year)
            if hasattr(self.instance, 'stop') and self.instance.stop:
                stopdate = "{0}/{1}/{2}".format(self.instance.stop.month,
                                                self.instance.stop.day,
                                                self.instance.stop.year)
            context = {'form': form, 'startdate': startdate, 'stopdate': stopdate, 'series_elements': element_forms,
                       'years':years, 'location': location, 'organizations': organizations, 'cancel_url': location, 'has_errors': has_errors}
            return render(request, self.template, context)

        form.save()
        for form in element_forms:
            form.save()
        update_state()
        return HttpResponseRedirect(request.POST.get('location', '/'))


class EditIntraAreaTransaction(BaseEditTransaction):

    model = IntraAreaTransaction
    form_class = IntraAreaTransactionForm
    template = 'transactions/edit_intratransaction.html'


class EditInterAreaTransaction(BaseEditTransaction):

    model = InterAreaTransaction
    form_class = InterAreaTransactionForm
    template = 'transactions/edit_intertransaction.html'


class EditNetTransaction(BaseEditTransaction):

    model = NetTransaction
    form_class = NetTransactionForm
    template = 'transactions/edit_nettransaction.html'


class EditMemberIntraAreaTransaction(BaseEditTransaction):

    model = MemberIntraAreaTransaction
    form_class = IntraAreaTransactionForm
    template = 'transactions/edit_intratransaction.html'


class EditMemberInterAreaTransaction(BaseEditTransaction):

    model = MemberInterAreaTransaction
    form_class = InterAreaTransactionForm
    template = 'transactions/edit_intertransaction.html'

