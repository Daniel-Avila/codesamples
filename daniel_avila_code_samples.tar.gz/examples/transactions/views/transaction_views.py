from django.db import transaction

from common.views.dashboard_view import BaseDashboardView
from django.conf import settings
from django.contrib.auth.decorators import login_required
from django.core.paginator import Paginator, EmptyPage, PageNotAnInteger
from django.shortcuts import render, redirect
from django.utils.decorators import method_decorator
from transactions.models import Year, BaseMasterTransaction, BaseMemberTransaction, ColumnNames, NetTransaction

from contacts.models.organization import Organization
from transactions.member_utils import verify_transactions, build_records, purge_member
from transactions.exceptions import UploadException
from transactions.utils import (get_match_count,
                                get_pending_count, get_collision_count,
                                get_orphan_count, get_member_submits,
                                get_master_count, get_final_count)


class DashboardView(BaseDashboardView):

    template = 'transactions/dashboard.html'
    http_method_names = ['get']

    def get_navigation(self, user):

        return [{'url': '#', 'text': 'TBD'},
                {'url': '#', 'text': 'TBD'},
                {'url': '#', 'text': 'TBD'},
                {'url': '#', 'text': 'TBD'}
                ]

    @method_decorator(login_required(redirect_field_name='next', login_url=settings.LOGIN_URL))
    def get(self, request):

        nav = self.get_navigation(request.user)
        return render(request, self.template, {'navigation': nav})


class TransactionDashboardView(BaseDashboardView):

    template = 'transactions/transaction_dashboard.html'
    http_method_names = ['get']

    @method_decorator(login_required(redirect_field_name='next', login_url=settings.LOGIN_URL))
    def get(self, request):

        nav = self.get_navigation(request.user)
        data = {'navigation': nav,
                'year': Year.objects.get(current=True),
                'collisions': get_collision_count(),
                'matches': get_match_count(),
                'pending': get_pending_count(),
                'orphan': get_orphan_count(),
                'final': get_final_count(),
                'master_total': get_master_count(),
                'member_submitted':get_member_submits()
                }
        return render(request, self.template, data)

    def get_navigation(self, user):
        """Get context sensitive navigation for a user"""
        return [{'url': '/transactions/upload/member/', 'text': 'Upload Member Workbook'},
                {'url': '/transactions/upload/member/?purge=1', 'text': 'Reset Member Workbook'},
                {'url': '/transactions/create-new-year/', 'text': 'Create New Working Year'},
                {'url': '/transactions/reset-current-year/', 'text': 'Reset Current Working Year'}
                ]


class UploadMemberWorkbookView(TransactionDashboardView):
    """Upload a work book. It may be either a master or
    or organization workbook depending on the 'organization' param
    passed from the front end. """

    template = "transactions/uploadworkbook.html"
    outcome_template = "transactions/upload_report.html"
    http_method_names = ['get', 'post']
    orgs = Organization.objects.filter(is_member=True, is_active=True).order_by('code').values('id', 'code')
    year = Year.objects.get(current=True)

    @method_decorator(login_required(redirect_field_name='next', login_url=settings.LOGIN_URL))
    def get(self, request):
        """Get the form. It will work for either a master workbook or a member workbook"""
        purge = request.GET.get('purge', False)

        return render(request, self.template, {'organizations': self.orgs,
                                               'purge': purge,
                                               'navigation': self.get_navigation(request.user)})

    @method_decorator(login_required(redirect_field_name='next', login_url=settings.LOGIN_URL))
    def post(self, request, *args, **kwargs):
        try:
            ColumnNames.objects.get(year__current=True)
        except ColumnNames.DoesNotExist:
            msg = 'No working year found. Please create a working year before trying to upload Member Workbooks'
            return render(request, self.outcome_template, {'result': [msg]})
        org = Organization.objects.get(id=request.POST.get('organization'))
        purge = request.POST.get('purge', False)
        if not request.POST.get('legacy'):
            is_legacy = False
        else:
            is_legacy = True
        if not purge:
            sub_klasses = BaseMemberTransaction.get_subclasses()
            count = 0
            for klass in sub_klasses:
                count += klass.objects.filter(year=self.year, member_entity=org).count()
            if count > 0:
                message = """You are uploading a workbook for a member that already has been uploaded.
                          You probably want to use Member Workbook Reset instead of Upload"""
                message = {'class': 'info', 'text': message}
                return render(request, self.template, {'organizations': self.orgs,
                                                       'purge': purge,
                                                       'message': message,
                                                       'navigation': self.get_navigation(request.user)})
        result = verify_transactions(request.FILES.get('workbook'), org.area_owner, is_legacy=is_legacy)

        if isinstance(result, dict):
            if purge:
                with transaction.atomic():
                    purge_member(org)
            try:
                with transaction.atomic():
                    build_records(result['records'], org, legacy=is_legacy)
            except UploadException as ex:
                outcome = ex.errors
                return render(request, self.outcome_template, {'result': outcome})

        elif isinstance(result, list):
            return render(request, self.outcome_template, {'result': result})

        return redirect('/transactions/workbook/members/view/')

    def get_navigation(self, user):
        """Get context sensitive navigation for a user"""
        return [{'url': '/transactions/upload/member/', 'text': 'Upload Member Workbook'},
                {'url': '/transactions/upload/member/?purge=1', 'text': 'Reset Member Workbook'}]


class WorkBookView(TransactionDashboardView):
    """View the rows of a workbook"""

    template = "transactions/workbookview.html"
    http_method_names = ['get']

    @method_decorator(login_required(redirect_field_name='next', login_url=settings.LOGIN_URL))
    def get(self, request):

        year = Year.objects.get(current=True)
        org = request.GET.get('org')
        sub_klasses = BaseMasterTransaction.get_subclasses()
        transactions = []
        filter = {'year': year}
        if org is not None:
            filter['from_area'] = Organization.objects.get(id=int(org))
        for klass in sub_klasses:
            transactions = transactions + list(klass.objects.filter(**filter).order_by('id'))

        try:
            series_row = ColumnNames.objects.get(year__current=True).get_series_names
        except IndexError:
            series_row = []
        except ColumnNames.DoesNotExist:
            series_row = []
        paginator = Paginator(transactions, 30)
        page = request.GET.get('page')
        try:
            transactions = paginator.page(page)
        except PageNotAnInteger:
            transactions = paginator.page(1)
        except EmptyPage:
            transactions = paginator.num_pages
        organizations = Organization.objects.filter(is_active=True).order_by('code')
        data = {'navigation': self.get_navigation(request.user),
                'year': year,
                'transactions': transactions,
                'series_row': series_row,
                'organizations': organizations,
                'is_master': True}

        return render(request, self.template, data)

    def get_navigation(self, user):
        """Get context sensitive navigation for a user"""
        return [{'url': '/transactions/create-new-year/', 'text': 'Create New Working Year'},
                {'url': '/transactions/reset-current-year/', 'text': 'Reset Current Working Year'},
                {'url': '/organizations/region/view/', 'text': 'Manage Regions'}
                ]


class NetTransactionView(TransactionDashboardView):
    """View the rows of a workbook"""

    template = "transactions/nettransactions.html"
    http_method_names = ['get']

    @method_decorator(login_required(redirect_field_name='next', login_url=settings.LOGIN_URL))
    def get(self, request):

        year = Year.objects.get(current=True)
        org = request.GET.get('org')
        filter = {'year': year}
        if org is not None:
            filter['from_area'] = Organization.objects.get(id=int(org))

        transactions = NetTransaction.objects.filter(**filter).order_by('id')
        try:
            series_row = ColumnNames.objects.get(year__current=True).get_series_names
        except IndexError:
            series_row = []
        except ColumnNames.DoesNotExist:
            series_row = []
        paginator = Paginator(transactions, 30)
        page = request.GET.get('page')
        try:
            transactions = paginator.page(page)
        except PageNotAnInteger:
            transactions = paginator.page(1)
        except EmptyPage:
            transactions = paginator.num_pages
        organizations = Organization.objects.filter(is_active=True).order_by('code')
        data = {'navigation': self.get_navigation(request.user),
                'year': year,
                'transactions': transactions,
                'series_row': series_row,
                'organizations': organizations}

        return render(request, self.template, data)

    def get_navigation(self, user):
        """Get context sensitive navigation for a user"""
        return [{'url': '/transactions/upload-net/', 'text': 'Upload Network Transactions'},
                {'url': '/organizations/region/view/', 'text': 'Manage Regions'}]


class MemberWorkBookView(TransactionDashboardView):
    """View the rows of a workbook"""

    template = "transactions/workbookview.html"
    http_method_names = ['get']

    @method_decorator(login_required(redirect_field_name='next', login_url=settings.LOGIN_URL))
    def get(self, request):
        year = Year.objects.get(current=True)

        sub_klasses = BaseMemberTransaction.get_subclasses()
        transactions = []
        for klass in sub_klasses:
            transactions = transactions + list(klass.objects.filter(year=year).order_by('id'))

        try:
            series_row = [x['series'] for x in transactions[0].series_data]
        except IndexError:
            series_row = []
        paginator = Paginator(transactions, 30)
        page = request.GET.get('page')
        try:
            transactions = paginator.page(page)
        except PageNotAnInteger:
            transactions = paginator.page(1)
        except EmptyPage:
            transactions = paginator.num_pages
        organizations = Organization.objects.filter(is_active=True).order_by('code')

        data = {'navigation': self.get_navigation(request.user),
                'year': year,
                'transactions': transactions,
                'series_row': series_row,
                'organizations': organizations,
                'is_master': False}

        return render(request, self.template, data)

    def get_navigation(self, user):
        """Get context sensitive navigation for a user"""
        return [{'url': '/transactions/upload/member/', 'text': 'Upload Member Workbook'},
                {'url': '/transactions/upload/member/?purge=1', 'text': 'Reset Member Workbook'},
                {'url': '/organizations/region/view/', 'text': 'Manage Regions'}]
