from django.http import HttpResponse

from transactions.models import (InterAreaTransaction,
                                 IntraAreaTransaction,
                                 NetTransaction)
from transactions.api.v1.serializers import MasterTransactionSerializer
from rest_framework.views import APIView
from rest_framework.renderers import JSONRenderer
from rest_framework.response import Response


class MasterTransactionData(APIView):

    def get(self, request, type_code, format=None):

        if type_code == 'inter':
            transactions = InterAreaTransaction.objects.all()
        elif type_code == 'intra':
            transactions = IntraAreaTransaction.objects.all()
        elif type_code == 'net':
            transactions = NetTransaction.objects.all()

        serializer = MasterTransactionSerializer(transactions, many=True)

        return Response(serializer.data)
