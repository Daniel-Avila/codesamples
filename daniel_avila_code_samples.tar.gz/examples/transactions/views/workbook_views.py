import datetime

from django.contrib.auth.decorators import login_required
from django.conf import settings
from django.db import transaction
from django.http import HttpResponse
from django.shortcuts import render, redirect
from django.utils.decorators import method_decorator
from django.views.generic import View

from transactions.exceptions import UploadException
from transactions.forms.uploadworkbooks import YearForm, ColumnsForm
from transactions.models import Year, BaseMasterTransaction, ColumnNames
from transactions.views.transaction_views import TransactionDashboardView
from transactions.master_utils import (verify_transactions, build_records,
                                       get_download, build_net_records,
                                       sum_master_workbook)
from transactions.utils import extract_column_names, check_duplicates
from pdb import set_trace


class DownloadWorkbookView(View):

    template = 'transactions/records.csv'

    @method_decorator(login_required(redirect_field_name='next', login_url=settings.LOGIN_URL))
    def get(self, request):
        is_net = request.GET.get('type') is not None
        if is_net:
            workbook_name = 'net_transactions'
        else:
            workbook_name = 'master_workbook'
        year = Year.objects.get(current=True)
        workbook = get_download(net=is_net)
        response = HttpResponse(content_type='application/xlsx')
        stamp = datetime.datetime.now().isoformat()
        response['Content-Disposition'] = 'attachment; filename="{0}_{1}_{2}.xlsx"'.format(workbook_name,
                                                                                           year.year,
                                                                                           stamp)
        response.write(workbook.getvalue())
        workbook.close()
        return response


class CreateWorkbookYearView(TransactionDashboardView):

    template = 'transactions/new_workbook.html'
    outcome_template = "transactions/upload_report.html"
    http_method_names = ['get', 'post']

    @method_decorator(login_required(redirect_field_name='next', login_url=settings.LOGIN_URL))
    def get(self, request):
        if request.get_full_path() == '/transactions/create-new-year/':
            data = {'nav': [], 'years':Year.objects.all().order_by('year')}
        elif request.get_full_path() == '/transactions/reset-current-year/':
            data = {'nav': [], 'years': None}

        response = render(request, self.template, data)
        return response

    @method_decorator(login_required(redirect_field_name='next', login_url=settings.LOGIN_URL))
    def post(self, request):
        non_form_errors = []
        if request.get_full_path() == '/transactions/create-new-year/':
            is_reset = False
            if request.POST.get('legacy'):
                is_legacy = True
            else:
                is_legacy = False
            count = 0
            year = Year.objects.get(id=int(request.POST.get('year')))
            for klass in BaseMasterTransaction.get_subclasses():
                count += klass.objects.filter(year=year).count()
            if count:
                non_form_errors.append("You are trying to reset the current year's workbook from the creation form.")
            year_form = YearForm(request.POST)
            years = Year.objects.all()

            names_form = ColumnsForm(request.POST)
        else:
            is_reset = True
            is_legacy = False
            year = Year.objects.get(current=True)
            years = None
            year_form = None
            instance = ColumnNames.objects.get(year=year)
            names_form = ColumnsForm({'year': year.id, 'series_columns': request.POST.get('series_columns')}, instance=instance)
        missing_file = request.FILES.get('workbook') is None

        if year_form is not None:
            if not year_form.is_valid() or not names_form.is_valid() or missing_file or non_form_errors:

                data = {'nav': [], 'years': years, 'year_form':year_form, 'missing_file': missing_file,
                        'names_form': names_form, 'non_form_errors': non_form_errors}
                return render(request, self.template, data)
        else:
            if not names_form.is_valid() or missing_file or non_form_errors:

                data = {'nav': [], 'years': years, 'year_form':year_form, 'missing_file': missing_file,
                        'names_form': names_form, 'non_form_errors': non_form_errors}
                return render(request, self.template, data)

        header_row = names_form.cleaned_data['series_columns'].strip().split('\r\n')

        col_names = extract_column_names(request.FILES.get('workbook'), header_row)
        result = verify_transactions(request.FILES.get('workbook'), header_row, is_legacy)

        if isinstance(result, dict):
            try:
                with transaction.atomic():
                    if not is_reset:
                        old_year = Year.objects.get(current=True)
                        old_year.current = False
                        old_year.save()
                        year.current = True
                        year.save()
                    c_names = names_form.save()
                    c_names.data_columns = ','.join(col_names)
                    c_names.save()
                    build_records(result['records'], header_row, year, is_legacy)
                    check_duplicates(org=None)
                    sum_master_workbook(year)
            except UploadException as ex:

                outcome = ex.errors
                return render(request, self.outcome_template, {'result': outcome})

            return redirect('/transactions/workbook/view/')
        elif isinstance(result, list):
            return render(request, self.outcome_template, {'result': result})


class UploadNetTransactionsView(TransactionDashboardView):

    template = 'transactions/new_net_transactions.html'
    outcome_template = "transactions/upload_report.html"
    http_method_names = ['get', 'post']

    @method_decorator(login_required(redirect_field_name='next', login_url=settings.LOGIN_URL))
    def get(self, request):
        data = {'nav': [], 'reset': False}

        response = render(request, self.template, data)
        return response

    @method_decorator(login_required(redirect_field_name='next', login_url=settings.LOGIN_URL))
    def post(self, request):

        if request.POST.get('legacy'):
            is_legacy = True
        else:
            is_legacy = False

        missing_file = request.FILES.get('workbook') is None
        if missing_file:
                data = {'nav': [], 'missing_file': missing_file}
                return render(request, self.template, data)
        year = Year.objects.get(current=True)
        header_row = ColumnNames.objects.get(year__current=True).get_series_names
        result = verify_transactions(request.FILES.get('workbook'), header_row, is_legacy)
        if isinstance(result, dict):
            try:
                with transaction.atomic():
                    build_net_records(result['records'], header_row, year, is_legacy)
            except UploadException as ex:
                outcome = ex.errors
                return render(request, self.outcome_template, {'result': outcome})

            return redirect('/transactions/net-transactions/view/')
        elif isinstance(result, list):
            return render(request, self.outcome_template, {'result': result})