from auditlog.registry import auditlog
from django.conf import settings
from django.db import models
from django_fsm import FSMField, transition
from .series_element import SeriesElement
from contacts.models.organization import Organization, Region
from django.contrib.contenttypes.models import ContentType

from transactions.copy_utils import (copy_inter_to_master,
                                     copy_intra_to_master,
                                     copy_net_to_master)


class TransactionUnmatched(Exception):
    pass


class GetSubclassesMixin(object):
    """
    We have multiple transaction types and sometimes we want all of the types regardless.

    This will return all subclass instances of a class. For example when we want to look
    at the current year or a past year Master Work Book the ContentTypes class keeps track
    of all of our content types and subsequently we can calculate the child types of a parent
    provided we set the app_label.

    """
    @classmethod
    def get_subclasses(cls):
        content_types = ContentType.objects.filter(app_label=cls._meta.app_label)
        mdls = [ct.model_class() for ct in content_types]
        return [model for model in mdls
                if (model is not None and
                    issubclass(model, cls) and
                    model is not cls)]


class ColumnNames(models.Model):
    """A container for the column names for a given model year"""

    class Meta:
        app_label = 'transactions'

    year = models.ForeignKey('Year', unique=True)
    series_columns = models.CharField(max_length=2048)
    data_columns = models.CharField(max_length=2048, default='')

    @property
    def get_series_names(self):
        return self.series_columns.split()

    @property
    def get_data_columns(self):
        return self.data_columns.split(',')


class Year(models.Model):
    """A year marker for identifying the Series Year we are dealing with.

    Managing Transactions in the master table is organized by year. Subsequently
    Series Elements need to know what year they represent. At the beginning of a new
    series year a new "Current Year" is set in the database.

    Attributes:
        Year.year (int): A four digit value representing a year
        Year.current (bool): A boolean telling us if this is the current year. True if this year
        is the current year. False otherwise.
    """
    class Meta:
        app_label = 'transactions'

    year = models.IntegerField(default=2015)
    current = models.BooleanField(default=False)


class BaseTransaction(models.Model):
    """Base abstract transaction model

    Attributes:
        BaseTransaction.from_region (str): A string code representing the region of origin
        BaseTransaction.comments (str): The comments from the uploaded Transaction Worksheet
    """
    class Meta:
        app_label = 'transactions'
        abstract = True

    year = models.ForeignKey('Year')

    comments = models.TextField(null=True, default='', blank=True)
    # firm This is the field Firm from the worksheet. Calculated by the rule:
    # If capacity is 0 or null then Firm is False

    @property
    def from_region(self):
        regions = Region.objects.all()
        for r in regions:
            if self.from_area.area_owner in r.valid_ids:
                return r.code
        return 'Not Set'

    @property
    def series_objects(self):
        """Get the SeriesElement objects associated with this instance"""

        content_type = ContentType.objects.get(model=self._meta.model_name)
        return SeriesElement.objects.filter(content_type=content_type, object_id=self.id).order_by('id')

    @property
    def series_data(self):
        """The series data for this record"""

        # series data column names in order. We should do this a different way

        content_type = ContentType.objects.get(model=self._meta.model_name)
        return SeriesElement.objects.filter(content_type=content_type, object_id=self.id).values('data', 'series')

    @property
    def is_zeroed(self):
        """Are all the series data values zeroed out

        Returns:
            bool: True if all series data values are 0 False otherwise
        """

        content_type = ContentType.objects.get(model=self._meta.model_name)
        values = [x['data'] for x in SeriesElement.objects.filter(content_type=content_type,
                                                                  object_id=self.id).values('data')]
        return not any(values)

    @property
    def content_type(self):
        return self._meta.model_name


class BaseMasterTransaction(GetSubclassesMixin, BaseTransaction):
    class Meta:
        abstract = True


class AreaTransaction(BaseMasterTransaction):
    """Base Area Transaction

    Attributes:
         AreaTransaction.match_type (str): code which specifies which table the match extists in
            intra or inter
         AreaTransaction.oasis_number (str): Nullable field that identifies the Oasis if it exists.
         AreaTransaction.link_no (str): An external value given to SPP can be anything
         AreaTransaction.plant (str):
         AreaTransaction.start (Date): Date when the transaction agreement started
         AreaTransaction.stop (Date): End of the Transaction agreement
         AreaTransaction.capacity (float): The max capacity of the transaction
         AreaTransaction.s0_scalable (bool): Nullable
         AreaTransaction.s5_scalable (bool): Nullable
         AreaTransaction.related_ref (str): nullable Kept for backwards compatability
         AreaTransaction.from_area (Organization): The organization responsible for this transaction (The Owner).
         AreaTransaction.to_area (Organization): The reciprocal organization of the transaction
    """
    class Meta:
        app_label = 'transactions'
        abstract = True

    match_type = models.CharField(max_length=5, default='')
    oasis_number = models.CharField(max_length=128, null=True, blank=True)
    link_no = models.CharField(max_length=128, null=True)
    plant = models.CharField(max_length=64, null=True)
    start = models.DateField(null=True, blank=True)
    stop = models.DateField(null=True, blank=True)
    capacity = models.FloatField(null=True, default=0)
    roll_over_rights = models.NullBooleanField()
    s0_scalable = models.NullBooleanField()
    s5_scalable = models.NullBooleanField()
    related_ref = models.CharField(max_length=128, null=True)

    @property
    def firm(self):
        try:
            return self.capacity > 0
        except TypeError:
            return False


class IntraAreaTransaction(AreaTransaction):

    class Meta:
        app_label = 'transactions'

    matching_record = models.PositiveIntegerField(null=True, default=0)
    from_area = models.ForeignKey(Organization, null=False, related_name="from_intra_entity")
    # "From Area #" in the workbook. The display value should be Organization.org_id
    # from_area This is actually the From Area Entity's Alpha Code i.e. self.from_area.code
    to_area = models.ForeignKey(Organization, null=False, related_name="to_intra_entity")
    # "To Area #" in the workbook. Display value is Organization.org_id This field is a string in the
    # NetTransaction type to_area This is the To Area Entity's Alpha Code i.e. self.to_area.code

    @property
    def trans_type(self):
        return 'intra'


class InterAreaTransaction(AreaTransaction):
    """
    Attributes:
        InterAreaTransaction.matching_record (InterAreaTransaction): our matched record
        InterAreaTransaction.transaction_id (str): A single character that allows us to match a transactions [1-9A-Z]
    """

    class Meta:
        app_label = 'transactions'

    matching_record = models.PositiveIntegerField(null=True, default=0)
    transaction_id = models.CharField(max_length=2)  # The ID field from the workbook
    from_area = models.ForeignKey(Organization, null=False, related_name="from_inter_entity")
    # "From Area #" in the workbook. The display value should be Organization.org_id
    # from_area This is actually the From Area Entity's Alpha Code i.e. self.from_area.code
    to_area = models.ForeignKey(Organization, null=False, related_name="to_inter_entity")
    # "To Area #" in the workbook. Display value is Organization.org_id This field is a string in the
    # NetTransaction type to_area This is the To Area Entity's Alpha Code i.e. self.to_area.code

    @property
    def trans_type(self):
        return 'inter'


class NetTransaction(BaseMasterTransaction):
    """
    Attributes:
        NetTransaction.matching_record (null): Read Only. Net transactions never have a match
        NetTransaction.to_area (str): Read Only. Will always be "NET"
        NetTransaction.to_area_id (str): Read Only. Will always be "NET"
    """
    class Meta:
        app_label = 'transactions'

    @property
    def matching_record(self):
        return None

    to_area = models.CharField(max_length=3, default='NET')
    from_area = models.ForeignKey(Organization)

    @property
    def trans_type(self):
        return 'net'

    @property
    def match_type(self):
        return 'NET'


def check_orphan(instance):

    instance_type = type(instance)
    if instance.to_area == 'NET':
        return False
    to_area = instance.to_area
    recip_uploaded = instance_type.objects.filter(member_entity=to_area).count() != 0
    has_match = get_matching(instance)
    if not recip_uploaded:
        return False
    if recip_uploaded and not has_match:
        return True
    return False


def get_matching(instance):

    if isinstance(instance, MemberInterAreaTransaction):
        try:
            match_master_id = InterAreaTransaction.objects.get(id=instance.master_record).matching_record
            return MemberInterAreaTransaction.objects.get(master_record=match_master_id)
        except InterAreaTransaction.DoesNotExist:
            return None
        except MemberInterAreaTransaction.DoesNotExist:
            return None
    if isinstance(instance, MemberIntraAreaTransaction):
        try:
            match_master_id = IntraAreaTransaction.objects.get(id=instance.master_record).matching_record
            return MemberIntraAreaTransaction.objects.get(master_record=match_master_id)
        except IntraAreaTransaction.DoesNotExist:
            return None
        except MemberIntraAreaTransaction.DoesNotExist:
            return None


def check_collision(instance):

    obj = get_matching(instance)
    if obj is None:
        return False
    obj_series = obj.series_data
    inst_series = instance.series_data

    for series_element in inst_series:
        if series_element['data'] is not None:
            series_element['data'] = -int(series_element['data'])
            if not series_element in obj_series:
                return True
    return False


def check_matching(instance):

    result = get_matching(instance)
    if result is None:
        return False
    instance.matching_record = result.id
    result.matching_record = instance.id
    instance.save()
    result.save()
    result = check_collision(instance)
    if result:
        return False
    else:
        return True


class BaseMemberTransaction(GetSubclassesMixin, BaseTransaction):
    """A marker class to designate this as a proposed member change"""

    class Meta:
        abstract = True
        app_label = 'transactions'

    state = FSMField(default=settings.FSM_STATE['pending'])

    @transition(field=state, source=settings.FSM_STATE['any'], target=settings.FSM_STATE['matched'], conditions=[check_matching])
    def match(self):
        match = get_matching(self)
        if match == 'NET':
            self.state = settings.FSM_STATE['matched']
            pass
        else:
            self.matching_record = match.id
            self.state = settings.FSM_STATE['matched']
            match.matching_record = self.id
            match.state = settings.FSM_STATE['matched']
            self.save()
            match.save()

    @transition(field=state, source=settings.FSM_STATE['any'], target=settings.FSM_STATE['collision'], conditions=[check_collision])
    def collision(self):
        match = get_matching(self)
        if match == 'NET':
            pass
        else:
            self.matching_record = match.id
            self.state = settings.FSM_STATE['collision']
            match.matching_record = self.id
            match.state = settings.FSM_STATE['collision']
            self.save()
            match.save()

    @transition(field=state, source=settings.FSM_STATE['any'], target=settings.FSM_STATE['orphan'], conditions=[check_orphan])
    def orphan(self):
        self.state = settings.FSM_STATE['orphan']
        self.save()

    @transition(field=state, source=settings.FSM_STATE['any'], target=settings.FSM_STATE['committed'])
    def commit(self):
        self.state = settings.FSM_STATE['committed']
        self.save()
        if self.trans_type == 'minter':
            copy_inter_to_master(self)
        if self.trans_type == 'mintra':
            copy_intra_to_master(self)
        if self.trans_type == 'mnet':
            copy_net_to_master(self)

    @property
    def vetted_series_data(self):
        """The series data for this record tagged with a conflict"""

        match = self.matching_record
        if match is None:
            raise TransactionUnmatched()
        inst_series = self.series_objects
        new_series = []
        content_type = ContentType.objects.get(app_label=self._meta.app_label, model=self._meta.model_name)

        for series_element in inst_series:
            match_element = SeriesElement.objects.get(content_type=content_type,
                                                      object_id=match,
                                                      series=series_element.series)
            data_one = str(-int(series_element.data))
            if data_one == str(match_element.data):
                # We have a match all good
                record = {'meta': {'match': True}, 'series_element': series_element, 'match_element': match_element}
            else:
                record = {'meta': {'match': False}, 'series_element': series_element, 'match_element': match_element}
            new_series.append(record)
        return new_series


class MemberAreaTransaction(BaseMemberTransaction):
    """Base Member Area Transaction

    Attributes:
         AreaTransaction.oasis_number (str): Nullable field that identifies the Oasis if it exists.
         AreaTransaction.link_no (str): An external value given to SPP can be anything
         AreaTransaction.plant (str):
         AreaTransaction.start (Date): Date when the transaction agreement started
         AreaTransaction.stop (Date): End of the Transaction agreement
         AreaTransaction.capacity (float): The max capacity of the transaction
         AreaTransaction.s0_scalable (bool): Nullable
         AreaTransaction.s5_scalable (bool): Nullable
         AreaTransaction.related_ref (str): nullable Kept for backwards compatibility
         AreaTransaction.from_area (Organization): The organization responsible for this transaction (The Owner).
         AreaTransaction.to_area (Organization): The reciprocal organization of the transaction
    """
    class Meta:
        app_label = 'transactions'
        abstract = True

    matching_record = models.IntegerField(null=True, default=None)
    oasis_number = models.CharField(max_length=128, null=True, blank=True)
    link_no = models.CharField(max_length=128, null=True)
    plant = models.CharField(max_length=64, null=True)
    start = models.DateField(null=True)
    stop = models.DateField(null=True)
    capacity = models.FloatField(null=True)
    roll_over_rights = models.NullBooleanField()
    s0_scalable = models.NullBooleanField()
    s5_scalable = models.NullBooleanField()
    related_ref = models.CharField(max_length=128, null=True)

    @property
    def firm(self):
        try:
            return self.capacity > 0
        except TypeError:
            return False


class MemberIntraAreaTransaction(MemberAreaTransaction):

    class Meta:
        app_label = 'transactions'

    master_record = models.PositiveIntegerField(null=True, default=None)
    from_area = models.ForeignKey(Organization, null=False, related_name='from_entity')
    # "From Area #" in the workbook. The display value should be Organization.org_id
    # from_area This is actually the From Area Entity's Alpha Code i.e. self.from_area.code
    to_area = models.ForeignKey(Organization, null=False, related_name='to_entity')
    # "To Area #" in the workbook. Display value is Organization.org_id This field is a string in the
    # NetTransaction type to_area This is the To Area Entity's Alpha Code i.e. self.to_area.code
    member_entity = models.ForeignKey(Organization)

    @property
    def master_type(self):
        return IntraAreaTransaction

    @property
    def get_matching(self):
        return MemberIntraAreaTransaction.objects.get(id=self.matching_record)

    @property
    def trans_type(self):
        return 'mintra'


class MemberInterAreaTransaction(MemberAreaTransaction):
    """
    Attributes:
        MemberInterAreaTransaction.transaction_id (str): A single character that lets us to match transactions [1-9A-Z]
    """
    class Meta:
        app_label = 'transactions'

    master_record = models.PositiveIntegerField(null=True, default=None)
    transaction_id = models.CharField(max_length=1)  # The ID field from the workbook
    from_area = models.ForeignKey(Organization, null=False, related_name='from_member_entity')
    # "From Area #" in the workbook. The display value should be Organization.org_id
    # from_area This is actually the From Area Entity's Alpha Code i.e. self.from_area.code
    to_area = models.ForeignKey(Organization, null=False, related_name='area_to')
    # "To Area #" in the workbook. Display value is Organization.org_id This field is a string in the
    # NetTransaction type to_area This is the To Area Entity's Alpha Code i.e. self.to_area.code
    member_entity = models.ForeignKey(Organization)

    @property
    def master_type(self):
        return InterAreaTransaction


    @property
    def get_matching(self):
        return MemberInterAreaTransaction.objects.get(id=self.matching_record)

    @property
    def trans_type(self):
        return 'minter'


auditlog.register(IntraAreaTransaction)
auditlog.register(InterAreaTransaction)
auditlog.register(NetTransaction)
auditlog.register(MemberIntraAreaTransaction)
auditlog.register(MemberInterAreaTransaction)
auditlog.register(Year)
