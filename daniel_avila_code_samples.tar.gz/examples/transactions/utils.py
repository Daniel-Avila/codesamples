import datetime
from openpyxl import load_workbook

from django.conf import settings
from django.db import connection
from reports.views.duplicate_report import get_all_duplicates

from transactions.models import (SeriesElement, BaseMemberTransaction, BaseMasterTransaction)
from transactions.exceptions import UploadException

def get_collision_count():
    klasses = BaseMemberTransaction.get_subclasses()
    count = 0
    for klass in klasses:
        count += klass.objects.filter(state=settings.FSM_STATE['collision']).count()
    return count


def get_match_count():
    klasses = BaseMemberTransaction.get_subclasses()
    count = 0
    for klass in klasses:
        count += klass.objects.filter(state=settings.FSM_STATE['matched']).count()
    return count


def get_pending_count():
    klasses = BaseMemberTransaction.get_subclasses()
    count = 0
    for klass in klasses:
        count += klass.objects.filter(state=settings.FSM_STATE['pending']).count()
    return count


def get_orphan_count():
    klasses = BaseMemberTransaction.get_subclasses()
    count = 0
    for klass in klasses:
        count += klass.objects.filter(state=settings.FSM_STATE['orphan']).count()
    return count


def get_final_count():
    klasses = BaseMemberTransaction.get_subclasses()
    count = 0
    for klass in klasses:
        count += klass.objects.filter(state=settings.FSM_STATE['committed']).count()
    return count


def get_master_count():
    klasses = BaseMasterTransaction.get_subclasses()
    count = 0
    for klass in klasses:
        count += klass.objects.filter(year__current=True).count()
    return count


def get_member_submits():
    klasses = BaseMemberTransaction.get_subclasses()
    members = []
    for klass in klasses:
        members += klass.objects.all().distinct('member_entity')


def convert_to_bool(value):
    return str(value).lower() in ['true', '1', 't', 'y', 'yes', 'yeah', 'yup', 'certainly', 'uh-huh']


def fix_dates(date_string):
    if date_string is not None and isinstance(date_string, datetime.datetime):
        date_string = date_string.date()
    elif isinstance(date_string, str):
        try:
            dt = datetime.datetime.strptime(date_string, '%m/%d/%Y')
            date_string = datetime.date.strftime(dt, "%Y-%m-%d")
        except ValueError:
            date_string = None
    else:
        date_string = None

    return date_string


def match_series(record, candidate):
    outcome = [x+y for x,y in zip([x['data'] for x in record.series_data],
                                  [x['data'] for x in candidate.series_data])]
    if not any(outcome):
        return True
    return False


def make_series(start, end, header_row, content_type_id, obj_id, record):
    """
    Make the series elements for this row record

    Attributes:
        start (int):
        end (int):
        header_row (list): The names of the columns from the spreadsheet.
        content_type_id:
        obj_id:
        record (list): The record row that contains the data for the series elements.

    """
    values = []
    SeriesElement.objects.filter(object_id=obj_id, content_type__id=content_type_id).delete()
    for series_idx in range(start, end):
        if record[series_idx].value is not None:
            try:
                data = int(record[series_idx].value)
            except ValueError:
                data = 0
            series = header_row[series_idx - start]
            values.append((obj_id, data, series, '', content_type_id))
    return values


def _insert_series(series_records):
    if series_records:
        query = "INSERT INTO transactions_serieselement (object_id, data, series, formatting, content_type_id) VALUES "
        query += ','.join([str(sr) for sr in series_records])
        cursor = connection.cursor()
        cursor.execute(query)


def _fix_comments(record, indexes, legacy):
    if legacy is True:
        comments = record['comments']
        if comments is None:
            comments = ''
        if 'oasis' in record:
            comments = str(comments) + str(record['oasis'])
    else:
        comments = record['comments']
        if comments is None:
            comments = ''
    return comments


def _fix_values(trans, indexes):
    try:
        int(trans['oasis_number'])
    except TypeError:
        trans['oasis_number'] = 0
    except ValueError:
        trans['oasis_number'] = 0
    try:
        float(trans['capacity'])
    except ValueError:
        trans['capacity'] = None
    except TypeError:
        pass
    return trans


def extract_column_names(fh, header_row):

    col_names = []
    ws = load_workbook(fh).get_sheet_by_name('Transactions')

    for cel in ws.rows[3]:
        if cel.value in header_row:
            break
        else:
            col_names.append(cel.value)
    return col_names


def calc_indexes(headers, raw_row, start, legacy):

    indexes = {}
    for i in range(len(raw_row)):
        if raw_row[i].value is None:
            continue
        if not raw_row[i].value in headers:
            continue
        indexes[raw_row[i].value.lower()] = i
    return indexes
    # Start is the start of the series data


def convert_record_to_dict(record, headers, start):

    record_dict = {}
    for i in range(len(headers)):
        if i == start:
            break
        if headers[i] is None:
            continue
        try:
            record_dict[settings.DB_MAPPINGS[headers[i].lower()]] = record[i].value
        except KeyError:
            pass
    return record_dict


def check_duplicates(org=None):
    dups = get_all_duplicates()

    errors = []
    for dup in dups:
        msg = "From Area Number {0} From Area {1} To Area Number {2} To Area {3} Capacity {4} {5}".format(dup[0].from_area.area_owner,
                                                                                         dup[0].from_area.code,
                                                                                         dup[0].to_area.area_owner,
                                                                                         dup[0].to_area.code,
                                                                                         dup[0].capacity,
                                                                                         str(dup[0].series_data))
        if hasattr(dup[0], 'transaction_id'):
            msg += " Transaction ID {0}".format(dup[0].transaction_id)
        msg += "\nSeems to be a duplicate of \n"
        msg += "From Area Number {0} From Area {1} To Area Number {2} To Area {3} Capacity {4} {5}".format(dup[1].from_area.area_owner,
                                                                                          dup[1].from_area.code,
                                                                                          dup[1].to_area.area_owner,
                                                                                          dup[1].to_area.code,
                                                                                          dup[1].capacity,
                                                                                          str(dup[0].series_data))
        if hasattr(dup[1], 'transaction_id'):
            msg += " Transaction ID {0}".format(dup[1].transaction_id)
        errors.append({'message': msg})
    if errors:
        raise UploadException("Duplicates Found", errors)


def verify_series_data(record, start, end):
    """
    :param record:
    :param start:
    :param end:
    :return: bool True if all are ints False if otherwise
    """
    for series_idx in range(start, end):
        try:
            data = int(record[series_idx].value)
        except ValueError:
            return False
        except TypeError:
            return False
    return True


def load_transactions(workbook_file, is_legacy):
    errors = []
    ws = None
    try:
        ws = load_workbook(workbook_file).get_sheet_by_name('Transactions')
        if is_legacy and ws.rows[3][0].value == 'masterID':
            errors += [{'message': 'You are trying to upload a new style workbook in Legacy Mode.'}]
        elif not is_legacy and ws.rows[3][0].value != 'masterID':
            msg = """You are trying to upload a legacy style workbook. You can only upload Legacy Workbooks
            when Legacy Mode is enabled. You may NOT do a reset with a legacy workbook."""
            errors += [{'message': msg}]
    except KeyError:
        errors += [{'message': 'Workbook has no transactions tab.'}]
    return errors, ws


def set_indexes(legacy):
    if legacy:
        return settings.WORKBOOK_INDEX['legacy_index']
    else:
        return settings.WORKBOOK_INDEX['new_index']


def calc_headers(records, header_row):

    headers = [x.value.strip() for x in records.rows[3] if x.value is not None]
    raw_headers = [x.value for x in records.rows[3]]

    series_start = raw_headers.index(header_row[0])
    start = headers.index(header_row[0])

    return headers, raw_headers, series_start, start
