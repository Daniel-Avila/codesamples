from django.conf.urls import url
from transactions.views.delete_transactions import DeleteTransactionView
from transactions.views.transaction_views import (TransactionDashboardView,
                                                  DashboardView,
                                                  UploadMemberWorkbookView,
                                                  WorkBookView, MemberWorkBookView, NetTransactionView)
from transactions.views.workbook_views import CreateWorkbookYearView, DownloadWorkbookView, UploadNetTransactionsView
from transactions.views.edit_transactions import (EditInterAreaTransaction,
                                                  EditIntraAreaTransaction,
                                                  EditNetTransaction,
                                                  EditMemberIntraAreaTransaction,
                                                  EditMemberInterAreaTransaction)
from .views.year_views import YearView
from .views.reconcile_views import ForceReconcileView
from .views.add_transaction import (AddIntraAreaTransaction,
                                    AddNetTransaction,
                                    AddInterAreaTransaction)

urlpatterns = [
    url(r'^$', DashboardView.as_view()),
    url(r'^net-transactions/view/', NetTransactionView.as_view()),
    url(r'^upload-net/', UploadNetTransactionsView.as_view()),
    url(r'^view/', TransactionDashboardView.as_view()),
    url(r'^create-new-year/', CreateWorkbookYearView.as_view()),
    url(r'^reset-current-year/', CreateWorkbookYearView.as_view()),
    url(r'^upload/member/', UploadMemberWorkbookView.as_view()),
    url(r'^workbook/view/$', WorkBookView.as_view()),
    url(r'^workbook/members/view/$', MemberWorkBookView.as_view()),
    url(r'^workbook/download/$', DownloadWorkbookView.as_view()),
    url(r'^inter/edit/(?P<pk>[0-9]+)/$', EditInterAreaTransaction.as_view()),
    url(r'^intra/edit/(?P<pk>[0-9]+)/$', EditIntraAreaTransaction.as_view()),
    url(r'^net/edit/(?P<pk>[0-9]+)/$', EditNetTransaction.as_view()),
    url(r'^(?P<name>[a-z]+)/delete/(?P<pk>[0-9]+)/$', DeleteTransactionView.as_view()),
    url(r'^inter/add/$', AddInterAreaTransaction.as_view()),
    url(r'^intra/add/$', AddIntraAreaTransaction.as_view()),
    url(r'^net/add/$', AddNetTransaction.as_view()),
    url(r'^force/$', ForceReconcileView.as_view()),
    url(r'^minter/edit/(?P<pk>[0-9]+)/$', EditMemberInterAreaTransaction.as_view()),
    url(r'^mintra/edit/(?P<pk>[0-9]+)/$', EditMemberIntraAreaTransaction.as_view()),
    url(r'^year/update/', YearView.as_view()),
]
