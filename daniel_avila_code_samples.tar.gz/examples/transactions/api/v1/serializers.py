from rest_framework import serializers
from transactions.models import BaseMasterTransaction


class MasterTransactionSerializer(serializers.Serializer):


    matching_record = serializers.IntegerField(required=False, default=0)
    transaction_id = serializers.CharField(max_length=1, required=False)  # The ID field from the workbook
    from_area = serializers.StringRelatedField()
    # "From Area #" in the workbook. The display value should be Organization.org_id
    # from_area This is actually the From Area Entity's Alpha Code i.e. self.from_area.code
    to_area = serializers.StringRelatedField()
    # "To Area #" in the workbook. Display value is Organization.org_id This field is a string in the
    # NetTransaction type to_area This is the To Area Entity's Alpha Code i.e. self.to_area.code

    match_type = serializers.CharField(max_length=5, default='')
    oasis_number = serializers.IntegerField(required=False)
    link_no = serializers.CharField(max_length=128, required=False)
    plant = serializers.CharField(max_length=64, required=False)
    start = serializers.DateField(required=False)
    stop = serializers.DateField(required=False)
    capacity = serializers.FloatField(required=False)
    roll_over_rights = serializers.NullBooleanField(required=False)
    s0_scalable = serializers.NullBooleanField(required=False)
    s5_scalable = serializers.NullBooleanField(required=False)
    related_ref = serializers.CharField(max_length=128, required=False)
    from_region = serializers.CharField(max_length=5, required=True)
    comments = serializers.CharField(required=False)

    def to_representation(self, instance):
        try:
            if instance.start is not None:
                start = "{0}/{1}/{2}".format(instance.start.month, instance.start.day, instance.start.year)
            else:
                start = None
            if instance.stop is not None:
                stop = "{0}/{1}/{2}".format(instance.stop.month, instance.stop.day, instance.stop.year)
            else:
                stop = None
            data = [instance.from_region,
                    instance.from_area_id,
                    instance.from_area.code,
                    instance.to_area_id,
                    instance.to_area.code,
                    instance.oasis_number,
                    instance.link_no,
                    instance.plant,
                    start,
                    stop,
                    instance.capacity,
                    instance.roll_over_rights,
                    instance.s0_scalable,
                    instance.s5_scalable,
                    instance.comments,
                    instance.related_ref,
                    instance.firm
                    ]

        except AttributeError:
            data = [instance.from_region,
                    instance.from_area_id,
                    instance.from_area.code,
                    instance.match_type,
                    instance.match_type,
                    'N/A',
                    'N/A',
                    'N/A',
                    'N/A',
                    'N/A',
                    'N/A',
                    'N/A',
                    'N/A',
                    'N/A',
                    instance.comments,
                    'N/A',
                    'N/A'
                    ]
#

        series_data = [x['data'] for x in instance.series_data]
        data = data + series_data

        return data
