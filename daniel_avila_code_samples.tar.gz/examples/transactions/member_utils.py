import sys
from django.db import connection
from django_fsm import TransitionNotAllowed

from django.contrib.contenttypes.models import ContentType
from django.conf import settings
from contacts.models.organization import Organization
from .exceptions import UploadException
from .models import (MemberInterAreaTransaction,
                     MemberIntraAreaTransaction,
                     Year, ColumnNames,
                     BaseMemberTransaction, SeriesElement, InterAreaTransaction, IntraAreaTransaction)
from transactions.utils import (fix_dates, make_series,
                                _fix_comments, convert_record_to_dict,
                                verify_series_data, convert_to_bool, set_indexes,
                                load_transactions, calc_headers)
from transactions.transaction_tests import (verify_areas, verify_header_row,
                                            verify_transaction_id, verify_area_owner_number,
                                            verify_float, verify_bool)


def purge_member(org):

    sub_klasses = BaseMemberTransaction.get_subclasses()
    year = Year.objects.get(current=True)
    for klass in sub_klasses:
        records = klass.objects.filter(year=year, member_entity=org)
        for record in records:
            SeriesElement.objects.filter(content_type__model=record._meta.model_name, object_id=record.pk).delete()
        records.delete()


def find_in_master(record, raw_record, rec_type, start, end, indexes):
    year = Year.objects.get(current=True)
    if rec_type == 'inter':
        try:
            return InterAreaTransaction.objects.get(from_area__area_owner=record['from_area_number'],
                                                    from_area__code=record['from_area_code'],
                                                    year=year,
                                                    to_area__area_owner=record['to_area_number'],
                                                    to_area__code=record['to_area_code'],
                                                    transaction_id=record['transaction_id']).id
        except InterAreaTransaction.DoesNotExist:
            return 0
        except InterAreaTransaction.MultipleObjectsReturned:
            return InterAreaTransaction.objects.get(from_area__area_owner=record['from_area_number'],
                                                    from_area__code=record['from_area_code'],
                                                    year=year,
                                                    to_area__area_owner=record['to_area_number'],
                                                    to_area__code=record['to_area_code'],
                                                    capacity=record['capacity'],
                                                    transaction_id=record['transaction_id']).id
    else:
        candidates = IntraAreaTransaction.objects.filter(from_area__area_owner=record['from_area_number'],
                                                         from_area__code=record['from_area_code'],
                                                         year=year,
                                                         to_area__area_owner=record['to_area_number'],
                                                         to_area__code=record['to_area_code'])
        for candidate in candidates:
            outcome = [x+y for x,y in zip([x.value for x in raw_record[start:end]],
                                  [x['data'] for x in candidate.series_data])]
            if not any(outcome):
                return candidate.id
    return 0


def process_inter_area_record(trans, master_id, indexes, legacy, year, from_org, to_org, organization):

    comments = _fix_comments(trans, indexes, legacy)
    data = {'master_record': master_id,
            'year': year,
            'from_area': from_org,
            'to_area': to_org,
            'transaction_id': trans['transaction_id'],
            'oasis_number': trans['oasis_number'],
            'link_no': trans['link_no'],
            'plant': trans['plant'],
            'start': fix_dates(trans['start']),
            'stop': fix_dates(trans['stop']),
            'capacity': trans['capacity'],
            'roll_over_rights': convert_to_bool(trans['roll_over_rights']),
            's0_scalable': convert_to_bool(trans['s0_scalable']),
            's5_scalable': convert_to_bool(trans['s5_scalable']),
            'related_ref': trans['related_ref'],
            'comments': comments,
            'member_entity': organization}

    return MemberInterAreaTransaction.objects.create(**data)


def process_intra_area_record(trans, master_id, indexes, legacy, year, from_org, to_org, organization):

    comments = _fix_comments(trans, indexes, legacy)
    data = {'master_record': master_id,
            'year': year,
            'from_area': from_org,
            'to_area': to_org,
            'oasis_number': trans['transaction_id'],
            'link_no': trans['link_no'],
            'plant': trans['plant'],
            'start': fix_dates(trans['start']),
            'stop': fix_dates(trans['stop']),
            'capacity': trans['capacity'],
            'roll_over_rights': convert_to_bool(trans['roll_over_rights']),
            's0_scalable': convert_to_bool(trans['s0_scalable']),
            's5_scalable': convert_to_bool(trans['s5_scalable']),
            'related_ref': trans['related_ref'],
            'comments': comments,
            'member_entity': organization}

    return MemberIntraAreaTransaction.objects.create(**data)


def build_records(records, organization, legacy=False):

    if legacy is False:
        indexes = settings.WORKBOOK_INDEX['new_index']
    else:
        indexes = settings.WORKBOOK_INDEX['legacy_index']
    header_row = ColumnNames.objects.get(year__current=True).get_series_names
    headers = [x.value for x in records.rows[3] if x.value not in ['NOTES', None]]
    raw_headers = [x.value for x in records.rows[3] if x.value not in ['NOTES']]
    start = headers.index(header_row[0])
    end = len(headers)
    area_owner = organization.area_owner
    code = organization.code
    year = Year.objects.get(current=True)
    series_records = []
    errors = []
    for raw_record in records.rows[4:]:
        if str(raw_record[0].value).lower() == 'end':
            break
        trans = convert_record_to_dict(raw_record, raw_headers, start)

        try:
            from_org = Organization.objects.get(code=trans['from_area_code'].strip(),
                                                area_owner=trans['from_area_number'])
            if not from_org.is_member:
                continue
            if trans['to_area_code'].strip() != 'NET':
                to_org = Organization.objects.get(code=trans['to_area_code'].strip(),
                                                  area_owner=trans['to_area_number'])
            if trans['from_area_number'] == area_owner and trans['from_area_code'] == code:
                if trans['transaction_id'] is not None:
                    content_type_id = ContentType.objects.get(model=MemberInterAreaTransaction._meta.model_name).id
                    if legacy is True:
                        master_id = find_in_master(trans, raw_record, 'inter', start, end, indexes)
                    else:
                        master_id = int(raw_record[0].value)
                    o = process_inter_area_record(trans, master_id, indexes, legacy, year, from_org, to_org,
                                                  organization)
                    o.save()
                    series_records += make_series(start, end, header_row, content_type_id, o.id, raw_record)
                if trans['transaction_id'] is None and trans['to_area_code'] != 'NET':
                    content_type_id = ContentType.objects.get(model=MemberIntraAreaTransaction._meta.model_name).id
                    if legacy is True:
                        master_id = find_in_master(trans, raw_record, 'intra', start, end, indexes)
                    else:
                        master_id = int(raw_record[0].value)
                    o = process_intra_area_record(trans, master_id, indexes, legacy, year, from_org, to_org,
                                                  organization)
                    o.save()
                    series_records += make_series(start, end, header_row, content_type_id, o.id, raw_record)

        except Exception as ex:
            message = sys.exc_info()[1].args[0]
            error = '%s (%s) Triggerd by row %s' % (message, type(ex), raw_record[0].row)
            errors.append({'message': error})

    if errors:
        raise UploadException('There were problems with your upload', errors)
    else:
        query = "INSERT INTO transactions_serieselement (object_id, data, series, formatting, content_type_id) VALUES "
        query += ','.join([str(sr) for sr in series_records])
        cursor = connection.cursor()
        cursor.execute(query)
    update_state()


def verify_transactions(workbook_file, area_owner, is_legacy):

    indexes = set_indexes(is_legacy)
    errors, ws = load_transactions(workbook_file, is_legacy)
    if errors:
        return errors
    header_row = ColumnNames.objects.get(year__current=True).get_series_names
    headers, raw_headers, series_start, start = calc_headers(ws, header_row)
    end = len(headers) - 1
    for row in ws.rows[4:]:
        if isinstance(row[0].value, str) and row[0].value.lower() == 'end':
            break
        record = convert_record_to_dict(row, headers, start)

        if not verify_series_data(row, start, end):
            errors += [{'message': "Please verify the series data values in row {0} are all numbers".format(row[0].row)}]
        if record['transaction_id'] is not None:
            if not verify_transaction_id(record['transaction_id']):
                errors += [{'message': 'Transaction ID must be a single digit or a single uppercase letter. ROW: {0}'.format(row[0].row)}]
        if not verify_area_owner_number(record['from_area_number']):
            errors += [{'message': 'From Area Number must be an integer between 1-999 inclusive. ROW: {0}'.format(row[0].row)}]
        if not verify_area_owner_number(record['to_area_number']):
            errors += [{'message': 'To Area Number must be an integer between 1-999 inclusive. ROW: {0}'.format(row[0].row)}]
        if not verify_float(record['capacity']):
            errors += [{'message': 'Capacity must be a float. ROW: {0}'.format(row[0].row)}]

        try:
            fix_dates(record['start'])
        except:
            errors += [{'message': 'Start is not a valid date format. MM/DD/YYYY ROW: {0}'.format(row[0].row)}]
        try:
            fix_dates(record['stop'])
        except:
            errors += [{'message': 'End is not a valid date format. MM/DD/YYYY ROW: {0}'.format(row[0].row)}]
        if not record['to_area_code'].lower() != 'net':
            if not verify_bool(record['roll_over_rights']):
                msg = 'Roll Over Rights must be one of the following values or blank. "YES, NO, True, False, 1, 0" ROW: {0}'.format(row[0].row)
                errors += [{'message': msg}]
            if not verify_bool(record['s0_scalable']):
                msg = 'S0 Scalable must be one of the following values or blank. "YES, NO, True, False, 1, 0" ROW: {0}'.format(row[0].row)
                errors += [{'message': msg}]
            if not verify_bool(record['s5_scalable']):
                msg = 'S5 Scalable must be one of the following values or blank. "YES, NO, True, False, 1, 0" ROW: {0}'.format(row[0].row)
                errors += [{'message': msg}]

    result = verify_areas(ws, area_owner, indexes)
    if result:
        errors += result

    result = verify_header_row(ws, header_row)
    if result:
        errors += result
    if errors:
        return errors
    else:
        return {'message': 'clean', 'records': ws}


def update_state():
    transactions = []
    for klass in BaseMemberTransaction.get_subclasses():
        transactions += klass.objects.filter(year__current=True)

    for trans in transactions:
        if trans.state == 'committed':
            continue
        try:
            trans.match()
        except TransitionNotAllowed:
            pass
        try:
            trans.collision()
        except TransitionNotAllowed:
            pass
        try:
            trans.orphan()
        except TransitionNotAllowed:
            pass


def order_element_forms(element_forms):
    return sorted(element_forms, key=lambda form: form.instance.id)
