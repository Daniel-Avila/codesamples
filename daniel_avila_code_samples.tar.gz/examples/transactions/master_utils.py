import sys

from django.contrib.contenttypes.models import ContentType
from openpyxl import Workbook
from openpyxl.writer.excel import save_virtual_workbook
from django.conf import settings

from contacts.models.organization import Organization
from .exceptions import UploadException
from transactions.transaction_tests import (verify_master_areas, verify_header_row,
                                            verify_transaction_id, verify_area_owner_number,
                                            verify_float, verify_bool)
from transactions.models import InterAreaTransaction, IntraAreaTransaction, NetTransaction
from transactions.utils import (fix_dates, match_series, make_series,
                                _insert_series, _fix_comments, set_indexes,
                                _fix_values, convert_record_to_dict, calc_headers,
                                verify_series_data, convert_to_bool, load_transactions)
from transactions.models import BaseMasterTransaction, Year, ColumnNames

import io


def make_matches():
    year = Year.objects.get(current=True)
    errors = _match_inter(year)
    errors += _match_intra(year)

    return errors


def _match_inter(year):
    inter = InterAreaTransaction.objects.filter(year=year)
    errors = []
    for record in inter:

        if record.from_area.is_member and record.to_area.is_member and not record.is_zeroed:
            try:
                candidates = InterAreaTransaction.objects.filter(year=year,
                                                                 to_area__area_owner=record.from_area.area_owner,
                                                                 from_area__area_owner=record.to_area.area_owner,
                                                                 transaction_id=record.transaction_id)
                for candidate in candidates:
                    is_match = match_series(record, candidate)
                    if is_match:
                        candidate.matching_record = record.id
                        record.matching_record = candidate.id
                        record.save()
                        candidate.save()
                if not record.matching_record:
                    message = '{0} {1} {2} {3} {4} {5} {6}'.format(record.id, record.from_area.area_owner,
                                                       record.from_area.code, record.to_area.area_owner,
                                                       record.to_area.code, record.transaction_id, record.series_data)
                    errors.append({'message': 'Match for Inter Area Record not found: {0}'.format(message)})
            except InterAreaTransaction.DoesNotExist:
                message = '{0} {1} {2} {3} {4} {5} {6}'.format(record.id, record.from_area.area_owner,
                                                       record.from_area.code, record.to_area.area_owner,
                                                       record.to_area.code, record.transaction_id, record.series_data)
                errors.append({'message': 'Match for Inter Area Record not found: {0}'.format(message)})
            except InterAreaTransaction.MultipleObjectsReturned:
                message = '{0} {1} {2} {3} {4} {5} {6}'.format(record.id, record.from_area.area_owner,
                                                       record.from_area.code, record.to_area.area_owner,
                                                       record.to_area.code, record.transaction_id, record.series_data)

                errors.append({'message': 'Multiple matches found for Inter Area Record: {0}'.format(message)})
    return errors


def _match_intra(year):
    errors = []
    intra = IntraAreaTransaction.objects.filter(year=year)
    for record in intra:
        if record.matching_record == 0:
            try:
                candidates = IntraAreaTransaction.objects.filter(year=year,
                                                                 to_area=record.from_area,
                                                                 from_area=record.to_area)
                for candidate in candidates:
                    is_match = match_series(record, candidate)
                    if is_match:
                        candidate.matching_record = record.id
                        record.matching_record = candidate.id
                        record.save()
                        candidate.save()
                        break
                if not record.matching_record:
                    message = '{0} {1} {2} {3} {4} {5} {6} {7}'.format(record.id, record.from_area.area_owner,
                                                       record.from_area.code, record.to_area.area_owner,
                                                       record.to_area.code, record.oasis_number, record.link_no, record.series_data)
                    errors.append({'message': 'Match for Intra Area Record not found: {0}'.format(message)})

            except IntraAreaTransaction.DoesNotExist:
                message = '{0} {1} {2} {3} {4}'.format(record.id, record.from_area.area_owner, record.from_area.code,
                                                       ' '.join([x['data'] for x in record.series_data]))
                errors.append({'message': 'Match for Intra Area Record not found: {0}'.format(message)})
    return errors


def build_net_records(records, header_row, year, legacy=False):

    if legacy is False:
        indexes = settings.WORKBOOK_INDEX['new_index']
    else:
        indexes = settings.WORKBOOK_INDEX['legacy_index']

    errors = []
    series_records = []
    headers, raw_headers, series_start, start = calc_headers(records, header_row)
    end = len(headers) - 1

    for raw_record in records.rows[4:]:
        if str(raw_record[0].value).lower() == 'end':
            break
        record = convert_record_to_dict(raw_record, raw_headers, series_start)
        try:
            from_org = Organization.objects.get(area_owner=record['from_area_number'],
                                                code=record['from_area_code'].strip())

            if record['to_area_code'] == 'NET':
                content_type_id = ContentType.objects.get(model=NetTransaction._meta.model_name).id
                record, o_id = process_net_transaction(record, indexes, legacy, year, from_org)
                series_records += make_series(start, end, header_row, content_type_id, o_id, raw_record)
        except Exception as ex:
            message = sys.exc_info()[1].args[0]
            error = '%s (%s) Triggerd by row --> %s values (%s)' % (message, type(ex), raw_record[0].row,
                                                                    [x.value for x in raw_record])
            errors.append({'message': error})
    if errors:
        raise UploadException('There were problems with your upload', errors)
    else:
        _insert_series(series_records)
    errors += make_matches()
    if errors:
        raise UploadException('Problems finding matches', errors)


def build_records(records, header_row, year, legacy=False):

    if legacy is False:
        indexes = settings.WORKBOOK_INDEX['new_index']
    else:
        indexes = settings.WORKBOOK_INDEX['legacy_index']

    errors = []
    series_records = []
    headers, raw_headers, series_start, start = calc_headers(records, header_row)
    end = len(headers) - 1
    rel_ref_idx = start - 1
    for raw_record in records.rows[4:]:
        if str(raw_record[0].value).lower() == 'end':
            break
        record = convert_record_to_dict(raw_record, raw_headers, series_start)
        try:
            from_org = Organization.objects.get(area_owner=record['from_area_number'],
                                                code=record['from_area_code'].strip())
            if not from_org.is_member:
                continue
            if record['to_area_code'].strip() != 'NET':
                to_org = Organization.objects.get(area_owner=record['to_area_number'],
                                                  code=record['to_area_code'].strip())

            if record['transaction_id'] is not None:
                content_type_id = ContentType.objects.get(model=InterAreaTransaction._meta.model_name).id
                record, o_id = process_inter_area_transaction(record, indexes, legacy, year, from_org, to_org,
                                                              rel_ref_idx)
                series_records += make_series(start, end, header_row, content_type_id, o_id, raw_record)

            if record['transaction_id'] is None and record['to_area_code'] != 'NET':
                content_type_id = ContentType.objects.get(model=IntraAreaTransaction._meta.model_name).id
                record, o_id = process_intra_area_transaction(record, indexes, legacy, year, from_org, to_org,
                                                              rel_ref_idx)
                series_records += make_series(start, end, header_row, content_type_id, o_id, raw_record)
        except Exception as ex:
            message = sys.exc_info()[1].args[0]
            error = '%s (%s) Triggerd by row --> values (%s)' % (message, type(ex),
                                                                 [(name, value) for name, value in record.items()])
            errors.append({'message': error})
    if errors:
        raise UploadException('There were problems with your upload', errors)
    else:
        _insert_series(series_records)
    errors += make_matches()
    if errors:
        raise UploadException('Problems finding matches', errors)


def process_inter_area_transaction(record, indexes, legacy, year, from_org, to_org, rel_ref_idx):

    comments = _fix_comments(record, indexes, legacy)
    record = _fix_values(record, indexes)
    data = {'year': year,
            'from_area': from_org,
            'to_area': to_org,
            'transaction_id': record['transaction_id'],
            'oasis_number': record['oasis_number'],
            'link_no': record['link_no'],
            'plant': record['plant'],
            'start': fix_dates(record['start']),
            'stop': fix_dates(record['stop']),
            'capacity': record['capacity'],
            'roll_over_rights': convert_to_bool(record['roll_over_rights']),
            's0_scalable': convert_to_bool(record['s0_scalable']),
            's5_scalable': convert_to_bool(record['s5_scalable']),
            'related_ref': record['related_ref'],
            'comments': comments}
    if not legacy:
        try:
            InterAreaTransaction.objects.get(id=int(record['id'].value), year__current=True).update(**data)
            o_id = int(record['id'])
        except InterAreaTransaction.DoesNotExist:
            o = InterAreaTransaction.objects.create(**data)
            o_id = o.id
    else:
        o = InterAreaTransaction.objects.create(**data)
        o_id = o.id
    return record, o_id


def process_intra_area_transaction(record, indexes, legacy, year, from_org, to_org, rel_ref_idx):
    comments = _fix_comments(record, indexes, legacy)
    record = _fix_values(record, indexes)
    data = {'year': year,
            'from_area': from_org,
            'to_area': to_org,
            'oasis_number': record['oasis_number'],
            'link_no': record['link_no'],
            'plant': record['plant'],
            'start': fix_dates(record['start']),
            'stop': fix_dates(record['stop']),
            'capacity': record['capacity'],
            'roll_over_rights': convert_to_bool(record['roll_over_rights']),
            's0_scalable': convert_to_bool(record['s0_scalable']),
            's5_scalable': convert_to_bool(record['s5_scalable']),
            'related_ref': record['related_ref'],
            'comments': comments}
    if not legacy:
        try:
            IntraAreaTransaction.objects.filter(id=int(record['id'].value), year__current=True).update(**data)
            o_id = int(record[0].value)
        except IntraAreaTransaction.DoesNotExist:
            o = IntraAreaTransaction.objects.create(**data)
            o_id = o.id
    else:
        o = IntraAreaTransaction.objects.create(**data)
        o_id = o.id
    return record, o_id


def process_net_transaction(record, indexes, legacy, year, from_org):

    comments = _fix_comments(record, indexes, legacy)
    record = _fix_values(record, indexes)

    data = {'year': year,
            'from_area': from_org,
            'to_area': 'NET',
            'comments': comments}
    if not legacy:
        try:
            NetTransaction.objects.filter(id=int(record['id']), year__current=True).update(**data)
            o_id = int(record['id'])
        except NetTransaction.DoesNotExist:
            o = NetTransaction.objects.create(**data)
            o_id = o.id
    else:
        o = NetTransaction.objects.create(**data)
        o_id = o.id
    return record, o_id
    

def verify_transactions(workbook_file, header_row, is_legacy):

    indexes = set_indexes(is_legacy)
    errors, ws = load_transactions(workbook_file, is_legacy)
    if errors:
        return errors
    headers, raw_headers, series_start, start = calc_headers(ws, header_row)
    end = len(headers) - 1
    for row in ws.rows[4:]:
        if isinstance(row[0].value, str) and row[0].value.lower() == 'end':
            break
        record = convert_record_to_dict(row, headers, start)

        if not verify_series_data(row, start, end):
            errors += [{'message': "Please verify the series data values in row {0} are all numbers".format(row[0].row)}]
        if record['transaction_id'] is not None:
            if not verify_transaction_id(record['transaction_id']):
                errors += [{'message': 'Transaction ID must be a single digit or a single uppercase letter. ROW: {0}'.format(row[0].row)}]
        if not verify_area_owner_number(record['from_area_number']):
            errors += [{'message': 'From Area Number must be an integer between 1-999 inclusive. ROW: {0}'.format(row[0].row)}]
        if not verify_area_owner_number(record['to_area_number']):
            errors += [{'message': 'To Area Number must be an integer between 1-999 inclusive. ROW: {0}'.format(row[0].row)}]
        if not verify_float(record['capacity']):
            errors += [{'message': 'Capacity must be a float. ROW: {0}'.format(row[0].row)}]

        try:
            fix_dates(record['start'])
        except:
            errors += [{'message': 'Start is not a valid date format. MM/DD/YYYY ROW: {0}'.format(row[0].row)}]
        try:
            fix_dates(record['stop'])
        except:
            errors += [{'message': 'End is not a valid date format. MM/DD/YYYY ROW: {0}'.format(row[0].row)}]

        if not record['to_area_code'].lower() != 'net':
            if not verify_bool(record['roll_over_rights']):
                msg = 'Roll Over Rights must be one of the following values or blank. "YES, NO, True, False, 1, 0" ROW: {0}'.format(row[0].row)
                errors += [{'message': msg}]
            if not verify_bool(record['s0_scalable']):
                msg = 'S0 Scalable must be one of the following values or blank. "YES, NO, True, False, 1, 0" ROW: {0}'.format(row[0].row)
                errors += [{'message': msg}]
            if not verify_bool(record['s5_scalable']):
                msg = 'S5 Scalable must be one of the following values or blank. "YES, NO, True, False, 1, 0" ROW: {0}'.format(row[0].row)
                errors += [{'message': msg}]

    result = verify_master_areas(ws, indexes)
    if result:
        errors += result

    result = verify_header_row(ws, header_row)
    if result:
        errors += result
    if errors:
        return errors
    else:
        return {'message': 'clean', 'records': ws}


def prep_record_data(record, inverted=False):
    if isinstance(record, InterAreaTransaction):
        record_data = [record.pk,
                       record.matching_record,
                       record.from_region,
                       record.from_area.area_owner,
                       record.from_area.code,
                       record.to_area.area_owner,
                       record.to_area.code,
                       record.transaction_id,
                       record.oasis_number,
                       record.link_no,
                       record.plant,
                       record.start,
                       record.stop,
                       record.capacity,
                       record.roll_over_rights,
                       record.s0_scalable,
                       record.s5_scalable,
                       record.comments,
                       record.related_ref]
    elif isinstance(record, IntraAreaTransaction):
        record_data = [record.pk,
                       record.matching_record,
                       record.from_region,
                       record.from_area.area_owner,
                       record.from_area.code,
                       record.to_area.area_owner,
                       record.to_area.code,
                       '',
                       record.oasis_number,
                       record.link_no,
                       record.plant,
                       record.start,
                       record.stop,
                       record.capacity,
                       record.roll_over_rights,
                       record.s0_scalable,
                       record.s5_scalable,
                       record.comments,
                       record.related_ref]

    if inverted:
        from_area_number = record[3]
        from_area_code = record[4]
        to_area_number = record[5]
        to_area_code = record[6]

        record[3] = to_area_number
        record[4] = to_area_code
        record[5] = from_area_number
        record[6] = from_area_code
    return record


def get_download(net=False):
    wb = Workbook()
    ws = wb.active
    ws.title = 'Transactions'
    year = Year.objects.get(current=True)
    records = []
    record_header = "masterID,matchingID,FROM REGION,From Area #,From Area,To Area #,To Area,ID,Oasis No.,Link No.,Plant,Start,Stop,Capacity,Roll Over Rights,S0 Scalable,S5 Scalable,Comments,Related Ref".split(
            ',')
    series_header = ColumnNames.objects.get(year=year).get_series_names
    header = record_header + series_header
    for i in range(len(header)):
        ws.cell(column=i + 1, row=4, value=header[i])
    if net is False:
        sub_classes = BaseMasterTransaction.get_subclasses()
        for klass in sub_classes:
            records = records + list(klass.objects.filter(year=year).order_by('id'))
    else:
        records = list(NetTransaction.objects.filter(year=year).order_by('id'))
    row_counter = 5
    for record in records:
        if isinstance(record, NetTransaction):
            record_data = [record.pk,
                           'N/A',
                           record.from_region,
                           record.from_area.area_owner,
                           record.from_area.code,
                           record.to_area,
                           record.to_area,
                           '',
                           '',
                           '',
                           '',
                           '',
                           '',
                           '',
                           '',
                           '',
                           '',
                           '',
                           '']
            for obj in record.series_objects:
                record_data.append(obj.data)
            for i in range(len(header)):
                ws.cell(column=i + 1, row=row_counter, value=record_data[i])
            row_counter += 1
        else:
            record_data = prep_record_data(record)
            for obj in record.series_objects:
                record_data.append(obj.data)
            for i in range(len(header)):
                ws.cell(column=i + 1, row=row_counter, value=record_data[i])
            row_counter += 1
            if not record.to_area.is_member:
                row_counter += 1
                inverse_record = prep_record_data(record, inverted=True)
                for obj in record.series_objects:
                    inverse_record.append(obj.data * -1)
                for i in range(len(header)):
                    ws.cell(column=i + 1, row=row_counter, value=inverse_record[i])
    out = io.BytesIO(save_virtual_workbook(wb))
    return out


def sum_master_workbook(year):

    records = IntraAreaTransaction.objects.filter(from_area__is_member=True, to_area__is_member=True, year=year)
    errors = []
    for record in records:
        match_record = IntraAreaTransaction.objects.get(id=record.matching_record)
        match_data = match_record.series_data
        record_data = record.series_data
        for point in record_data:
            point['data'] = point['data'] * -1
            if point not in match_data:
                r_msg = 'From Area: {0}:{1} To Area {2}:{3} {4}'.format(record.from_area.area_owner,
                                                                        record.from_area.code,
                                                                        record.to_area.area_owner,
                                                                        record.to_area.code,
                                                                        record_data)
                m_msg = 'From Area: {0}:{1} To Area {2}:{3} {4}'.format(match_record.from_area.area_owner,
                                                                        match_record.from_area.code,
                                                                        match_record.to_area.area_owner,
                                                                        match_record.to_area.code,
                                                                        match_data)

                error = {'message': 'Record does not zero\n{0}\n{1}'.format(r_msg, m_msg)}
                errors.append(error)
                continue

    records = InterAreaTransaction.objects.filter(from_area__is_member=True, to_area__is_member=True, year=year)
    errors = []
    for record in records:
        if record.is_zeroed:
            continue
        match_record = InterAreaTransaction.objects.get(id=record.matching_record)

        match_data = match_record.series_data
        record_data = record.series_data
        for point in record_data:
            point['data'] = point['data'] * -1
            if point not in match_data:
                r_msg = 'From Area: {0}:{1} To Area {2}:{3} {4}'.format(record.from_area.area_owner,
                                                                        record.from_area.code,
                                                                        record.to_area.area_owner,
                                                                        record.to_area.code,
                                                                        record_data)
                m_msg = 'From Area: {0}:{1} To Area {2}:{3} {4}'.format(match_record.from_area.area_owner,
                                                                        match_record.from_area.code,
                                                                        match_record.to_area.area_owner,
                                                                        match_record.to_area.code,
                                                                        match_data)

                error = {'message': 'Record does not zero\n{0}\n{1}'.format(r_msg, m_msg)}
                errors.append(error)
                continue
    if errors:
        raise UploadException("Workbook does not zero out.", errors)
