from auditlog.registry import auditlog
from django.contrib.contenttypes.fields import GenericForeignKey
from django.contrib.contenttypes.models import ContentType
from django.db import models


class SeriesElement(models.Model):
    """
    Defines the series data for a given work book year. When a new series year is "rolled over" these records
    are cloned and the series_year is set to the "Current Year" in the clone. This allows us to reconstruct historical
    copies of the work book.

    Attributes:
        SeriesElement.series_year (Year): represents the year of the workbook to which this element record belongs
        SeriesElement.content_type (ContentType): The content_type object representing the record to which this
            element belongs. This content type object will point to one of six content types: IntraAreaTransaction,
            InterAreaTransaction, NetTransaction, MemberIntraAreaTransaction, MemberInterAreaTransaction
        SeriesElement.data (int): The value of the series cell. May be a negative int. Null if not provided.
        SeriesElement.series (str): The name of the series year this cell represents
        SeriesElement.transaction (GenericForeignKey): the content type and object id of the transaction record.
        SeriesElement.formatting (text): a python dictionary expressed as a string that contains the formatting
            information from the uploaded Excel worksheet
    """

    class Meta:
        app_label = 'transactions'

    content_type = models.ForeignKey(ContentType)
    object_id = models.PositiveIntegerField()
    content_object = GenericForeignKey('content_type', 'object_id')
    data = models.IntegerField(null=True)
    series = models.CharField(max_length=8)
    formatting = models.TextField(default='')

auditlog.register(SeriesElement)
