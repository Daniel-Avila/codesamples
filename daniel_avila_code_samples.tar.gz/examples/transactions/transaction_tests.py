from contacts.models.organization import Organization
import string


def verify_bool(value):
    """This is not a true boolean test.
    Valid values were not given but we are assuming the following:

    Valid true values are True, Yes, 1, Y
    Valid false values are False, No, N, 0
    """
    if value == None:
        return True
    valid = ['true', 'yes', '1', 'y', 'false', 'no', 'n', '0']
    if str(value.lower()) in valid:
        return True
    return False


def verify_area_owner_number(value):
    if str(value).lower() == 'net':
        return True
    try:
        int(value)
        return True
    except ValueError:
        return False
    except TypeError:
        return False


def verify_float(value):
    if value is None:
        return True
    try:
        float(value)
        return True
    except ValueError:
        return False
    except TypeError:
        return False


def verify_transaction_id(value):

    if not len(str(value)) == 1:
        return False
    valid_values = string.ascii_uppercase + '0123456789'
    if str(value) not in valid_values:
        return False
    return True


def verify_areas(ws, area_owner, indexes):
    errors = []

    for trans in ws.rows[4:]:
        if str(trans[0].value).lower() == 'end':
            break
        if trans[indexes['from_area_number']].value == area_owner:
            try:
                if trans[indexes['to_area_code']].value != 'NET':

                    to_area = Organization.objects.get(code=trans[indexes['to_area_code']].value.strip(),
                                                       area_owner=trans[indexes['to_area_number']].value)
            except Organization.DoesNotExist:
                error = {'message': 'To Area Organization.DoesNotExist row -> {0} {1}:{2}'.format(trans[4].row,
                                                                                            trans[indexes['to_area_number']].value,
                                                                                            trans[indexes['to_area_code']].value.strip())}
                errors.append(error)
            except Organization.MultipleObjectsReturned:
                error = {'message': 'To Area Organization.MultipleMatches row -> {0} {1}:{2}'.format(trans[4].row,
                                                                                              trans[indexes['to_area_number']].value,
                                                                                              trans[indexes['to_area_code']].value.strip())}
                errors.append(error)
    return errors


def verify_header_row(ws, header_row):
    row = ws.rows[3]
    errors = []
    candidate = [x.value.strip() for x in row if x.value not in ['NOTES', None]]
    try:
        offset = candidate.index(header_row[0])
        end = candidate.index(header_row[-1:][0]) + 1
        candidate = candidate[offset:end]
    except ValueError:
        errors.append({'message': 'Workbook Headers do not match expected values:\r\nExpected: {0}\r\nActual{1}'.format(
            ','.join(header_row), ','.join(candidate)
        )})

    if len(candidate) != len(header_row):
        errors.append({'message': 'Headers do not match workbook.\r\n Workbook: len {0} {1}\r\nInput: len {2}--------{3}'.format(
            len(candidate), ','.join(candidate), len(header_row), ','.join(header_row)
        )})
    if not candidate == header_row:
        errors.append({'message': 'Headers do not match workbook order.\r\n Workbook: {0}\r\nInput:--------{1}'.format(
            ','.join(candidate), ','.join(header_row)
        )})
    return errors


def verify_master_areas(ws, indexes):
    errors = []
    for trans in ws.rows[4:]:
        if str(trans[0].value).lower() == 'end':
            break
        if not all([trans[indexes['from_area_number']].value, trans[indexes['from_area_code']].value,
                    trans[indexes['to_area_number']].value, trans[indexes['to_area_code']].value]):

            msg = 'From Area #: {0} From Area: {1} To Area #: {2} To Area: {3}'.format(
                trans[indexes['from_area_number']].value, trans[indexes['from_area_code']].value,
                trans[indexes['to_area_number']].value, trans[indexes['to_area_code']].value)

            error = {'message': 'Record missing required value row {0}: {1}'.format(trans[0].row, msg)}
            errors.append(error)
            continue
        try:
            int(trans[indexes['from_area_number']].value)
        except ValueError:
            msg = 'From area number must be an int. Found string'
            error = {'message': 'Record missing required value row {0}: {1}'.format(trans[0].row, msg)}
            errors.append(error)
            continue
        try:
            if trans[indexes['to_area_code']].value != 'NET':
                int(trans[indexes['to_area_number']].value)
        except ValueError:
            msg = 'To area number must be an int. Found string'
            error = {'message': 'Record missing required value row {0}: {1}'.format(trans[0].row, msg)}
            errors.append(error)
            continue
        try:
            if trans[indexes['to_area_code']].value != 'NET':
                to_area = Organization.objects.get(code=trans[indexes['to_area_code']].value.strip(),
                                                   area_owner=trans[indexes['to_area_number']].value)
        except Organization.DoesNotExist:
            error = {'message': 'To Area Organization.DoesNotExist row -> {0} {1}:{2}'.format(
                trans[indexes['from_area_code']].row, trans[indexes['to_area_number']].value,
                trans[indexes['to_area_code']].value)}

            errors.append(error)
        except Organization.MultipleObjectsReturned:
            error = {'message': 'To Area Organization.MultipleMatches row -> {0} {1}:{2}'.format(
                trans[indexes['from_area_code']].row, trans[indexes['to_area_number']].value,
                trans[indexes['to_area_code']].value)}

            errors.append(error)
        try:
            if trans[indexes['from_area_code']].value != 'NET':
                from_area = Organization.objects.get(code=trans[indexes['from_area_code']].value.strip(),
                                                     area_owner=trans[indexes['from_area_number']].value)
        except Organization.DoesNotExist:
            error = {'message': 'From Area Organization.DoesNotExist row -> {0} {1}:{2}'.format(trans[3].row,
                                                                                                trans[indexes['from_area_number']].value,
                                                                                                trans[indexes['from_area_code']].value)}
            errors.append(error)
        except Organization.MultipleObjectsReturned:
            error = {'message': 'From Area Organization.MultipleMatches row -> {0} {1}:{2}'.format(trans[3].row,
                                                                                                   trans[indexes['from_area_number']].value,
                                                                                                   trans[indexes['from_area_code']].value)}
            errors.append(error)
    return errors

