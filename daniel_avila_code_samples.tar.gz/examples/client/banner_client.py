"""
BannerClient

This is the sub client which defines all the banner managment functionality
"""

from mixin import OpenXMixIn
from django.conf import settings
from adcoin_openx.exceptions import AdcoinException
import json


class BannerClient(OpenXMixIn):
    # ================  Banner statistics methods below this line ===============

    def get_banner_stats_by_date(self, banner_id, start_date, end_date):
        """Get banner stats by day

        Args:
            banner_id (int): id for banner we're interested in
            start_date (str): start date must be in yyyy-mm-dd format
            end_date (str): end date must be in yyyy-mm-dd format
        """
        payload = {}
        endpoint = '%s/%s/statistics/daily/%s/%s' % (settings.OPENX_GET_BANNER,
                                                     banner_id, start_date,
                                                     end_date)
        return json.loads(self._get(endpoint, payload))

    def get_banner_stats_by_pub(self, banner_id, start_date, end_date):
        """Get banner stats by publisher

        Args:
            banner_id (int): id for banner we're interested in
            start_date (str): start date must be in yyyy-mm-dd format
            end_date (str): end date must be in yyyy-mm-dd format
        """
        payload = {}
        endpoint = '%s/%s/statistics/publisher/%s/%s' % (settings.OPENX_GET_BANNER,
                                                         banner_id, start_date,
                                                         end_date)
        return json.loads(self._get(endpoint, payload))

    def get_banner_stats_by_zone(self, banner_id, start_date, end_date):
        """Get banner stats by zone

        Args:
            banner_id (int): id for banner we're interested in
            start_date (str): start date must be in yyyy-mm-dd format
            end_date (str): end date must be in yyyy-mm-dd format
        """
        payload = {}
        endpoint = '%s/%s/statistics/zone/%s/%s' % (settings.OPENX_GET_BANNER,
                                                    banner_id, start_date,
                                                    end_date)
        return json.loads(self._get(endpoint, payload))

    # ================  Banner management methods below this line ===============

    def add_banner_target(self, banner_id, logical, limit, comp, data):
        """Sets all delivery limitations for a banner

        Args:
            banner_id (int): A banner id
            logical (enum): enum of logical parameters (and,or)
            limit (str): type of delivery limitation
            comparation (enum): type of comparation
            data (str): comparation data

        Returns:
            dictionary of banner delivery limitations
        """

        valid_types = ['and', 'or']
        # TODO: need to verify actual comp types once OpenX server is up
        comp_types = ['<', '>', '==', '!=']

        if logical not in valid_types:
            msg = 'logical expects %s got %s' % (', '.join(valid_types),
                                                 logical)
            raise AdcoinException(msg)
        elif comp not in comp_types:
            msg = 'comparation expects %s got %s' % (', '.join(comp_types),
                                                     comp)
            raise AdcoinException(msg)

        endpoint = '%s/targeting' % banner_id
        payload = {'logical': logical,
                   'type': limit,
                   'comparation': comp,
                   'data': data}
        endpoint = '%s/%s' % (settings.OPENX_GET_BANNER, endpoint)
        result = self._post(endpoint, payload)
        if result == '{"OK"}':  # The rest api does not return valid json
            return {'result': 'OK'}

    def add_banner(self, campaign, banner, storage, image, html, width, height,
                   weight, url):
        """Add a new banner to the OPENX server

        Args:
            campaign (int): sets the campaign ID for the banner
            banner (str): optional name of the banner
            storage (enum): optional enum type of storage (html, txt, sql, web,
                            url, video)
            image (str): optional image URL
            html (str): optional banner html
            width (int): optional width of banner
            height (int): optional height of banner
            weight (int): optional weight of banner
            url (str): optional destination url

        Returns:
            dictionary of the result
        """
        valid_types = ['html', 'txt', 'sql', 'web', 'url', 'video']
        if storage not in valid_types:
            msg = 'storage expects %s got %s' % (', '.join(valid_types),
                                                 storage)
            raise AdcoinException(msg)

        payload = {'campaignId': campaign,
                   'bannerName': banner,
                   'storageType': storage,
                   'imageURL': image,
                   'htmlTemplate': html,
                   'width': width,
                   'height': height,
                   'weight': weight,
                   'url': url}

        result = self._post(settings.OPENX_NEW_BANNER, payload)
        if result == '{"OK"}':  # The rest api does not return valid json
            return {'result': 'OK'}

    def delete_banner(self, banner_id):
        """Delete a banner ID

        Args:
            banner_id (int): A banner id

        Returns:
            json string of the result
        """

        return json.loads(self._delete(settings.OPENX_GET_BANNER, banner_id))

    def get_banner(self, banner_id):
        """Return a banner

        Args:
            banner_id (int): A banner id

        Returns:
            dictionary of banner data
        """

        return json.loads(self._get(settings.OPENX_GET_BANNER, banner_id))

    def get_banner_campaign(self, campaign_id):
        """Return all campaigns from a banner

        Args:
            campaign_iD (int): A banner id

        Returns:
            dictionary of banner campaign data
        """

        return json.loads(self._get(settings.OPENX_GET_BANNER_CAMPAIGN,
                                    campaign_id))

    def get_banner_target(self, banner_id):
        """Return all delivery limitations for a banner

        Args:
            banner_id (int): A banner id

        Returns:
            dictionary of banner delivery limitations
        """

        payload = '%s/targeting' % banner_id
        return json.loads(self._get(settings.OPENX_GET_BANNER, payload))


    def modify_banner_campaign(self, banner_id, campaign):
        """Set the campaign ID

        Args:
            banner_id (int): The banner being changed
            campaign (int): The new campaign ID

        Returns:
            dictionary of response from openx
        """

        payload = {'campaignId': campaign}
        endpoint = '%s/%s' % (settings.OPENX_GET_BANNER, banner_id)
        result = self._post(endpoint, payload)
        if result == '{"OK"}':  # The rest api does not return valid json
            return {'result': 'OK'}

    def modify_banner_height(self, banner_id, height):
        """Set the banner height

        Args:
            banner_id (int): The banner being changed
            height (int): The new banner height

        Returns:
            Dictionary of response from openx
        """

        payload = {'height': height}
        endpoint = '%s/%s' % (settings.OPENX_GET_BANNER, banner_id)
        result = self._post(endpoint, payload)
        if result == '{"OK"}':  # The rest api does not return valid json
            return {'result': 'OK'}

    def modify_banner_name(self, banner_id, banner):
        """Set the banner name

        Args:
            banner_id (int): The banner being changed
            banner (str): The new banner name

        Returns:
            Dictionary of response from openx server
        """

        payload = {'bannerName': banner}
        endpoint = '%s/%s' % (settings.OPENX_GET_BANNER, banner_id)
        result = self._post(endpoint, payload)
        if result == '{"OK"}':  # The rest api does not return valid json
            return {'result': 'OK'}

    def modify_banner_image(self, banner_id, image):
        """Set the banner image URL

        Args:
            banner_id (int): The banner being changed
            image (str): The new banner image URL

        Returns:
            Dictionary of response from openx server
        """

        payload = {'imageURL': image}
        endpoint = '%s/%s' % (settings.OPENX_GET_BANNER, banner_id)
        result = self._post(endpoint, payload)
        if result == '{"OK"}':  # The rest api does not return valid json
            return {'result': 'OK'}

    def modify_banner_html(self, banner_id, html):
        """Set the banner html

        Args:
            banner_id (int): The banner being changed
            html (str): The new banner HTML

        Returns:
            Dictionary of response from openx server
        """

        payload = {'htmlTemplate': html}
        endpoint = '%s/%s' % (settings.OPENX_GET_BANNER, banner_id)
        result = self._post(endpoint, payload)
        if result == '{"OK"}':  # The rest api does not return valid json
            return {'result': 'OK'}


    def modify_banner_url(self, banner_id, url):
        """Set the banner destination URL

        Args:
            banner_id (int): The banner being changed
            url (str): The new banner URL

        Returns:
            Dictionary of response from openx server
        """

        payload = {'url': url}
        endpoint = '%s/%s' % (settings.OPENX_GET_BANNER, banner_id)
        result = self._post(endpoint, payload)
        if result == '{"OK"}':  # The rest api does not return valid json
            return {'result': 'OK'}

    def modify_banner_storage(self, banner_id, storage):
        """Set the banner storage type

        Args:
            banner_id (int): The banner being changed
            storage (str): The new banner storage type

        Returns:
            Dictionary of response from openx server
        """
        valid_types = ['html', 'txt', 'sql', 'web', 'url', 'video']
        if storage not in valid_types:
            msg = 'storage expects %s got %s' % (', '.join(valid_types),
                                                 storage)
            raise AdcoinException(msg)

        payload = {'storageType': storage}
        endpoint = '%s/%s' % (settings.OPENX_GET_BANNER, banner_id)
        result = self._post(endpoint, payload)
        if result == '{"OK"}':  # The rest api does not return valid json
            return {'result': 'OK'}

    def modify_banner_weight(self, banner_id, weight):
        """Set the banner weight

        Args:
            banner_id (int): The banner being changed
            weight (int): The new banner weight

        Returns:
            Dictionary of response from openx server
        """

        payload = {'weight': weight}
        endpoint = '%s/%s' % (settings.OPENX_GET_BANNER, banner_id)
        result = self._post(endpoint, payload)
        if result == '{"OK"}':  # The rest api does not return valid json
            return {'result': 'OK'}

    def modify_banner_width(self, banner_id, width):
        """Set the banner width

        Args:
            banner_id (int): The banner being changed
            width (int): The new banner width

        Returns:
            Dictionary of response from openx server
        """

        payload = {'width': width}
        endpoint = '%s/%s' % (settings.OPENX_GET_BANNER, banner_id)
        result = self._post(endpoint, payload)
        if result == '{"OK"}':  # The rest api does not return valid json
            return {'result': 'OK'}


