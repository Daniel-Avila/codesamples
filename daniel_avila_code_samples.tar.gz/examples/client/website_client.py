"""
WebsiteClient

This is the sub client which defines all the website managment functionality
"""

from mixin import OpenXMixIn
from django.conf import settings
import json


class WebsiteClient(OpenXMixIn):
    # ================  Website statistics methods below this line ===============

    def get_publisher_stats_by_date(self, publisher_id, start_date, end_date):
        """Get publisher stats by day

        Args:
            publisher_id (int): id for the publisher we're interested in
            start_date (str): start date must be in yyyy-mm-dd format
            end_date (str): end date must be in yyyy-mm-dd format"""
        payload = {}
        endpoint = '%s/%s/statistics/daily/%s/%s' % (settings.OPENX_GET_PUBLISHER,
                                                     publisher_id, start_date,
                                                     end_date)
        return json.loads(self._get(endpoint, payload))

    def get_publisher_stats_by_zone(self, publisher_id, start_date, end_date):
        """Get publisher stats by zone

        Args:
            publisher_id (int): id for the publisher we're interested in
            start_date (str): start date must be in yyyy-mm-dd format
            end_date (str): end date must be in yyyy-mm-dd format"""
        payload = {}
        endpoint = '%s/%s/statistics/zone/%s/%s' % (settings.OPENX_GET_PUBLISHER,
                                                    publisher_id, start_date,
                                                    end_date)
        return json.loads(self._get(endpoint, payload))

    def get_publisher_stats_by_advertiser(self, publisher_id, start_date, end_date):
        """Get publisher stats by advertiser

        Args:
            publisher_id (int): id for the advertiser we're interested in
            start_date (str): start date must be in yyyy-mm-dd format
            end_date (str): end date must be in yyyy-mm-dd format"""
        payload = {}
        # TODO: need to verify actual endpoint since docs reference both /statistics/publisher
        # and /statistics/advertiser
        endpoint = '%s/%s/statistics/publisher/%s/%s' % (settings.OPENX_GET_PUBLISHER,
                                                         publisher_id, start_date,
                                                         end_date)
        return json.loads(self._get(endpoint, payload))

    def get_publisher_stats_by_campaign(self, publisher_id, start_date, end_date):
        """Get publisher stats by campaign

        Args:
            publisher_id (int): id for the advertiser we're interested in
            start_date (str): start date must be in yyyy-mm-dd format
            end_date (str): end date must be in yyyy-mm-dd format"""
        payload = {}
        endpoint = '%s/%s/statistics/campaign/%s/%s' % (settings.OPENX_GET_PUBLISHER,
                                                        publisher_id, start_date,
                                                        end_date)
        return json.loads(self._get(endpoint, payload))

    def get_publisher_stats_by_banner(self, publisher_id, start_date, end_date):
        """Get publisher stats by banner

        Args:
            publisher_id (int): id for the advertiser we're interested in
            start_date (str): start date must be in yyyy-mm-dd format
            end_date (str): end date must be in yyyy-mm-dd format"""
        payload = {}
        endpoint = '%s/%s/statistics/banner/%s/%s' % (settings.OPENX_GET_PUBLISHER,
                                                      publisher_id, start_date,
                                                      end_date)
        return json.loads(self._get(endpoint, payload))

    # ================  Website management methods below this line ===============

    def delete_publisher(self, publisher_id):
        """Delete an existing publisher from openx

        Args:
            publisher_id (int) The id of the publisher you wish to delete

        Returns:
            dictionary of result from openx server
        """

        return json.loads(self._delete(settings.OPENX_GET_PUBLISHER,
                                       publisher_id))

    def modify_publisher_name(self, publisher_id, name):
        """Set the publishers name

        Args:
            publisher_id (int): The publisher being changed
            name (str): The new publisher name
        Returns:
            Dictionary of resposne from openx
        """
        payload = {'publisherName': name if name else ''}
        endpoint = '%s/%s' % (settings.OPENX_GET_PUBLISHER, publisher_id)
        result = self._post(endpoint, payload)
        if result == '{"OK"}':  # The rest api does not return valid json
            return {'result': 'OK'}

    def modify_publisher_email(self, publisher_id, email):
        """Set the publishers email address

        Args:
            publisher_id (int): The publisher being changed
            email (str): The new email address
        Returns:
            Dictionary of resposne from openx
        """
        payload = {'emailAddress': email if email else ''}
        endpoint = '%s/%s' % (settings.OPENX_GET_PUBLISHER, publisher_id)
        result = self._post(endpoint, payload)
        if result == '{"OK"}':  # The rest api does not return valid json
            return {'result': 'OK'}

    def modify_publisher_contact(self, publisher_id, contact_name):
        """Set the publishers contact_name

        Args:
            publisher_id (int): The publisher being changed
            contact_name (str): The new contact name
        Returns:
            Dictionary of resposne from openx
        """
        payload = {'contactName': contact_name if contact_name else ''}
        endpoint = '%s/%s' % (settings.OPENX_GET_PUBLISHER, publisher_id)
        result = self._post(endpoint, payload)
        if result == '{"OK"}':  # The rest api does not return valid json
            return {'result': 'OK'}

    def modify_publisher_agency(self, publisher_id, agency_id):
        """Set the publishers agency

        Args:
            publisher_id (int): The publisher being changed
            agency_id (int): The new agency
        Returns:
            Dictionary of resposne from openx
        """
        payload = {'agencyId': agency_id if agency_id else ''}
        endpoint = '%s/%s' % (settings.OPENX_GET_PUBLISHER, publisher_id)
        result = self._post(endpoint, payload)
        if result == '{"OK"}':  # The rest api does not return valid json
            return {'result': 'OK'}

    def get_pub_agency(self, agency_id):
        """Return the list of publishers for a given agency id

            Args:
                agency_id (int): The agency identifier

            Returns:
                dictionary of result data
        """

        return json.loads(self._get(settings.OPENX_GET_PUB_AGC, agency_id))

    def get_publisher(self, publisher_id):
        """Return the publisher for a given id

            Args:
                publisher_id (int): The account identifier

            Returns:
                dictionary of result data
        """

        return json.loads(self._get(settings.OPENX_GET_PUBLISHER,
                                    publisher_id))

    def add_publisher(self, agency_id=None, publisher_name=None,
                      contact_name=None, email=None):
        """Add a new publisher to the openx server

        Args:
            agency_id (int): Optional an agency id
            publisher_name (str): Optional publisher name Defaults to Untitled
            contact_name (str): Optional publisher contact name
            email (str): Optional publisher email address

        Returns
            dictionary of the json response from the openx server
        """
        payload = {}
        if agency_id is not None:
            payload['agencyId'] = agency_id
        if publisher_name is not None:
            payload['publisherName'] = publisher_name
        if contact_name is not None:
            payload['contactName'] = contact_name
        if email is not None:
            payload['emailAddress'] = email

        result = self._post(settings.OPENX_NEW_PUBLISHER, payload)
        if result == '{"OK"}':  # The rest api does not return valid json
            return {'result': 'OK'}


