"""
AgencyClient

This is the sub client which defines all the agency managment functionality
"""

from mixin import OpenXMixIn
from django.conf import settings
import json


class AgencyClient(OpenXMixIn):

    # ================= agency statistics below ===============================

    def get_agency_stats_by_date(self, agency_id, start_date, end_date):
        """Get agency stats by day

        Args:
            agency_id (int): id for agency we're interested in
            start_date (str): start date must be in yyyy-mm-dd format
            end_date (str): end date must be in yyyy-mm-dd format"""
        payload = {}
        endpoint = '%s/%s/statistics/daily/%s/%s' % (settings.OPENX_GET_AGENCY,
                                                     agency_id, start_date,
                                                     end_date)
        return json.loads(self._get(endpoint, payload))

    def get_agency_stats_by_zone(self, agency_id, start_date, end_date):
        """Get agency stats by zone

        Args:
            agency_id (int): id for agency we're interested in
            start_date (str): start date must be in yyyy-mm-dd format
            end_date (str): end date must be in yyyy-mm-dd format"""
        payload = {}
        endpoint = '%s/%s/statistics/zone/%s/%s' % (settings.OPENX_GET_AGENCY,
                                                    agency_id, start_date,
                                                    end_date)
        return json.loads(self._get(endpoint, payload))

    def get_agency_stats_by_publisher(self, agency_id, start_date, end_date):
        """Get agency stats by publisher

        Args:
            agency_id (int): id for agency we're interested in
            start_date (str): start date must be in yyyy-mm-dd format
            end_date (str): end date must be in yyyy-mm-dd format"""
        payload = {}
        endpoint = '%s/%s/statistics/publisher/%s/%s' % (settings.
                                                         OPENX_GET_AGENCY,
                                                         agency_id, start_date,
                                                         end_date)
        return json.loads(self._get(endpoint, payload))

    def get_agency_stats_by_banner(self, agency_id, start_date, end_date):
        """Get agency stats by banner

        Args:
            agency_id (int): id for agency we're interested in
            start_date (str): start date must be in yyyy-mm-dd format
            end_date (str): end date must be in yyyy-mm-dd format"""
        payload = {}
        endpoint = '%s/%s/statistics/banner/%s/%s' % (settings.OPENX_GET_AGENCY,
                                                      agency_id, start_date,
                                                      end_date)
        return json.loads(self._get(endpoint, payload))

    def get_agency_stats_by_campaign(self, agency_id, start_date, end_date):
        """Get agency stats by campaign

        Args:
            agency_id (int): id for agency we're interested in
            start_date (str): start date must be in yyyy-mm-dd format
            end_date (str): end date must be in yyyy-mm-dd format"""
        payload = {}
        endpoint = '%s/%s/statistics/campaign/%s/%s' % (settings.
                                                        OPENX_GET_AGENCY,
                                                        agency_id, start_date,
                                                        end_date)
        return json.loads(self._get(endpoint, payload))

    def get_agency_stats_by_advertiser(self, agency_id, start_date, end_date):
        """Get agency stats by advertiser

        Args:
            agency_id (int): id for agency we're interested in
            start_date (str): start date must be in yyyy-mm-dd format
            end_date (str): end date must be in yyyy-mm-dd format"""
        payload = {}
        endpoint = '%s/%s/statistics/advertiser/%s/%s' % (settings.
                                                          OPENX_GET_AGENCY,
                                                          agency_id, start_date,
                                                          end_date)
        return json.loads(self._get(endpoint, payload))

    # ================= agency management below ===============================

    def get_agency(self, agency_id):
        """Return an agency

        Args:
            agency_id (int): An agency id

        Returns:
            dictionary of agency data
        """

        return json.loads(self._get(settings.OPENX_GET_AGENCY, agency_id))

    def delete_agency(self, agency_id):
        """Delete an agency

        Args:
            agency_id (int): An agency id

        Returns:
            json string of the result
        """

        return json.loads(self._delete(settings.OPENX_GET_AGENCY, agency_id))

    def get_agency_list(self):
        """Return a list of existing agencies

        Returns:
            dictionary of agency data
        """

        return json.loads(self._get(settings.OPENX_GET_AGENCY_LIST,
                                    payload=''))

    def add_agency(self, agency, contact, email, username, password):
        """Add a new agency to the openx server

        Args:
            agency (str): name of the agency
            contact (str): contact name
            email (str): optional email address
            username (str): optional username
            password (str): optional password

        Returns:
            dictionary of the result data
        """

        payload = {'agencyName': agency,
                   'contactName': contact,
                   'emailAddress': email,
                   'username': username,
                   'password': password}

        result = self._post(settings.OPENX_NEW_AGENCY, payload)
        if result == '{"OK"}':  # The rest api does not return valid json
            return {'result': 'OK'}

    def modify_agency_name(self, agency_id, agency):
        """Modify the agency name

        Args:
            agency_id (int): agency id
            agency (str): agency name

        Returns:
            Dictionary of response from openx server
        """

        payload = {'agencyName': agency}
        endpoint = '%s/%s' % (settings.OPENX_GET_AGENCY, agency_id)
        result = self._post(endpoint, payload)
        if result == '{"OK"}':  # The rest api does not return valid json
            return {'result': 'OK'}

    def modify_agency_contact(self, agency_id, contact):
        """Modify the agency contact name

        Args:
            agency_id (int): agency id
            contact (str): agency contact name

        Returns:
            Dictionary of response from openx server
        """

        payload = {'contactName': contact}
        endpoint = '%s/%s' % (settings.OPENX_GET_AGENCY, agency_id)
        result = self._post(endpoint, payload)
        if result == '{"OK"}':  # The rest api does not return valid json
            return {'result': 'OK'}

    def modify_agency_email(self, agency_id, email):
        """Modify the agency email name

        Args:
            agency_id (int): agency id
            email (str): agency email address

        Returns:
            Dictionary of response from openx server
        """

        payload = {'emailAddress': email}
        endpoint = '%s/%s' % (settings.OPENX_GET_AGENCY, agency_id)
        result = self._post(endpoint, payload)
        if result == '{"OK"}':  # The rest api does not return valid json
            return {'result': 'OK'}

    def modify_agency_username(self, agency_id, username):
        """Modify the agency user name

        Args:
            agency_id (int): agency id
            username (str): agency user name

        Returns:
            Dictionary of response from openx server
        """

        payload = {'username': username}
        endpoint = '%s/%s' % (settings.OPENX_GET_AGENCY, agency_id)
        result = self._post(endpoint, payload)
        if result == '{"OK"}':  # The rest api does not return valid json
            return {'result': 'OK'}

    def modify_agency_password(self, agency_id, password):
        """Modify the agency name

        Args:
            agency_id (int): agency id
            password (str): agency user password

        Returns:
            Dictionary of response from openx server
        """

        payload = {'password': password}
        endpoint = '%s/%s' % (settings.OPENX_GET_AGENCY, agency_id)
        result = self._post(endpoint, payload)
        if result == '{"OK"}':  # The rest api does not return valid json
            return {'result': 'OK'}
