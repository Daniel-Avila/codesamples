"""OpenX API Client

The Revive (OpenX) ad server exposes a RESTFul API via the
http://www.openxsourcerestapi.com/ plugin.

The client designed here leverages the documentation located at
http://www.reviveadserverrestapi.com/api-documentation/

Examples:

    client = OpenXAPIClient()
    user_info = client.users.get_user(user_id=uid)


"""
from user_client import UserClient
from agency_client import AgencyClient
from banner_client import BannerClient
from zone_client import ZoneClient
from campaign_client import CampaignClient
from website_client import WebsiteClient
from advertiser_client import AdvertiserClient
from channel_client import ChannelClient


class OpenXAPIClient(object):
    """
    The API client which pulls together all the functionality.
    """

    def __init__(self):
        """Set up our client by pulling in all the parts"""

        self.users = UserClient()
        self.agency = AgencyClient()
        self.banner = BannerClient()
        self.zone = ZoneClient()
        self.publisher = WebsiteClient()
        self.campaign = CampaignClient()
        self.advertiser = AdvertiserClient()
        self.channel = ChannelClient()
        # since in different contexts we might call this different names
        self.website = self.publisher
