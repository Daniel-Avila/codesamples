"""
ChannelClient

This is the sub client which defines all the channel managment functionality
"""

from mixin import OpenXMixIn
from django.conf import settings
from adcoin_openx.exceptions import AdcoinException
import json


class ChannelClient(OpenXMixIn):

    def get_channel(self, channel_id):
        """Return a channel

        Args:
            channel_id (int): A channel id

        Returns:
            dictionary of channel data
        """

        return json.loads(self._get(settings.OPENX_GET_CHANNEL, channel_id))

    def add_channel(self, channel_name, agency_id, website_id, channel_desc,
                    comments):
        """Add a new channel to the OPENX server

        Args:
            channel_name (str): sets the name for the channel
            agency_id (int): optional filter by agency
            website_id (int): optional filter by website
            channel_desc (str): optional channel description
            comment (str): optional channel comments

        Returns:
            dictionary of the result
        """

        payload = {'channelName': channel_name,
                   'agencyId': agency_id,
                   'websiteId': website_id,
                   'Description': channel_desc,
                   'comments': comments}

        result = self._post(settings.OPENX_GET_CHANNEL, payload)
        if result == '{"OK"}':  # The rest api does not return valid json
            return {'result': 'OK'}

    def add_channel_target(self, channel_id, logical, limit, comp, data):
        """Sets all delivery limitations for a channel

        Args:
            channel_id (int): A channel id
            logical (enum): enum of logical parameters (and,or)
            limit (str): type of delivery limitation
            comparation (enum): type of comparation
            data (str): comparation data

        Returns:
            dictionary of channel delivery limitations
        """

        valid_types = ['and', 'or']
        comp_types = ['<', '>', '==', '!=']

        if logical not in valid_types:
            msg = 'logical expects %s got %s' % (', '.join(valid_types),
                                                 logical)
            raise AdcoinException(msg)
        elif comp not in comp_types:
            msg = 'comparation expects %s got %s' % (', '.join(comp_types),
                                                     comp)
            raise AdcoinException(msg)

        endpoint = '%s/targeting' % channel_id
        payload = {'logical': logical,
                   'type': limit,
                   'comparation': comp,
                   'data': data}
        endpoint = '%s/%s' % (settings.OPENX_GET_CHANNEL, endpoint)
        result = self._post(endpoint, payload)
        if result == '{"OK"}':  # The rest api does not return valid json
            return {'result': 'OK'}

    def delete_channel(self, channel_id):
        """Delete a channel

        Args:
            channel_id (int): A channel id

        Returns:
            json string of the result
        """

        return json.loads(self._delete(settings.OPENX_GET_CHANNEL, channel_id))

    def modify_channel_name(self, channel_id, channel_name):
        """Set the channel name

        Args:
            chanel_id (int): The channel being changed
            channel_name (str): The new channel name

        Returns:
            dictionary of response from openx
        """

        payload = {'channelName': channel_name}
        endpoint = '%s/%s' % (settings.OPENX_GET_CHANNEL, channel_id)
        result = self._post(endpoint, payload)
        if result == '{"OK"}':  # The rest api does not return valid json
            return {'result': 'OK'}

    def modify_channel_agency(self, channel_id, agency_id):
        """Set the channel agency_id

        Args:
            chanel_id (int): The channel being changed
            agency_id (int): The new channel agency_id

        Returns:
            dictionary of response from openx
        """

        payload = {'agencyId': agency_id}
        endpoint = '%s/%s' % (settings.OPENX_GET_CHANNEL, channel_id)
        result = self._post(endpoint, payload)
        if result == '{"OK"}':  # The rest api does not return valid json
            return {'result': 'OK'}

    def modify_channel_website(self, channel_id, website_id):
        """Set the channel website_id

        Args:
            chanel_id (int): The channel being changed
            website_id (int): The new channel website_id

        Returns:
            dictionary of response from openx
        """

        payload = {'websiteId': website_id}
        endpoint = '%s/%s' % (settings.OPENX_GET_CHANNEL, channel_id)
        result = self._post(endpoint, payload)
        if result == '{"OK"}':  # The rest api does not return valid json
            return {'result': 'OK'}

    def modify_channel_description(self, channel_id, channel_desc):
        """Set the channel description

        Args:
            chanel_id (int): The channel being changed
            channel_desc (str): The new channel description

        Returns:
            dictionary of response from openx
        """

        payload = {'Description': channel_desc}
        endpoint = '%s/%s' % (settings.OPENX_GET_CHANNEL, channel_id)
        result = self._post(endpoint, payload)
        if result == '{"OK"}':  # The rest api does not return valid json
            return {'result': 'OK'}

    def modify_channel_comments(self, channel_id, comments):
        """Set the channel comments

        Args:
            chanel_id (int): The channel being changed
            comments (str): The new channel comments

        Returns:
            dictionary of response from openx
        """

        payload = {'comments': comments}
        endpoint = '%s/%s' % (settings.OPENX_GET_CHANNEL, channel_id)
        result = self._post(endpoint, payload)
        if result == '{"OK"}':  # The rest api does not return valid json
            return {'result': 'OK'}


    def get_channel_website(self, website_id):
        """Get the list of channels by website

        Args:
            website_id (int): The website we care about

        Returns:
            Dictionary of channels by website
        """

        return json.loads(self._get(settings.OPENX_GET_CHANNEL_WEBSITE,
                                    website_id))

    def get_channel_agency(self, agency_id):
        """Get the list of channels by agency

        Args:
            agency_id (int): The agency we care about

        Returns:
            Dictionary of channels by agency
        """

        return json.loads(self._get(settings.OPENX_GET_CHANNEL_AGENCY,
                                    agency_id))
    def get_channel_target(self, channel_id):
        """Return all delivery limitations for a channel

        Args:
            channel_id (int): A channel id

        Returns:
            dictionary of channel delivery limitations
        """

        payload = '%s/targeting' % channel_id
        return json.loads(self._get(settings.OPENX_GET_BANNER, payload))
