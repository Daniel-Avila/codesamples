from django.conf import settings
import json
import requests


class OpenXMixIn(object):
    """
    OpenXMixIn provides the interface to actually send and receive
    information from the OpenX Ad Server via the Rest API
    """

    def _get(self, endpoint, payload):
        """Send a get query to the openx server

        Args:
            endpoint (str) The endpoint being contacted
            payload (str) optional The payload appended to the endpoint

        Returns:
            dictionary of result data
        """

        return self._send_request('get', endpoint, payload)

    def _post(self, endpoint, payload):
        """Send a post to the openx server

        Args:
            endpoint (str): the endpoint being called
            payload (dict): The data being posted to the server

        Returns:
            json string of the result
        """
        payload = json.dumps(payload)
        return self._send_request('post', endpoint, payload)

    def _delete(self, endpoint, payload):
        """Send a delete to the openx server

        Args:
            endpoint (str): the endpoint being called
            payload (str): optional The payload appended to the endpoint

        Returns:
            json string of the result
        """

        return self._send_request('delete', endpoint, payload)

    def _make_url(self, endpoint):
        """Add the url to the endpoint

        Args:
            endpoint (str): the endpoint we are contacting
        Returns
            str of host plus the endpoint
        """

        return '%s/%s' % (settings.OPENX_HOST, endpoint)

    def _send_request(self, method, endpoint, payload=''):
        """Send the request to the openx server

        Args:
            method (str): The HTTP method to call on the end point
            endpoint (str): The endpont being called
            payload (str): An optional json payload being sent to the server
            data to the sever
        """
        url = self._make_url(endpoint)
        headers = {'Content-Type': 'text/javascript'}
        if method == 'post':
            result = requests.post(url, data=payload, headers=headers,
                                   auth=settings.OPENX_AUTH)
        elif method == 'get':
            url = '%s/%s' % (url, payload)
            result = requests.get(url, headers=headers,
                                  auth=settings.OPENX_AUTH)
        elif method == 'delete':
            url = '%s/%s' % (url, payload)
            result = requests.delete(url, headers=headers,
                                     auth=settings.OPENX_AUTH)
        if result.status_code == 200 and not result.content:
            return '{"OK"}'
        elif result.status_code == 200 and result.content:
            return result.content
        else:
            result.raise_for_status()
            return result.content
