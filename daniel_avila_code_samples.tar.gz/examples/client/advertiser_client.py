"""
AdvertiserClient

This is the sub client which defines all the user managment functionality
"""

from mixin import OpenXMixIn
from django.conf import settings
import json


class AdvertiserClient(OpenXMixIn):

    # ================  Advertiser statistics methods below this line ===============

    def get_advertiser_stats_by_date(self, advertiser_id, start_date, end_date):
        """Get advertiser stats by day

        Args:
            advertiser_id (int): id for advertiser we're interested in
            start_date (str): start date must be in yyyy-mm-dd format
            end_date (str): end date must be in yyyy-mm-dd format"""
        payload = {}
        endpoint = '%s/%s/statistics/daily/%s/%s' % (settings.OPENX_ADVERT,
                                                     advertiser_id, start_date,
                                                     end_date)
        return json.loads(self._get(endpoint, payload))

    def get_advertiser_stats_by_campaign(self, advertiser_id, start_date, end_date):
        """Get advertiser stats by campaign

        Args:
            advertiser_id (int): id for advertiser we're interested in
            start_date (str): start date must be in yyyy-mm-dd format
            end_date (str): end date must be in yyyy-mm-dd format"""
        payload = {}
        endpoint = '%s/%s/statistics/campaign/%s/%s' % (settings.OPENX_ADVERT,
                                                        advertiser_id, start_date,
                                                        end_date)
        return json.loads(self._get(endpoint, payload))

    def get_advertiser_stats_by_banner(self, advertiser_id, start_date, end_date):
        """Get advertiser stats by banner

        Args:
            advertiser_id (int): id for advertiser we're interested in
            start_date (str): start date must be in yyyy-mm-dd format
            end_date (str): end date must be in yyyy-mm-dd format"""
        payload = {}
        endpoint = '%s/%s/statistics/banner/%s/%s' % (settings.OPENX_ADVERT,
                                                      advertiser_id, start_date,
                                                      end_date)
        return json.loads(self._get(endpoint, payload))

    def get_advertiser_stats_by_publisher(self, advertiser_id, start_date, end_date):
        """Get advertiser stats by publisher

        Args:
            advertiser_id (int): id for advertiser we're interested in
            start_date (str): start date must be in yyyy-mm-dd format
            end_date (str): end date must be in yyyy-mm-dd format"""
        payload = {}
        endpoint = '%s/%s/statistics/publisher/%s/%s' % (settings.OPENX_ADVERT,
                                                         advertiser_id, start_date,
                                                         end_date)
        return json.loads(self._get(endpoint, payload))

    def get_advertiser_stats_by_zone(self, advertiser_id, start_date, end_date):
        """Get advertiser stats by zone

        Args:
            advertiser_id (int): id for advertiser we're interested in
            start_date (str): start date must be in yyyy-mm-dd format
            end_date (str): end date must be in yyyy-mm-dd format"""
        payload = {}
        endpoint = '%s/%s/statistics/zone/%s/%s' % (settings.OPENX_ADVERT,
                                                    advertiser_id, start_date,
                                                    end_date)
        return json.loads(self._get(endpoint, payload))

    # ================  Advertiser management methods below this line ===============

    def add_advertiser(self, advertiser_name, agency_id, contact_name,
                       email_address, username, password):
        """Add a new user to the OPENX server

        Args:
            advertiser_name (str):  advertiser name
            agency_id (int):  advertiser id
            contact_name (str): contact name for the advertiser being created
            email (str): Contact email for the contact
            username (str): a login name for the user
            passwordd (str): the unencrypted password

        Returns:
            dict of the result
        """
        payload = {'advertiserName': advertiser_name,
                   'agencyID': agency_id,
                   'contactName': contact_name,
                   'emailAddress': email_address,
                   'username': username,
                   'password': password}

        result = self._post(settings.OPENX_NEW_ADVERT, payload)
        if result == '{"OK"}':  # The rest api does not return valid json
            return {'result': 'OK'}

    def modify_advertiser_agency_id(self, advertiser_id, agency_id):
        """modify and advertiser's  agency_id property

        Args:
            advertiser_id (int): advertisers id
            agency_id (int):  the agency id we are setting
        Returns:
            dict of the result
        """
        payload = {'agencyID': agency_id}
        endpoint = '%s/%s' % (settings.OPENX_ADVERT, advertiser_id)
        result = self._post(endpoint, payload)
        if result == '{"OK"}':  # The rest api does not return valid json
            return {'result': 'OK'}

    def modify_advertiser_name(self, advertiser_id, advertiser_name):
        """modify and advertiser's advertiser_name property

        Args:
            advertiser_id (int): advertisers id
            advertiser_name (str):  whatever we're changing the name to
        Returns:
            dict of the result
        """
        payload = {'advertiserName': advertiser_name}
        endpoint = '%s/%s' % (settings.OPENX_ADVERT, advertiser_id)
        result = self._post(endpoint, payload)
        if result == '{"OK"}':  # The rest api does not return valid json
            return {'result': 'OK'}

    def modify_advertiser_contact_name(self, advertiser_id, contact_name):
        """modify and advertiser's contact_name property

        Args:
            advertiser_id (int): advertisers id
            contact_name (str):  the new contact name
        Returns:
            dict of the result
        """
        payload = {'contactName': contact_name}
        endpoint = '%s/%s' % (settings.OPENX_ADVERT, advertiser_id)
        result = self._post(endpoint, payload)
        if result == '{"OK"}':  # The rest api does not return valid json
            return {'result': 'OK'}

    def modify_advertiser_email_address(self, advertiser_id, email_address):
        """modify and advertiser's  email_address property

        Args:
            advertiser_id (int): advertisers id
            email_address(str):  the new email address

        Returns:
            dict of the result
        """
        payload = {'emailAddress': email_address}
        endpoint = '%s/%s' % (settings.OPENX_ADVERT, advertiser_id)
        result = self._post(endpoint, payload)
        if result == '{"OK"}':  # The rest api does not return valid json
            return {'result': 'OK'}

    def modify_advertiser_username(self, advertiser_id, username):
        """modify and advertiser's username property

        Args:
            advertiser_id (int): advertisers id

        Returns:
            dict of the result
        """
        payload = {'username': username}
        endpoint = '%s/%s' % (settings.OPENX_ADVERT, advertiser_id)
        result = self._post(endpoint, payload)
        if result == '{"OK"}':  # The rest api does not return valid json
            return {'result': 'OK'}

    def modify_advertiser_password(self, advertiser_id, password):
        """modify and advertiser's password property

        Args:
            advertiser_id (int): advertisers id
            password (str):  the new password

        Returns:
            dict of the result
        """
        payload = {'password': password}
        endpoint = '%s/%s' % (settings.OPENX_ADVERT, advertiser_id)
        result = self._post(endpoint, payload)
        if result == '{"OK"}':  # The rest api does not return valid json
            return {'result': 'OK'}

    def get_advertiser(self, advertiser_id):
        """Return an advertiser by it's advertiser_id

        Args:
            advertiser_id (int): the advertiser id that we're dealing with

        Returns:
            dictionary of result data
        """
        return json.loads(self._get(settings.OPENX_ADVERT, advertiser_id))

    def get_advertiser_list_by_agency_id(self, agency_id):
        """Return a list of advertisers associated with a given agency

        Args:
            agency_id (int): agency id

        Returns:
            dictionary of result data
        """
        return json.loads(self._get(settings.OPENX_ADVERT, agency_id))

    def delete_advertiser(self, advertiser_id):
        """Delete an advertiser by it's advertiser_id

        Args:
            advertiser_id (int): the advertiser id that we're deleting

        Returns:
            dictionary of result data
        """
        return json.loads(self._delete(settings.OPENX_ADVERT, advertiser_id))
