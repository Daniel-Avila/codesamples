"""
ZoneClient

This is the sub client which defines all the zone managment functionality
"""

from mixin import OpenXMixIn
from django.conf import settings
from adcoin_openx.exceptions import AdcoinException
import json


class ZoneClient(OpenXMixIn):

    # ================ Zone statistics methods below this line ================

    def get_zone_stats_by_banner(self, zone_id, start_date, end_date):
        """Get banner stats by zone for a given time period

        Args:
            zone_id (int): id for zone we're interested in
            start_date (str): start date must be in yyyy-mm-dd format
            end_date (str): end date must be in yyyy-mm-dd format"""
        payload = {}
        endpoint = '%s/%s/statistics/banner/%s/%s' % (settings.OPENX_ZONE,
                                                      zone_id, start_date,
                                                      end_date)
        return json.loads(self._get(endpoint, payload))

    def get_zone_stats_by_advertiser(self, zone_id, start_date, end_date):
        """Get zone stats for a given advertiser

        Args:
            zone_id (int): id for zone we're interested in
            start_date (str): start date must be in yyyy-mm-dd format
            end_date (str): end date must be in yyyy-mm-dd format"""
        payload = {}
        endpoint = '%s/%s/statistics/advertiser/%s/%s' % (settings.OPENX_ZONE,
                                                          zone_id, start_date,
                                                          end_date)
        return json.loads(self._get(endpoint, payload))

    def get_zone_stats_by_date(self, zone_id, start_date, end_date):
        """Get zone stats by day

        Args:
            zone_id (int): id for zone we're interested in
            start_date (str): start date must be in yyyy-mm-dd format
            end_date (str): end date must be in yyyy-mm-dd format"""
        payload = {}
        endpoint = '%s/%s/statistics/daily/%s/%s' % (settings.OPENX_ZONE,
                                                     zone_id, start_date,
                                                     end_date)
        return json.loads(self._get(endpoint, payload))

    def get_zone_stats_by_campaign(self, zone_id, start_date, end_date):
        """Get zone stats by campaign

        Args:
            zone_id (int): id for zone we're interested in
            start_date (str): start date must be in yyyy-mm-dd format
            end_date (str): end date must be in yyyy-mm-dd format"""
        payload = {}
        endpoint = '%s/%s/statistics/campaign/%s/%s' % (settings.OPENX_ZONE,
                                                        zone_id, start_date,
                                                        end_date)
        return json.loads(self._get(endpoint, payload))

    # ================  Zone management methods below this line ===============

    def add_zone(self, campaign_id, banner_name, storage_type, image_url,
                 html_template, width, height, weight, url):
        """Add a new zone to the OPENX server

        Args:
             campaign_id (int): campaign ID
             banner_name (str): banner name
             storage_type (enum): type of storage, must be one of these values:
                 html,txt,sql,web,url,video
             html_template (str):  destionation url

        Returns:
             dict of the result
        """
        valid_types = ['html', 'txt', 'sql', 'web', 'url', 'video']

        if storage_type not in valid_types:
            msg = 'storageType expects %s got %s' % (', '.join(valid_types),
                                                     storage_type)
            raise AdcoinException(msg)

        payload = {'campaignId': campaign_id,
                   'bannerName': banner_name,
                   'storageType': storage_type,
                   'imageURL': image_url,
                   'htmlTemplate': html_template,
                   'width': width,
                   'height': height,
                   'weith': weight,
                   'url': url}
        result = self._post(settings.OPENX_ADD_ZONE, payload)
        if result == '{"OK"}':  # The rest api does not return valid json
            return {'result': 'OK'}

    def delete_zone(self, zone_id):
        """Return delete a zone by zoneid

        Args:
            zoneid(int):  a zone id

        Returns:
            deletes a selected zone
        """
        return json.loads(self._delete(settings.OPENX_ZONE, zone_id))

    def generate_tags(self, zone_id, code_type, block, target, source,
                      with_text, block_campaign, char_set, third_party_track,
                      comments):
        """Add tags by zone id the OPENX server

        Args:
            zone_id (int):  the zone id we're dealing with
            code_type (enum):   invocation code type (adframe, adjs, adlayer,
                                adview, adviewnocookies, local, popup, xmlrpc)
            block (bool):  Don't show banner again on same page (0 or 1)
            target (enum):  Target frame (_blank, _top)
            source (str):  source
            with_text(bool):  with text below banner
            block_campaign (bool):  Don't show a banner from the same campaign
                    again on the same page
            char_set (enum):  Character set (ISO-8859-6, Windows-1256,
                    ISO-8859-4, UTF-8, EUC-KR,...)
            third_party_track(enum):  Support 3rd party server clicktracking
                    (0, generic, 3rdPartyServers:ox3rdPartyServers:doubleclick,
                    3rdPartyServers:max)
            comments(bool):  include comments

        Returns:
             dict of the result
        """
        valid_code_type = ['adframe', 'adjs', 'adlayer', 'adview',
                           'adviewnocookies', 'local', 'popup', 'xmlrpc']
        valid_target = ['_blank', '_top']
        valid_char_set = ['ISO-8859-6', 'Windows-1256', 'ISO-8859-4', 'UTF-8',
                          'EUC-KR']
        valid_tracker = ['0', 'generic',
                         '3rdPartyServers:ox3rdPartyServers:doubleclick',
                         '3rdPartyServers:max']

        if code_type not in valid_code_type:
            msg = 'code type expects %s got %s' % (', '.join(valid_code_type),
                                                   code_type)
            raise AdcoinException(msg)

        if target not in valid_target:
            msg = 'target expects %s got %s' % (', '.join(valid_target),
                                                target)
            raise AdcoinException(msg)

        if char_set not in valid_char_set:
            msg = 'character set expects %s got %s'
            msg %= (', '.join(valid_char_set), char_set)
            raise AdcoinException(msg)

        if third_party_track not in valid_tracker:
            msg = 'third party tracker set expects %s got %s'
            msg %= (', '.join(valid_tracker), third_party_track)
            raise AdcoinException(msg)

        # we have to convert from boolean to ints to make openx happy

        endpoint = "%s/%s/ic" % (settings.OPENX_ZONE, zone_id)

        payload = {'codeType': code_type,
                   'block': 1 if block else 0,
                   'target': target,
                   'source': source,
                   'withtext': 1 if with_text else 0,
                   'blockcampaign': 1 if block_campaign else 0,
                   'charset':  char_set,
                   'thirdpartytrack': third_party_track,
                   'comments': 1 if comments else 0}
        result = self._post(endpoint, payload)
        if result == '{"OK"}':  # The rest api does not return valid json
            return {'result': 'OK'}

    def get_zone_by_publisher(self, publisher_id):
        """Return a list of zone(s) for a publisher id

        Args:
            publisher_id(str):  a Publisher id

        Returns:
            list of zones for a given publisher id
        """

        return json.loads(self._get(settings.OPENX_GET_ZONE, publisher_id))

    def get_zone(self, zone_id):
        """Return zone information for a zone id

        Args:
            zone_id (int): A Zone id

        Returns:
            dictionary of zone data for a zone
        """

        return json.loads(self._get(settings.OPENX_GET_ZONE, zone_id))

    def unlink_banner(self, zone_id, banner_id):
        """unlinks a banner to a zone

        Args:
            zone_id (int):  the zone id  we're dealing with.
            banner_id (int):  the banner id that we're linking to"""
        payload = {}
        endpoint = '%s/%s/ban/%s' % (settings.OPENX_ZONE, zone_id, banner_id)
        result = self._delete(endpoint, payload)
        if result == '{"OK"}':  # The rest api does not return valid json
            return {'result': 'OK'}

    def link_banner(self, zone_id, banner_id):
        """links a banner to a zone

        Args:
            zone_id (int):  the zone id  we're dealing with.
            banner_id (int):  the banner id that we're linking to"""
        payload = {}
        endpoint = '%s/%s/ban/%s' % (settings.OPENX_ZONE, zone_id, banner_id)
        result = self._post(endpoint, payload)
        if result == '{"OK"}':  # The rest api does not return valid json
            return {'result': 'OK'}

    def unlink_campaign(self, zone_id, campaign_id):
        """unlinks a campaign to a zone

        Args:
            zone_id (int):  the zone id  we're dealing with.
            campaign_id (int):  the campaign id that we're linking to"""
        payload = {}
        endpoint = '%s/%s/cam/%s' % (settings.OPENX_ZONE, zone_id, campaign_id)
        result = self._delete(endpoint, payload)
        if result == '{"OK"}':  # The rest api does not return valid json
            return {'result': 'OK'}

    def link_campaign(self, zone_id, campaign_id):
        """links a campaign to a zone

        Args:
            zone_id (int):  the zone id  we're dealing with.
            campaign_id (int):  the campaign id that we're linking to"""
        payload = {}
        endpoint = '%s/%s/cam/%s' % (settings.OPENX_ZONE, zone_id, campaign_id)
        result = self._post(endpoint, payload)
        if result == '{"OK"}':  # The rest api does not return valid json
            return {'result': 'OK'}

    def modify_zone_height(self, zone_id, height):
        """Set the zones width

        Args:
            zone_id (int): The zone being changed
            height (int): The zones new height

        Returns:
            Dictionary of resposne from openx
        """
        payload = {'height': height}
        endpoint = '%s/%s' % (settings.OPENX_ZONE, zone_id)
        result = self._post(endpoint, payload)
        if result == '{"OK"}':  # The rest api does not return valid json
            return {'result': 'OK'}

    def modify_zone_width(self, zone_id, width):
        """Set the zones width

        Args:
            zone_id (int): The zone being changed
            width (int): The zones new width

        Returns:
            Dictionary of resposne from openx
        """
        payload = {'width': width}
        endpoint = '%s/%s' % (settings.OPENX_ZONE, zone_id)
        result = self._post(endpoint, payload)
        if result == '{"OK"}':  # The rest api does not return valid json
            return {'result': 'OK'}

    def modify_zone_type(self, zone_id, zone_type):
        """Set the zones type

        Args:
            zone_int(int): The zone being changed
            zone_type (int): The zones new type

        Returns:
            Dictionary of resposne from openx
        """
        valid_types = range(0, 3)

        if zone_type not in valid_types:
            msg = 'zone type expects a number from 0 to 3 got %s' % (zone_type)
            raise AdcoinException(msg)

        payload = {'type':  zone_type}
        endpoint = '%s/%s' % (settings.OPENX_ZONE, zone_id)
        result = self._post(endpoint, payload)
        if result == '{"OK"}':  # The rest api does not return valid json
            return {'result': 'OK'}

    def modify_zone_name(self, zone_id, zone_name):
        """Set the zones name

        Args:
            zone_id (int): The zone being changed
            zone_name (str): The zones new name

        Returns:
            Dictionary of resposne from openx
        """
        payload = {'zoneName': zone_name}
        endpoint = '%s/%s' % (settings.OPENX_ZONE, zone_id)
        result = self._post(endpoint, payload)
        if result == '{"OK"}':  # The rest api does not return valid json
            return {'result': 'OK'}

    def modify_zone_publisher_id(self, zone_id, publisher_id):
        """Set the zones publisher id

        Args:
            zone_id (int): The zone being changed
            zone_publisher_id (int): The zones new publisher id

        Returns:
            Dictionary of resposne from openx
        """
        payload = {'publisherId': publisher_id}
        endpoint = '%s/%s' % (settings.OPENX_ZONE, zone_id)
        result = self._post(endpoint, payload)
        if result == '{"OK"}':  # The rest api does not return valid json
            return {'result': 'OK'}
