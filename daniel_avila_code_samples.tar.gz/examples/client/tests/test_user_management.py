from django import test
import mock
import adcoin_openx.client.user_client as client
import json


@mock.patch('adcoin_openx.client.mixin.OpenXMixIn._send_request')
class TestAPIClientUserManagement(test.TestCase):

    def setUp(self):

        self.client = client.UserClient()

    def test_get_user(self, mock_send_request):
        """Can we get the user data?"""
        expected = {'result': "OK"}
        mock_send_request.return_value = json.dumps(expected)
        result = self.client.get_user(1)
        self.assertEqual(expected, result)

    def test_add_user(self, mock_send_request):
        """Can we add a user to the OPENX server?"""
        mock_send_request.return_value = '{"OK"}'

        expected = {'result': "OK"}
        contact = 'Eric Idle'
        email = 'basil@faultytowers.co.uk'
        username = 'ericbasil'
        passwd = 'spamspamspam'
        default = True
        active = True
        result = self.client.add_user(contact, email, username, passwd,
                                      default, active)
        self.assertEqual(result, expected)

    def test_get_user_list(self, mock_send_request):
        """Can we get the user list for an account?"""

        expected = {'result': "OK"}
        mock_send_request.return_value = json.dumps(expected)
        result = self.client.get_user_list(1)
        self.assertEqual(expected, result)

    def test_modify_user_active(self, mock_send_request):
        """Can we modify an existing users active status?"""

        mock_send_request.return_value = '{"OK"}'
        result = self.client.modify_user_active(1, True)
        expected = {'result': "OK"}
        self.assertEqual(result, expected)

    def test_modify_user_password(self, mock_send_request):
        """Can we modify an existing user password?"""

        user_id = 1
        mock_send_request.return_value = '{"OK"}'
        result = self.client.modify_user_password(user_id, 'birds')
        expected = {'result': "OK"}
        self.assertEqual(result, expected)

    def test_modify_user_email(self, mock_send_request):
        """Can we modify an existing user contact name?"""

        user_id = 1
        mock_send_request.return_value = '{"OK"}'
        result = self.client.modify_user_email(user_id, 'sparky@localhost.com')
        expected = {'result': "OK"}
        self.assertEqual(result, expected)

    def test_modify_user_contact_name(self, mock_send_request):
        """Can we modify an existing user contact name?"""

        user_id = 1
        mock_send_request.return_value = '{"OK"}'
        result = self.client.modify_user_contact_name(user_id, 'Eric Clease')
        expected = {'result': "OK"}
        self.assertEqual(result, expected)

    def test_delete_user(self, mock_send_request):
        """Can we delete a user?"""

        expected = json.dumps({'result': "OK"})
        user_id = 1
        mock_send_request.return_value = '{"OK"}'
        result = self.client.delete_user(user_id)
        expected = {'result': "OK"}
        self.assertEqual(result, expected)
