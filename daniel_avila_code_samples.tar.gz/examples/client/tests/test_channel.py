from django import test
import mock
import adcoin_openx.client.channel_client as client
import json
from adcoin_openx.exceptions import AdcoinException


@mock.patch('adcoin_openx.client.mixin.OpenXMixIn._send_request')
class TestAPIClientChannel(test.TestCase):

    def setUp(self):

        self.client = client.ChannelClient()

    def test_get_channel(self, mock_send_request):
        """Can we get the channel data?"""
        expected = {'result': "OK"}
        mock_send_request.return_value = json.dumps(expected)
        result = self.client.get_channel(1)
        self.assertEqual(expected, result)

    def test_add_channel(self, mock_send_request):
        """Can we add a channel?"""
        mock_send_request.return_value = '{"OK"}'

        expected = {'result': "OK"}

        channel_name = 'Test Channel'
        agency_id = 1
        website_id = 1
        channel_desc = 'Test Channel Description'
        comments = 'Test Channel Comments'

        result = self.client.add_channel(channel_name, agency_id, website_id,
                                        channel_desc, comments)
        self.assertEqual(result, expected)

    def test_delete_channel(self, mock_send_request):
        """Can we delete the channel?"""
        expected = {'result': "OK"}
        mock_send_request.return_value = json.dumps(expected)
        result = self.client.delete_channel(1)
        self.assertEqual(expected, result)

    def test_modify_channel_name(self, mock_send_request):
        """Can we modify a channel name?"""

        mock_send_request.return_value = '{"OK"}'
        new_value = 'New Test Channel Name'
        result = self.client.modify_channel_name(2, new_value)
        expected = {'result': "OK"}
        self.assertEqual(result, expected)

    def test_modify_channel_agency(self, mock_send_request):
        """Can we modify a channel agency_id?"""

        mock_send_request.return_value = '{"OK"}'
        new_value = 2
        result = self.client.modify_channel_agency(2, new_value)
        expected = {'result': "OK"}
        self.assertEqual(result, expected)

    def test_modify_channel_website(self, mock_send_request):
        """Can we modify a channel website_id?"""

        mock_send_request.return_value = '{"OK"}'
        new_value = 2
        result = self.client.modify_channel_website(2, new_value)
        expected = {'result': "OK"}
        self.assertEqual(result, expected)

    def test_modify_channel_description(self, mock_send_request):
        """Can we modify a channel description?"""

        mock_send_request.return_value = '{"OK"}'
        new_value = 'New Test Channel Description'
        result = self.client.modify_channel_description(2, new_value)
        expected = {'result': "OK"}
        self.assertEqual(result, expected)

    def test_modify_channel_comments(self, mock_send_request):
        """Can we modify a channel comments?"""

        mock_send_request.return_value = '{"OK"}'
        new_value = 'New Test Channel Comments'
        result = self.client.modify_channel_comments(2, new_value)
        expected = {'result': "OK"}
        self.assertEqual(result, expected)

    def test_channel_website(self, mock_send_request):
        """Can we get channels from a specific website?"""

        expected = {'result': "OK"}
        mock_send_request.return_value = json.dumps(expected)
        result = self.client.get_channel_website(1)
        self.assertEqual(expected, result)

    def test_channel_agency(self, mock_send_request):
        """Can we get channels from a specific agency?"""

        expected = {'result': "OK"}
        mock_send_request.return_value = json.dumps(expected)
        result = self.client.get_channel_agency(1)
        self.assertEqual(expected, result)

    def test_channel_target(self, mock_send_request):
        """Can we get delivery limitations for a specific channel?"""

        expected = {'result': "OK"}
        mock_send_request.return_value = json.dumps(expected)
        result = self.client.get_channel_target(1)
        self.assertEqual(expected, result)

    def test_add_channel_target(self, mock_send_request):
        """Can we set the delivery limitations for a specific channel?"""

        expected = {'result': "OK"}
        logical = 'and'
        limit = 'Some delivery limitations for channel'
        comp = '=='
        data = 'Some data string'

        mock_send_request.return_value = '{"OK"}'

        result = self.client.add_channel_target(2, logical, limit, comp, data)
        self.assertEqual(expected, result)

    def test_add_channel_target_logical_expection(self, mock_send_request):
        """Does add_channel_target raise an exception when logical type
        is bad"""

        expected = {'result': "OK"}
        logical = 'not and'
        limit = 'Some delivery limitations'
        comp = '=='
        data = 'Some data string'

        mock_send_request.return_value = json.dumps(expected)
        with self.assertRaises(AdcoinException):

            self.client.add_channel_target(4, logical, limit, comp, data)

    def test_add_channel_target_comp_expection(self, mock_send_request):
        """Does add_channel_target raise an exception when comp type is bad"""

        expected = {'result': "OK"}
        logical = 'and'
        limit = 'Some delivery limitations'
        comp = 'not =='
        data = 'Some data string'

        mock_send_request.return_value = json.dumps(expected)
        with self.assertRaises(AdcoinException):

            self.client.add_channel_target(4, logical, limit, comp, data)
