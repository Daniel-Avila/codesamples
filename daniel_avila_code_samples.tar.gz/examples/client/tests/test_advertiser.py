from django import test
import mock
import adcoin_openx.client.advertiser_client as client
import json


@mock.patch('adcoin_openx.client.mixin.OpenXMixIn._send_request')
class TestAPIClientAdvertiser(test.TestCase):

    def setUp(self):

        self.client = client.AdvertiserClient()

    # ===============  advertiser stats tests below ==============================

    def test_get_advertiser_by_date(self, mock_send_request):
        """Can we get advertiser stats by day?"""

        advertiser_id = 1
        start_date = '2014-12-12'
        end_date = '2015-12-23'
        expected = {'result': 'OK'}
        mock_send_request.return_value = json.dumps(expected)
        result = self.client.get_advertiser_stats_by_date(advertiser_id, start_date,
                                                          end_date)
        self.assertEqual(expected, result)

    def test_get_advertiser_by_campgaign(self, mock_send_request):
        """Can we get advertiser stats by campaign?"""

        advertiser_id = 1
        start_date = '2014-12-12'
        end_date = '2015-12-23'
        expected = {'result': 'OK'}
        mock_send_request.return_value = json.dumps(expected)
        result = self.client.get_advertiser_stats_by_campaign(advertiser_id, start_date,
                                                              end_date)
        self.assertEqual(expected, result)

    def test_get_advertiser_by_banner(self, mock_send_request):
        """Can we get advertiser stats by banner?"""

        advertiser_id = 1
        start_date = '2014-12-12'
        end_date = '2015-12-23'
        expected = {'result': 'OK'}
        mock_send_request.return_value = json.dumps(expected)
        result = self.client.get_advertiser_stats_by_banner(advertiser_id, start_date,
                                                              end_date)
        self.assertEqual(expected, result)

    def test_get_advertiser_by_publisher(self, mock_send_request):
        """Can we get advertiser stats by publisher?"""

        advertiser_id = 1
        start_date = '2014-12-12'
        end_date = '2015-12-23'
        expected = {'result': 'OK'}
        mock_send_request.return_value = json.dumps(expected)
        result = self.client.get_advertiser_stats_by_publisher(advertiser_id, start_date,
                                                              end_date)
        self.assertEqual(expected, result)

    def test_get_advertiser_by_zone(self, mock_send_request):
        """Can we get advertiser stats by zone?"""

        advertiser_id = 1
        start_date = '2014-12-12'
        end_date = '2015-12-23'
        expected = {'result': 'OK'}
        mock_send_request.return_value = json.dumps(expected)
        result = self.client.get_advertiser_stats_by_zone(advertiser_id, start_date,
                                                          end_date)
        self.assertEqual(expected, result)


    # ===============  advertiser management tests below =========================

    def test_add_advertiser(self, mock_send_request):
        """Can we add an advertiser to the OPENX server?"""
        mock_send_request.return_value = '{"OK"}'
        expected = {'result': "OK"}
        advertiser_name = 'bubba'
        agency_id = 2
        contact_name = 'Eric Idle'
        email_address = 'basil@faultytowers.co.uk'
        username = 'ericbasil'
        password = 'spamspamspam'
        result = self.client.add_advertiser(advertiser_name, agency_id,
                                            contact_name, email_address,
                                            username, password)
        self.assertEqual(result, expected)

    def test_modify_advertiser_name(self, mock_send_request):
        """Can we modify an advertiser's name property?"""
        mock_send_request.return_value = '{"OK"}'
        expected = {'result': "OK"}
        advertiser_id = 1
        advertiser_name = 'bubba'
        result = self.client.modify_advertiser_name(advertiser_id,
                                                    advertiser_name)
        self.assertEqual(result, expected)

    def test_modify_advertiser_agency_id(self, mock_send_request):
        """Can we modify an advertiser's agency_id property?"""
        mock_send_request.return_value = '{"OK"}'
        expected = {'result': "OK"}
        advertiser_id = 1
        agency_id = 1
        result = self.client.modify_advertiser_agency_id(advertiser_id,
                                                         agency_id)
        self.assertEqual(result, expected)

    def test_modify_advertiser_contact_name(self, mock_send_request):
        """Can we modify an advertiser's contact_name property?"""
        mock_send_request.return_value = '{"OK"}'
        expected = {'result': "OK"}
        advertiser_id = 1
        contact_name = 'bubba'
        result = self.client.modify_advertiser_contact_name(advertiser_id,
                                                            contact_name)
        self.assertEqual(result, expected)

    def test_modify_advertiser_email_address(self, mock_send_request):
        """Can we modify an advertiser's email_address property?"""
        mock_send_request.return_value = '{"OK"}'
        expected = {'result': "OK"}
        advertiser_id = 1
        email_address = 'bob@.com'
        result = self.client.modify_advertiser_email_address(advertiser_id,
                                                             email_address)
        self.assertEqual(result, expected)

    def test_modify_advertiser_username(self, mock_send_request):
        """Can we modify an advertiser's username property?"""
        mock_send_request.return_value = '{"OK"}'
        expected = {'result': "OK"}
        advertiser_id = 1
        username = 'bubba'
        result = self.client.modify_advertiser_username(advertiser_id, username)
        self.assertEqual(result, expected)

    def test_modify_advertiser_password(self, mock_send_request):
        """Can we modify an advertiser's password property?"""
        mock_send_request.return_value = '{"OK"}'
        expected = {'result': "OK"}
        advertiser_id = 1
        password = 'bubba'
        result = self.client.modify_advertiser_password(advertiser_id, password)
        self.assertEqual(result, expected)

    def test_get_advertiser(self, mock_send_request):
        """Can we get an advertiser?"""
        expected = {'result': "OK"}
        mock_send_request.return_value = json.dumps(expected)
        advertiser_id = 1
        result = self.client.get_advertiser(advertiser_id)
        self.assertEqual(expected, result)

    def test_get_advertiser_list_by_agency_id(self, mock_send_request):
        """Can we get a list of  advertisers by agency_id?"""
        expected = {'result': "OK"}
        mock_send_request.return_value = json.dumps(expected)
        agency_id = 1
        result = self.client.get_advertiser_list_by_agency_id(agency_id)
        self.assertEqual(expected, result)

    def test_delete_advertiser(self, mock_send_request):
        """Can we delete an existing advertiser?"""
        expected = {'result': "OK"}
        mock_send_request.return_value = json.dumps(expected)
        advertiser_id = 1
        result = self.client.delete_advertiser(advertiser_id)
        self.assertEqual(expected, result)
