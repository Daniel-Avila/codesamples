from django import test
import mock
import adcoin_openx.client.campaign_client as client
import json


@mock.patch('adcoin_openx.client.mixin.OpenXMixIn._send_request')
class TestAPIClientCampaign(test.TestCase):

    def setUp(self):
        self.client = client.CampaignClient()

    # ============= campaign stats below =====================================

    def test_get_campaign_stats_by_date(self, mock_send_request):
        """Can we get campaign stats by day?"""
        campaign_id = 1
        start_date = '2014-12-12'
        end_date = '2015-12-23'
        expected = {'result': 'OK'}
        mock_send_request.return_value = json.dumps(expected)
        result = self.client.get_campaign_stats_by_date(campaign_id, start_date,
                                                        end_date)
        self.assertEqual(expected, result)

    def test_get_campaign_stats_by_publisher(self, mock_send_request):
        """Can we get campaign stats by publisher?"""
        campaign_id = 1
        start_date = '2014-12-12'
        end_date = '2015-12-23'
        expected = {'result': 'OK'}
        mock_send_request.return_value = json.dumps(expected)
        result = self.client.get_campaign_stats_by_publisher(campaign_id,
                                                             start_date,
                                                             end_date)
        self.assertEqual(expected, result)

    def test_get_campaign_stats_by_banner(self, mock_send_request):
        """Can we get campaign stats by banner?"""
        campaign_id = 1
        start_date = '2014-12-12'
        end_date = '2015-12-23'
        expected = {'result': 'OK'}
        mock_send_request.return_value = json.dumps(expected)
        result = self.client.get_campaign_stats_by_banner(campaign_id,
                                                          start_date, end_date)
        self.assertEqual(expected, result)

    def test_get_campaign_stats_by_zone(self, mock_send_request):
        """Can we get campaign stats by zone?"""
        campaign_id = 1
        start_date = '2014-12-12'
        end_date = '2015-12-23'
        expected = {'result': 'OK'}
        mock_send_request.return_value = json.dumps(expected)
        result = self.client.get_campaign_stats_by_zone(campaign_id,
                                                        start_date, end_date)
        self.assertEqual(expected, result)

    def test_get_campaign_conversion_stats(self, mock_send_request):
        """Can we get campaign conversion stats?"""
        campaign_id = 1
        start_date = '2014-12-12'
        end_date = '2015-12-23'
        expected = {'result': 'OK'}
        mock_send_request.return_value = json.dumps(expected)
        result = self.client.get_campaign_conversion_stats(campaign_id,
                                                           start_date, end_date)
        self.assertEqual(expected, result)

    # =============  campaign management below ================================

    def test_add_campaign(self, mock_send_request):
        """can we add a campaign?"""
        advertiser_id = 1
        campaign_name = 'bubba'
        start_date = '2014-12-12'
        end_date = '2015-12-12'
        impressions = 500
        clicks = 500
        priority = 2
        weight = 500
        mock_send_request.return_value = '{"OK"}'
        result = self.client.add_campaign(advertiser_id, campaign_name,
                                          start_date, end_date, impressions,
                                          clicks, priority, weight)
        expected = {'result': "OK"}
        self.assertEqual(result, expected)

    def test_modify_campaign_advertiser_id(self, mock_send_request):
        """Can we modify a campaigns advertiser id property?"""
        campaign_id = 1
        advertiser_id = 1
        mock_send_request.return_value = '{"OK"}'
        result = self.client.modify_campaign_advertiser_id(campaign_id,
                                                           advertiser_id)
        expected = {'result': "OK"}
        self.assertEqual(result, expected)

    def test_modify_campaign_name(self, mock_send_request):
        """Can we modify a campaigns mae property?"""
        campaign_id = 1
        name = 'bubba'
        mock_send_request.return_value = '{"OK"}'
        result = self.client.modify_campaign_name(campaign_id, name)
        expected = {'result': "OK"}
        self.assertEqual(result, expected)

    def test_modify_campaign_start_date(self, mock_send_request):
        """Can we modify a campaigns start date property?"""
        campaign_id = 1
        start_date = '2014-12-12'
        mock_send_request.return_value = '{"OK"}'
        result = self.client.modify_campaign_start_date(campaign_id,
                                                        start_date)
        expected = {'result': "OK"}
        self.assertEqual(result, expected)

    def test_modify_campaign_end_date(self, mock_send_request):
        """Can we modify a campaigns end_date  property?"""
        campaign_id = 1
        end_date = '2014-12-12'
        mock_send_request.return_value = '{"OK"}'
        result = self.client.modify_campaign_end_date(campaign_id, end_date)
        expected = {'result': "OK"}
        self.assertEqual(result, expected)

    def test_modify_campaign_impressions(self, mock_send_request):
        """Can we modify a campaigns impressions property?"""
        campaign_id = 1
        impressions = 500
        mock_send_request.return_value = '{"OK"}'
        result = self.client.modify_campaign_impressions(campaign_id,
                                                         impressions)
        expected = {'result': "OK"}
        self.assertEqual(result, expected)

    def test_modify_campaign_clicks(self, mock_send_request):
        """Can we modify a campaigns clicks property?"""
        campaign_id = 1
        clicks = 500
        mock_send_request.return_value = '{"OK"}'
        result = self.client.modify_campaign_clicks(campaign_id, clicks)
        expected = {'result': "OK"}
        self.assertEqual(result, expected)

    def test_modify_campaign_priority(self, mock_send_request):
        """Can we modify a campaigns priority property?"""
        campaign_id = 1
        priority = 2
        mock_send_request.return_value = '{"OK"}'
        result = self.client.modify_campaign_priority(campaign_id, priority)
        expected = {'result': "OK"}
        self.assertEqual(result, expected)

    def test_modify_campaign_weight(self, mock_send_request):
        """Can we modify a campaigns weight property?"""
        campaign_id = 1
        weight = 500
        mock_send_request.return_value = '{"OK"}'
        result = self.client.modify_campaign_weight(campaign_id, weight)
        expected = {'result': "OK"}
        self.assertEqual(result, expected)

    def test_get_campaign_list_by_advertiserid(self, mock_send_request):
        """Can we get the campaign list for an advertiser?"""
        advertiser_id = 1
        expected = {'result': "OK"}
        mock_send_request.return_value = json.dumps(expected)
        result = self.client.get_campaign_list_by_advertiserid(advertiser_id)
        self.assertEqual(expected, result)

    def test_get_campaign(self, mock_send_request):
        """Can we get an existing campaign?"""
        campaign_id = 1
        expected = {'result': "OK"}
        mock_send_request.return_value = json.dumps(expected)
        result = self.client.get_campaign(campaign_id)
        self.assertEqual(expected, result)

    def test_delet_campaign(self, mock_send_request):
        """Can we delete a campaign?"""
        campaign_id = 1
        mock_send_request.return_value = '{"OK"}'
        result = self.client.delete_campaign(campaign_id)
        expected = {'result': "OK"}
        self.assertEqual(result, expected)
