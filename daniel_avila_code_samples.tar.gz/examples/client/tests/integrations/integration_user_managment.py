from django import test
import adcoin_openx.client.user_client as client


class TestAPIClientUserManagement(test.TestCase):

    def setUp(self):

        self.client = client.UserClient()

    def tearDown(self):
        self._delete_current_user()

    def test_user_add_and_delete(self):
        """Can we add a user to the OPENX server?"""

        expected = {'result': "OK"}
        contact = 'Eric Idle'
        email = 'basil@faultytowers.co.uk'
        username = 'ericbasil'
        passwd = 'spamspamspam'
        default = 2
        active = True
        result = self.client.add_user(contact, email, username, passwd,
                                      default, active)
        self.assertEqual(result, expected)
        result = self.client.get_user_list(2)
        self.assertEqual(len(result), 2)
        for r in result:
            if r['username'] == username:
                self.client.delete_user(r['userId'])

    def test_get_user_list(self):
        """Can we get the user list for an account?"""

        expected = [{u'username': u'revive', u'defaultAccountId': u'2',
                     u'userId': u'1',
                     u'emailAddress': u'sparky@goventurelab.com',
                     u'contactName': u'Administrator',
                     u'active': u'1', u'password': None}]
        result = self.client.get_user_list(2)
        self.assertEqual(len(result), 1)
        self.assertEqual(expected, result)

    def test_modify_user_active(self):
        """Can we modify an existing users active status?"""
        self._add_test_user()
        users = self.client.get_user_list(2)
        for u in users:
            if u['userId'] == self.current_user:
                self.assertEqual(u['active'], '1')
                result = self.client.modify_user_active(self.current_user,
                                                        False)
        expected = {'result': "OK"}
        self.assertEqual(result, expected)
        users = self.client.get_user_list(2)
        for u in users:
            if u['userId'] == self.current_user:
                self.assertEqual(u['active'], '0')
        self._delete_current_user()

#    def test_modify_user_password(self): Must be tested manually since openx
#    wont return the password. Which makes sense.

    def test_modify_user_email(self):
        """Can we modify an existing user email?"""

        self._add_test_user()
        new_email = 'x@y.com'
        users = self.client.get_user_list(2)
        for u in users:
            if u['userId'] == self.current_user:
                self.assertEqual(u['emailAddress'], 'basil@faultytowers.co.uk')
                result = self.client.modify_user_email(self.current_user,
                                                       new_email)
        expected = {'result': "OK"}
        self.assertEqual(result, expected)
        users = self.client.get_user_list(2)
        for u in users:
            if u['userId'] == self.current_user:
                self.assertEqual(u['emailAddress'], new_email)

    def test_modify_user_contact_name(self):
        """Can we modify an existing user contact name?"""
        self._add_test_user()
        new_name = 'John Cleese'
        users = self.client.get_user_list(2)
        for u in users:
            if u['userId'] == self.current_user:
                self.assertEqual(u['contactName'], 'Eric Idle')
                result = self.client.modify_user_contact_name(self.current_user,
                                                              new_name)
        expected = {'result': "OK"}
        self.assertEqual(result, expected)
        users = self.client.get_user_list(2)
        for u in users:
            if u['userId'] == self.current_user:
                self.assertEqual(u['contactName'], new_name)

    def _delete_current_user(self):
        try:
            self.client.delete_user(self.current_user)
        except:
            pass
        result = self.client.get_user_list(2)
        for r in result:
            if r['username'] != 'revive':
                self.client.delete_user(r['userId'])

    def _add_test_user(self):

        contact = 'Eric Idle'
        email = 'basil@faultytowers.co.uk'
        username = 'ericbasil'
        passwd = 'spamspamspam'
        default = 2
        active = True
        self.client.add_user(contact, email, username, passwd, default, active)
        result = self.client.get_user_list(2)
        for r in result:
            if r['emailAddress'] == email:
                self.current_user = r['userId']
