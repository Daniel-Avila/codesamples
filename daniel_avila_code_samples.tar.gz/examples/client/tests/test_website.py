from django import test
import mock
import adcoin_openx.client.website_client as client
import json


@mock.patch('adcoin_openx.client.mixin.OpenXMixIn._send_request')
class TestAPIClientWebsite(test.TestCase):
    def setUp(self):
        self.client = client.WebsiteClient()

    # ==================  website statistics tests below =========================

    def test_get_publisher_stats_by_date(self, mock_send_request):
        """Can we get publisher stats by date?"""
        publisher_id = 1
        start_date = '2014-12-12'
        end_date = '2015-12-23'
        expected = {'result': 'OK'}
        mock_send_request.return_value = json.dumps(expected)
        result = self.client.get_publisher_stats_by_date(publisher_id, start_date,
                                                         end_date)
        self.assertEqual(expected, result)

    def test_get_publisher_stats_by_zone(self, mock_send_request):
        """Can we get publisher stats by zone?"""
        publisher_id = 1
        start_date = '2014-12-12'
        end_date = '2015-12-23'
        expected = {'result': 'OK'}
        mock_send_request.return_value = json.dumps(expected)
        result = self.client.get_publisher_stats_by_zone(publisher_id, start_date,
                                                         end_date)
        self.assertEqual(expected, result)

    def test_get_publisher_stats_by_advertiser(self, mock_send_request):
        """Can we get publisher stats by advertiser?"""
        publisher_id = 1
        start_date = '2014-12-12'
        end_date = '2015-12-23'
        expected = {'result': 'OK'}
        mock_send_request.return_value = json.dumps(expected)
        result = self.client.get_publisher_stats_by_advertiser(publisher_id, start_date,
                                                               end_date)
        self.assertEqual(expected, result)

    def test_get_publisher_stats_by_campaign(self, mock_send_request):
        """Can we get publisher stats by campaign?"""
        publisher_id = 1
        start_date = '2014-12-12'
        end_date = '2015-12-23'
        expected = {'result': 'OK'}
        mock_send_request.return_value = json.dumps(expected)
        result = self.client.get_publisher_stats_by_campaign(publisher_id, start_date,
                                                             end_date)
        self.assertEqual(expected, result)

    def test_get_publisher_stats_by_banner(self, mock_send_request):
        """Can we get publisher stats by banner?"""
        publisher_id = 1
        start_date = '2014-12-12'
        end_date = '2015-12-23'
        expected = {'result': 'OK'}
        mock_send_request.return_value = json.dumps(expected)
        result = self.client.get_publisher_stats_by_banner(publisher_id, start_date,
                                                           end_date)
        self.assertEqual(expected, result)

    # ==================  website management tests below =========================

    def test_add_publisher(self, mock_send_request):
        """Can we add a publisher?"""
        expected = {'result': "OK"}
        mock_send_request.return_value = '{"OK"}'
        agency_id = 12
        publisher_name = 'Turbo Bob publishing'
        contact_name = 'Turbo Bob'
        email = 'basil@faultytowers.co.uk'

        result = self.client.add_publisher(agency_id, publisher_name,
                                           contact_name, email)
        self.assertEqual(result, expected)

    def test_get_publisher(self, mock_send_request):
        """Can we get a publisher"""

        expected = {'result': "OK"}
        mock_send_request.return_value = json.dumps(expected)
        result = self.client.get_publisher(1)
        self.assertEqual(expected, result)

    def test_get_pub_by_agency(self, mock_send_request):
        """Can we get a publisher list for a given agency?"""

        expected = {'result': "OK"}
        mock_send_request.return_value = json.dumps(expected)
        result = self.client.get_pub_agency(1)
        self.assertEqual(expected, result)

    def test_modify_publisher_email_address(self, mock_send_request):
        """Can we modify an existing publishers email address?"""

        mock_send_request.return_value = '{"OK"}'
        result = self.client.modify_publisher_email(1, 'bob@test.com')
        expected = {'result': "OK"}
        self.assertEqual(result, expected)

    def test_modify_publisher_contact_name(self, mock_send_request):
        """Can we modify an existing publishers contact name?"""

        mock_send_request.return_value = '{"OK"}'
        result = self.client.modify_publisher_contact(1, 'bob two')
        expected = {'result': "OK"}
        self.assertEqual(result, expected)

    def test_modify_publisher_name(self, mock_send_request):
        """Can we modify an existing publishers name?"""

        mock_send_request.return_value = '{"OK"}'
        result = self.client.modify_publisher_name(1, 'new agency')
        expected = {'result': "OK"}
        self.assertEqual(result, expected)

    def test_modify_publisher_agency_id(self, mock_send_request):
        """Can we modify an existing publishers agency id?"""

        mock_send_request.return_value = '{"OK"}'
        result = self.client.modify_publisher_agency(1, 2)
        expected = {'result': "OK"}
        self.assertEqual(result, expected)

    def test_delete_publisher(self, mock_send_request):
        """Can we delete a publisher?"""

        expected = json.dumps({'result': "OK"})
        user_id = 1
        mock_send_request.return_value = expected
        result = self.client.delete_publisher(user_id)
        expected = {'result': "OK"}
        self.assertEqual(result, expected)


