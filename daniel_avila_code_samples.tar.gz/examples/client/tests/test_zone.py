from django import test
import mock
import adcoin_openx.client.zone_client as client
from adcoin_openx.exceptions import AdcoinException
import json


@mock.patch('adcoin_openx.client.mixin.OpenXMixIn._send_request')
class TestAPIClientZone(test.TestCase):
    def setUp(self):
        self.client = client.ZoneClient()

    # ===============  zone stats below =======================================

    def test_get_zone_stats_by_banner(self, mock_send_request):
        """Can we get zone stats by banner?"""
        zone_id = 1
        start_date = '2014-12-12'
        end_date = '2015-12-23'
        expected = {'result': 'OK'}
        mock_send_request.return_value = json.dumps(expected)
        result = self.client.get_zone_stats_by_banner(zone_id, start_date,
                                                      end_date)
        self.assertEqual(expected, result)

    def test_get_zone_stats_by_date(self, mock_send_request):
        """Can we get zone stats by date?"""
        zone_id = 1
        start_date = '2014-12-12'
        end_date = '2015-12-23'
        expected = {'result': 'OK'}
        mock_send_request.return_value = json.dumps(expected)
        result = self.client.get_zone_stats_by_date(zone_id, start_date,
                                                    end_date)
        self.assertEqual(expected, result)

    def test_get_zone_stats_by_advertiser(self, mock_send_request):
        """Can we get zone banner stats by date?"""
        zone_id = 1
        start_date = '2014-12-12'
        end_date = '2015-12-23'
        expected = {'result': 'OK'}
        mock_send_request.return_value = json.dumps(expected)
        result = self.client.get_zone_stats_by_advertiser(zone_id, start_date,
                                                          end_date)
        self.assertEqual(expected, result)

    def test_get_zone_stats_by_campaign(self, mock_send_request):
        """Can we get zone stats by campaign?"""
        zone_id = 1
        start_date = '2014-12-12'
        end_date = '2015-12-23'
        expected = {'result': 'OK'}
        mock_send_request.return_value = json.dumps(expected)
        result = self.client.get_zone_stats_by_date(zone_id, start_date,
                                                    end_date)
        self.assertEqual(expected, result)

    # ==================  zone management tests below =========================

    def test_unlink_banner(self, mock_send_request):
        """can we unlink a zone to a banner"""
        zone_id = 1
        banner_id = 1
        mock_send_request.return_value = '{"OK"}'
        result = self.client.unlink_banner(zone_id, banner_id)
        expected = {'result': "OK"}
        self.assertEqual(result, expected)

    def test_link_banner(self, mock_send_request):
        """can we link a zone to a banner"""
        zone_id = 1
        banner_id = 1
        mock_send_request.return_value = '{"OK"}'
        result = self.client.link_banner(zone_id, banner_id)
        expected = {'result': "OK"}
        self.assertEqual(result, expected)

    def test_unlink_campaign(self, mock_send_request):
        """can we unlink a zone to a campaign"""
        zone_id = 1
        campaign_id = 1
        mock_send_request.return_value = '{"OK"}'
        result = self.client.unlink_campaign(zone_id, campaign_id)
        expected = {'result': "OK"}
        self.assertEqual(result, expected)

    def test_link_campaign(self, mock_send_request):
        """can we link a zone to a campaign"""
        zone_id = 1
        campaign_id = 1
        mock_send_request.return_value = '{"OK"}'
        result = self.client.link_campaign(zone_id, campaign_id)
        expected = {'result': "OK"}
        self.assertEqual(result, expected)

    def test_generate_tags_raise_exception_code_type(self, mock_send_request):
        """Can we generate create tags """
        zone_id = 1
        mock_send_request.return_value = '{"OK"}'
        code_type = "xxxadframe"
        block = True
        target = '_top'
        source = 'somerandomtext'
        with_text = True
        block_campaign = True
        char_set = 'ISO-8859-6'
        third_party_track = 'generic'
        comments = True
        mock_send_request.return_value = '{"OK"}'
        with self.assertRaises(AdcoinException):
            self.client.generate_tags(zone_id, code_type, block, target,
                                      source, with_text, block_campaign,
                                      char_set, third_party_track, comments)

    def test_generate_tags_raise_exception_target(self, mock_send_request):
        """Can we generate create tags """
        zone_id = 1
        mock_send_request.return_value = '{"OK"}'
        code_type = "adframe"
        block = True
        target = 'xxx_top'
        source = 'somerandomtext'
        with_text = True
        block_campaign = True
        char_set = 'ISO-8859-6'
        third_party_track = 'generic'
        comments = True
        mock_send_request.return_value = '{"OK"}'
        with self.assertRaises(AdcoinException):
            self.client.generate_tags(zone_id, code_type, block, target,
                                      source, with_text, block_campaign,
                                      char_set, third_party_track, comments)

    def test_generate_tags_raise_exception_char_set(self, mock_send_request):
        """Can we generate create tags """
        zone_id = 1
        mock_send_request.return_value = '{"OK"}'
        code_type = "adframe"
        block = True
        target = '_top'
        source = 'somerandomtext'
        with_text = True
        block_campaign = True
        char_set = 'xxxISO-8859-6'
        third_party_track = 'generic'
        comments = True
        mock_send_request.return_value = '{"OK"}'
        with self.assertRaises(AdcoinException):
            self.client.generate_tags(zone_id, code_type, block, target,
                                      source, with_text, block_campaign,
                                      char_set, third_party_track, comments)

    def test_generate_tags_raise_exception_third_party_track(self,
                                                             mock_send_request):
        """Can we generate create tags """
        zone_id = 1
        mock_send_request.return_value = '{"OK"}'
        code_type = "adframe"
        block = True
        target = '_top'
        source = 'somerandomtext'
        with_text = True
        block_campaign = True
        char_set = 'ISO-8859-6'
        third_party_track = 'xxxgeneric'
        comments = True
        mock_send_request.return_value = '{"OK"}'
        with self.assertRaises(AdcoinException):
            self.client.generate_tags(zone_id, code_type, block,
                                      target, source, with_text,
                                      block_campaign, char_set,
                                      third_party_track, comments)

    def test_generate_tags(self, mock_send_request):
        """Can we generate create tags """
        zone_id = 1
        mock_send_request.return_value = '{"OK"}'
        code_type = "adframe"
        block = 1
        target = '_top'
        source = 'somerandomtext'
        with_text = 1
        block_campaign = 1
        char_set = 'ISO-8859-6'
        third_party_track = 'generic'
        comments = 1
        mock_send_request.return_value = '{"OK"}'
        result = self.client.generate_tags(zone_id, code_type, block, target,
                                           source, with_text, block_campaign,
                                           char_set, third_party_track,
                                           comments)
        expected = {'result': "OK"}
        self.assertEqual(result, expected)

    def test_modify_zone_height(self, mock_send_request):
        """Can we change a zones height?"""
        zone_id = 1
        mock_send_request.return_value = '{"OK"}'
        result = self.client.modify_zone_height(zone_id, 21)
        expected = {'result': "OK"}
        self.assertEqual(result, expected)

    def test_modify_zone_width(self, mock_send_request):
        """Can we change a zones width?"""
        zone_id = 1
        mock_send_request.return_value = '{"OK"}'
        result = self.client.modify_zone_width(zone_id, 1)
        expected = {'result': "OK"}
        self.assertEqual(result, expected)

    def test_modify_zone_type(self, mock_send_request):
        """Can we change a zones type?"""
        zone_id = 1
        mock_send_request.return_value = '{"OK"}'
        result = self.client.modify_zone_type(zone_id, 0)
        expected = {'result': "OK"}
        self.assertEqual(result, expected)

    def test_modify_zone_type_raises_exception(self, mock_send_request):
        """Does an exception get raised if type is other than 0-3"""
        zone_id = 1
        with self.assertRaises(AdcoinException):

            self.client.modify_zone_type(zone_id, 7)

    def test_modify_zone_name(self, mock_send_request):
        """Can we change a zones name?"""
        zone_id = 1
        mock_send_request.return_value = '{"OK"}'
        result = self.client.modify_zone_name(zone_id, 'bubba')
        expected = {'result': 'OK'}
        self.assertEqual(result, expected)

    def test_modify_zone_publisher_id(self, mock_send_request):
        """Can we change a zones publisher ID?"""
        zone_id = 1
        mock_send_request.return_value = '{"OK"}'
        result = self.client.modify_zone_publisher_id(zone_id, "bubba")
        expected = {'result': 'OK'}
        self.assertEqual(result, expected)

    def test_add_zone(self, mock_send_request):
        """Can we add a zone to the OPENX server?"""
        mock_send_request.return_value = '{"OK"}'
        expected = {'result': "OK"}
        campaign_id = 4
        banner_name = "unionjack"
        storage_type = "html"
        image_url = "127.0.0.1/uj.jpg"
        html_template = "<HTML></HTML>"
        width = 8
        height = 9
        weight = 7
        url = "www.gmail.com"
        result = self.client.add_zone(campaign_id, banner_name, storage_type,
                                      image_url, html_template, width, height,
                                      weight, url)
        self.assertEqual(result, expected)

    def test_delete_zone(self, mock_send_request):
        """Can we delete a zone?"""
        expected = {'result': 'OK'}
        mock_send_request.return_value = json.dumps(expected)
        result = self.client.delete_zone(1)
        self.assertEqual(expected, result)

    def test_get_zone(self, mock_send_request):
        """Can we get the information for a zone?"""
        expected = {'result': 'OK'}
        mock_send_request.return_value = json.dumps(expected)
        result = self.client.get_zone(1)
        self.assertEqual(expected, result)

    def test_get_zone_by_publisher(self, mock_send_request):
        """Can we get the zones for a publisher?"""
        expected = {'result': 'OK'}
        mock_send_request.return_value = json.dumps(expected)
        result = self.client.get_zone_by_publisher(1)
        self.assertEqual(expected, result)

    def test_ad_zone_raises_exeption(self, mock_send_request):
        """Does ad_zone raise an exception when storage type is bad"""
        mock_send_request.return_value = '{"OK"}'
        campaign_id = 4
        banner_name = "unionjack"
        storage_type = "rxhtml"
        image_url = "127.0.0.1/uj.jpg"
        html_template = "<HTML></HTML>"
        width = 8
        height = 9
        weight = 7
        url = "12"
        with self.assertRaises(AdcoinException):

            self.client.add_zone(campaign_id, banner_name, storage_type,
                                 image_url, html_template, width, height,
                                 weight, url)
