from django import test
import mock
import adcoin_openx.client.banner_client as client
import json
from adcoin_openx.exceptions import AdcoinException


@mock.patch('adcoin_openx.client.mixin.OpenXMixIn._send_request')
class TestAPIClientBanner(test.TestCase):

    def setUp(self):

        self.client = client.BannerClient()
    # ===============  banner statistics tests below ============================

    def test_get_banner_stats_by_date(self, mock_send_request):
        """Can we get the banner stats grouped by day?"""

        banner_id = 1
        start_date = '2014-12-12'
        end_date = '2015-12-23'
        expected = {'result': 'OK'}
        mock_send_request.return_value = json.dumps(expected)
        result = self.client.get_banner_stats_by_date(banner_id, start_date, end_date)
        self.assertEqual(expected, result)

    def test_get_banner_stats_by_pub(self, mock_send_request):
        """Can we get the banner stats by publisher?"""

        banner_id = 1
        start_date = '2014-12-12'
        end_date = '2015-12-23'
        expected = {'result': 'OK'}
        mock_send_request.return_value = json.dumps(expected)
        result = self.client.get_banner_stats_by_pub(banner_id, start_date, end_date)
        self.assertEqual(expected, result)

    def test_get_banner_stats_by_zone(self, mock_send_request):
        """Can we get the banner stats by zone?"""

        banner_id = 1
        start_date = '2014-12-12'
        end_date = '2015-12-23'
        expected = {'result': 'OK'}
        mock_send_request.return_value = json.dumps(expected)
        result = self.client.get_banner_stats_by_zone(banner_id, start_date, end_date)
        self.assertEqual(expected, result)

    # ==================  banner management tests below =========================

    def test_get_banner(self, mock_send_request):
        """Can we get the banner data?"""
        expected = {'result': "OK"}
        mock_send_request.return_value = json.dumps(expected)
        result = self.client.get_banner(1)
        self.assertEqual(expected, result)

    def test_delete_banner(self, mock_send_request):
        """Can we delete the banner?"""
        expected = {'result': "OK"}
        mock_send_request.return_value = json.dumps(expected)
        result = self.client.delete_banner(1)
        self.assertEqual(expected, result)

    def test_add_banner(self, mock_send_request):
        """Can we add a banner?"""
        mock_send_request.return_value = '{"OK"}'

        expected = {'result': "OK"}
        campaign = 3
        banner = 'Test Banner'
        storage = 'html'
        image = 'http://www.example.com/img.png'
        html = 'Test Template html'
        width = 468
        height = 60
        weight = 1
        url = 'http://www.example.com'
        result = self.client.add_banner(campaign, banner, storage, image,
                                        html, width, height, weight, url)
        self.assertEqual(result, expected)

    def test_add_banner_exception(self, mock_send_request):
        """Does add_banner raise an exception when storage type is bad"""
        mock_send_request.return_value = '{"OK"}'

        campaign = 3
        banner = 'Test Banner'
        storage = 'NOThtml'
        image = 'http://www.example.com/img.png'
        html = 'Test Template html'
        width = 468
        height = 60
        weight = 1
        url = 'http://www.example.com'
        with self.assertRaises(AdcoinException):

            self.client.add_banner(campaign, banner, storage, image, html,
                                   width, height, weight, url)

    def test_modify_banner_campaign(self, mock_send_request):
        """Can we modify a banner campaign ID?"""

        mock_send_request.return_value = '{"OK"}'
        result = self.client.modify_banner_campaign(4, 8)
        expected = {'result': "OK"}
        self.assertEqual(result, expected)

    def test_modify_banner_name(self, mock_send_request):
        """Can we modify a banner name?"""

        mock_send_request.return_value = '{"OK"}'
        result = self.client.modify_banner_name(4, 'Another banner name')
        expected = {'result': "OK"}
        self.assertEqual(result, expected)

    def test_modify_banner_html(self, mock_send_request):
        """Can we modify a banner html?"""

        mock_send_request.return_value = '{"OK"}'
        result = self.client.modify_banner_html(4, 'Some HTML here')
        expected = {'result': "OK"}
        self.assertEqual(result, expected)

    def test_modify_banner_height(self, mock_send_request):
        """Can we modify a banner height?"""

        mock_send_request.return_value = '{"OK"}'
        result = self.client.modify_banner_height(4, 200)
        expected = {'result': "OK"}
        self.assertEqual(result, expected)

    def test_modify_banner_weight(self, mock_send_request):
        """Can we modify a banner weight?"""

        mock_send_request.return_value = '{"OK"}'
        result = self.client.modify_banner_weight(4, 40)
        expected = {'result': "OK"}
        self.assertEqual(result, expected)

    def test_modify_banner_width(self, mock_send_request):
        """Can we modify a banner width?"""

        mock_send_request.return_value = '{"OK"}'
        result = self.client.modify_banner_width(4, 100)
        expected = {'result': "OK"}
        self.assertEqual(result, expected)

    def test_modify_banner_url(self, mock_send_request):
        """Can we modify a banner url?"""

        mock_send_request.return_value = '{"OK"}'
        result = self.client.modify_banner_url(4, 'Another URL')
        expected = {'result': "OK"}
        self.assertEqual(result, expected)

    def test_modify_banner_image(self, mock_send_request):
        """Can we modify a banner image url?"""

        mock_send_request.return_value = '{"OK"}'
        result = self.client.modify_banner_image(4, 'Another Image URL')
        expected = {'result': "OK"}
        self.assertEqual(result, expected)

    def test_modify_banner_storage(self, mock_send_request):
        """Can we modify a banner storage type?"""

        mock_send_request.return_value = '{"OK"}'
        result = self.client.modify_banner_storage(4, 'sql')
        expected = {'result': "OK"}
        self.assertEqual(result, expected)

    def test_modify_banner_storage_exception(self, mock_send_request):
        """Does modify_banner_storage raise an exception when
        storage type is bad"""

        mock_send_request.return_value = '{"OK"}'
        storage = 'NOThtml'
        with self.assertRaises(AdcoinException):

            self.client.modify_banner_storage(4, storage)

    def test_banner_campaign(self, mock_send_request):
        """Can we get banners from a specific campaign?"""

        expected = {'result': "OK"}
        mock_send_request.return_value = json.dumps(expected)
        result = self.client.get_banner_campaign(1)
        self.assertEqual(expected, result)

    def test_banner_target(self, mock_send_request):
        """Can we get delivery limitations for a specific banner?"""

        expected = {'result': "OK"}
        mock_send_request.return_value = json.dumps(expected)
        result = self.client.get_banner_target(1)
        self.assertEqual(expected, result)

    def test_add_banner_target(self, mock_send_request):
        """Can we set the delivery limitations for a specific banner?"""

        expected = {'result': "OK"}
        logical = 'and'
        limit = 'Some delivery limitations'
        comp = '=='
        data = 'Some data string'

        mock_send_request.return_value = '{"OK"}'

        result = self.client.add_banner_target(4, logical, limit, comp, data)
        self.assertEqual(expected, result)

    def test_add_banner_target_logical_expection(self, mock_send_request):
        """Does add_banner_target raise an exception when logical type
        is bad"""

        expected = {'result': "OK"}
        logical = 'not and'
        limit = 'Some delivery limitations'
        comp = '=='
        data = 'Some data string'

        mock_send_request.return_value = json.dumps(expected)
        with self.assertRaises(AdcoinException):

            self.client.add_banner_target(4, logical, limit, comp, data)

    def test_add_banner_target_comp_expection(self, mock_send_request):
        """Does add_banner_target raise an exception when comp type is bad"""

        expected = {'result': "OK"}
        logical = 'and'
        limit = 'Some delivery limitations'
        comp = 'not =='
        data = 'Some data string'

        mock_send_request.return_value = json.dumps(expected)
        with self.assertRaises(AdcoinException):

            self.client.add_banner_target(4, logical, limit, comp, data)
