"""
UserClient

This is the sub client which defines all the user managment functionality
"""

from mixin import OpenXMixIn
from django.conf import settings
import json


class UserClient(OpenXMixIn):

    def add_user(self, contact, email, username, passwd, default_id, active):
        """Add a new user to the OPENX server

        Args:
            contact (str): The contact name for the user being created
            email (str): Contact email for the user
            username (str): a login name for the user
            passwd (str): the unencrypted password
            default_id (int): sets the default account ID for the user
            active (bool): Flags if the user is active or inactive.

        Returns:
            dict of the result
        """
        payload = {'contactName': contact,
                   'emailAddress': email,
                   'defaultAccountId': default_id,
                   'username': username,
                   'password': passwd,
                   'active': active}

        result = self._post(settings.OPENX_NEW_USER, payload)
        if result == '{"OK"}':  # The rest api does not return valid json
            return {'result': 'OK'}

    def get_user(self, userid):
        """Return a user account by it's OpenX UserID

        Args:
            userid (int): An OpenX user id

        Returns:
            dictionary of result data
        """
        return json.loads(self._get(settings.OPENX_USR, userid))

    def delete_user(self, user_id):
        """Delete an existing user from openx

        Args:
            user_id (int) The id of the user you wish to delete

        Returns:
            dictionary of result from openx server
        """
        result = self._delete(settings.OPENX_USR, user_id)
        if result == '{"OK"}':  # The rest api does not return valid json
            return {'result': 'OK'}

    def modify_user_active(self, user_id, active):
        """Set the users active status to the value in active

        Args:
            user_id (int): The user being changed
            active (bool): The new active status
        Returns:
            Dictionary of resposne from openx
        """
        payload = {'active': 1 if active else 0}
        endpoint = '%s/%s' % (settings.OPENX_USR, user_id)
        result = self._post(endpoint, payload)
        if result == '{"OK"}':  # The rest api does not return valid json
            return {'result': 'OK'}

    def modify_user_contact_name(self, user_id, contact_name):
        """Set the users contact_name

        Args:
            user_id (int): The user being changed
            contact_name (str): The users new contact name

        Returns:
            Dictionary of resposne from openx
        """
        payload = {'contactName': contact_name}
        endpoint = '%s/%s' % (settings.OPENX_USR, user_id)
        result = self._post(endpoint, payload)
        if result == '{"OK"}':  # The rest api does not return valid json
            return {'result': 'OK'}

    def modify_user_email(self, user_id, email):
        """Set the users email address

        Args:
            user_id (int): The user being changed
            email (str): The users new email address

        Returns:
            Dictionary of resposne from openx
        """
        payload = {'emailAddress': email}
        endpoint = '%s/%s' % (settings.OPENX_USR, user_id)
        result = self._post(endpoint, payload)
        if result == '{"OK"}':  # The rest api does not return valid json
            return {'result': 'OK'}

    def modify_user_password(self, user_id, password):
        """Set the users password

        Args:
            user_id (int): The user being changed
            password (str): The users new password

        Returns:
            Dictionary of resposne from openx
        """
        payload = {'password': password}
        endpoint = '%s/%s' % (settings.OPENX_USR, user_id)
        result = self._post(endpoint, payload)
        if result == '{"OK"}':  # The rest api does not return valid json
            return {'result': 'OK'}

    def get_user_list(self, account_id):
        """Return a list of user accounts assigned to a given account

            Args:
                account_id (int): The account identifier

            Returns:
                dictionary of result data
        """
        return json.loads(self._get(settings.OPENX_GET_USR_LIST,
                                    account_id))
