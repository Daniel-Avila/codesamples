"""
CampaignClient

This is the sub client which defines all the campaign managment functionality
"""

from mixin import OpenXMixIn
from django.conf import settings
import json


class CampaignClient(OpenXMixIn):

    # ==================== campaign stats below ==============================

    def get_campaign_stats_by_date(self, campaign_id, start_date, end_date):
        """Get campaign stats by day

        Args:
            campaign_id (int): id for the campaign we're interested in
            start_date (str): start date must be in yyyy-mm-dd format
            end_date (str): end date must be in yyyy-mm-dd format"""
        payload = {}
        endpoint = '%s/%s/statistics/daily/%s/%s' % (settings.OPENX_CAM,
                                                     campaign_id, start_date,
                                                     end_date)
        return json.loads(self._get(endpoint, payload))

    def get_campaign_conversion_stats(self, campaign_id, start_date, end_date):
        """Get campaign conversion stats

        Args:
            campaign_id (int): id for the campaign we're interested in
            start_date (str): start date must be in yyyy-mm-dd format
            end_date (str): end date must be in yyyy-mm-dd format"""
        payload = {}
        endpoint = '%s/%s/statistics/conversion/%s/%s' % (settings.OPENX_CAM,
                                                          campaign_id,
                                                          start_date, end_date)
        return json.loads(self._get(endpoint, payload))

    def get_campaign_stats_by_zone(self, campaign_id, start_date, end_date):
        """Get campaign stats by zone

        Args:
            campaign_id (int): id for the campaign we're interested in
            start_date (str): start date must be in yyyy-mm-dd format
            end_date (str): end date must be in yyyy-mm-dd format"""
        payload = {}
        endpoint = '%s/%s/statistics/zone/%s/%s' % (settings.OPENX_CAM,
                                                    campaign_id, start_date,
                                                    end_date)
        return json.loads(self._get(endpoint, payload))

    def get_campaign_stats_by_publisher(self, campaign_id, start_date,
                                        end_date):
        """Get campaign stats by publisher

        Args:
            campaign_id (int): id for the campaign we're interested in
            start_date (str): start date must be in yyyy-mm-dd format
            end_date (str): end date must be in yyyy-mm-dd format"""
        payload = {}
        endpoint = '%s/%s/statistics/publisher/%s/%s' % (settings.OPENX_CAM,
                                                         campaign_id,
                                                         start_date, end_date)
        return json.loads(self._get(endpoint, payload))

    def get_campaign_stats_by_banner(self, campaign_id, start_date, end_date):
        """Get campaign stats by day

        Args:
            campaign_id (int): id for the campaign we're interested in
            start_date (str): start date must be in yyyy-mm-dd format
            end_date (str): end date must be in yyyy-mm-dd format"""
        payload = {}
        endpoint = '%s/%s/statistics/banner/%s/%s' % (settings.OPENX_CAM,
                                                      campaign_id, start_date,
                                                      end_date)
        return json.loads(self._get(endpoint, payload))

    # ==================== campaign management below =========================

    def add_campaign(self, advertiser_id, campaign_name, start_date, end_date,
                     impressions, clicks, priority, weight):
        """Add a new campaign to the OPENX server

        Args:
            advertiser_id(int):  id of the advertiser
            campaign_name(str):  name of the campaign
            start_date(str):  start date(yyyy-mm-dd)
            end_date(str):  end date(yyyy-mm-dd)
            impressions(int):  booked impressions
            clicks(int):    booked clicks
            priority(int):campaign priority(0-2)0 normal,1 contract,2 exclusive
            weight(int):  campaign weight

        Returns:
            dict of the result
        """
        payload = {'advertiser_id': advertiser_id,
                   'campaign_name': campaign_name,
                   'start_date': start_date,
                   'end_date': end_date,
                   'impressions': impressions,
                   'clicks':  clicks,
                   'priority': priority,
                   'weight': weight}
        result = self._post(settings.OPENX_NEW_CAM, payload)
        if result == '{"OK"}':  # The rest api does not return valid json
            return {'result': 'OK'}

    def modify_campaign_advertiser_id(self, campaign_id, advertiser_id):
        """Set the advertisers id in a campaign

        Args:
            advertiser_id (int): The advertiser being changed
            campaign_id (int): The campaign we're working on
        Returns:
            Dictionary of resposne from openx
        """
        payload = {'advertiserId': advertiser_id}
        endpoint = '%s/%s' % (settings.OPENX_CAM, campaign_id)
        result = self._post(endpoint, payload)
        if result == '{"OK"}':  # The rest api does not return valid json
            return {'result': 'OK'}

    def modify_campaign_name(self, campaign_id, campaign_name):
        """Set the campaign name

        Args:
            campaign_id (int): The campaign we're working on
            campaign_name (str):  campaign name
        Returns:
            Dictionary of resposne from openx
        """
        payload = {'campaignName': campaign_name}
        endpoint = '%s/%s' % (settings.OPENX_CAM, campaign_id)
        result = self._post(endpoint, payload)
        if result == '{"OK"}':  # The rest api does not return valid json
            return {'result': 'OK'}

    def modify_campaign_start_date(self, campaign_id, start_date):
        """Set the campaign start date

        Args:
            campaign_id (int): The campaign we're working on
            start_date(str):  The campaign start date
        Returns:
            Dictionary of resposne from openx
        """
        payload = {'startDate': start_date}
        endpoint = '%s/%s' % (settings.OPENX_CAM, campaign_id)
        result = self._post(endpoint, payload)
        if result == '{"OK"}':  # The rest api does not return valid json
            return {'result': 'OK'}

    def modify_campaign_end_date(self, campaign_id, end_date):
        """Set the campaign end date

        Args:
            campaign_id (int): The campaign we're working on
            end_date(str):  the campaign end date
        Returns:
            Dictionary of resposne from openx
        """
        payload = {'endDate': end_date}
        endpoint = '%s/%s' % (settings.OPENX_CAM, campaign_id)
        result = self._post(endpoint, payload)
        if result == '{"OK"}':  # The rest api does not return valid json
            return {'result': 'OK'}

    def modify_campaign_impressions(self, campaign_id, impressions):
        """Set the impressions

        Args:
            campaign_id (int): The campaign we're working on
            impressions(int):  The number of impressions
        Returns:
            Dictionary of resposne from openx
        """
        payload = {'impressions': impressions}
        endpoint = '%s/%s' % (settings.OPENX_CAM, campaign_id)
        result = self._post(endpoint, payload)
        if result == '{"OK"}':  # The rest api does not return valid json
            return {'result': 'OK'}

    def modify_campaign_clicks(self, campaign_id, clicks):
        """Set the clicks

        Args:
            campaign_id (int): The campaign we're working on
            clicks(int):  clicks
        Returns:
            Dictionary of resposne from openx
        """
        payload = {'clicks': clicks}
        endpoint = '%s/%s' % (settings.OPENX_CAM, campaign_id)
        result = self._post(endpoint, payload)
        if result == '{"OK"}':  # The rest api does not return valid json
            return {'result': 'OK'}

    def modify_campaign_priority(self, campaign_id, priority):
        """Set the campaign priority

        Args:
            campaign_id (int): The campaign we're working on
            priority (int):  campaign priority a number from 0 to two
        Returns:
            Dictionary of resposne from openx
        """
        payload = {'priority': priority}
        endpoint = '%s/%s' % (settings.OPENX_CAM, campaign_id)
        result = self._post(endpoint, payload)
        if result == '{"OK"}':  # The rest api does not return valid json
            return {'result': 'OK'}

    def modify_campaign_weight(self, campaign_id, weight):
        """Set the campaign weight

        Args:
            campaign_id (int): The campaign we're working on
            weight (int):  the campaigns weight
        Returns:
            Dictionary of resposne from openx
        """
        payload = {'weight': weight}
        endpoint = '%s/%s' % (settings.OPENX_CAM, campaign_id)
        result = self._post(endpoint, payload)
        if result == '{"OK"}':  # The rest api does not return valid json
            return {'result': 'OK'}

    def get_campaign_list_by_advertiserid(self, advertiser_id):
        """Get a list of all of a given advertisers campaigns

        Args:
            advertiser_id(int):  the advertiser we're dealing with
        Returns:
            Dictionary of resposne from openx
        """
        return json.loads(self._get(settings.OPENX_CAM, advertiser_id))

    def get_campaign(self, campaign_id):
        """Get an existing campaign

        Args:
            campaign_id(int):  the campaign we're dealing with
        Returns:
            Dictionary of resposne from openx
        """
        return json.loads(self._get(settings.OPENX_CAM, campaign_id))

    def delete_campaign(self, campaign_id):
        """delete a campaign

        Args:
            campaign_id (int): The campaign we're working on
        Returns:
            Dictionary of resposne from openx
        """
        payload = ''
        endpoint = '%s/%s' % (settings.OPENX_CAM, campaign_id)
        result = self._delete(endpoint, payload)
        if result == '{"OK"}':  # The rest api does not return valid json
            return {'result': 'OK'}
