from django.test import TestCase
from django.db import IntegrityError
from adcoin_user.models import AdcoinUserManager, AdcoinUser


class TestCustomUserManager(TestCase):

    def setUp(self):
        self.aum = AdcoinUserManager()

    def test_user_email_unique(self):
        """If we create a user as an advertiser does it get added to the advertiser group?"""

        full_name = "bubba"
        email = 'a@b.com'
        account_type = 'advertiser'
        password = 'pass'
        self.aum.create_user(full_name, email, account_type, password=password)
        with self.assertRaises(IntegrityError):
            self.aum.create_user(full_name, email, account_type, password=password)


    def test_create_user(self):
        """Can we create a user at all?"""

        full_name = "bubba"
        email = 'a@b.com'
        account_type = 'publisher'
        password = 'pass'
        result = self.aum.create_user(full_name, email, account_type, password=password)
        self.assertTrue(isinstance(result, AdcoinUser))

    def test_user_group_publisher(self):
        """If we create a user as a publisher does it get added to the publisher group?"""

        full_name = "bubba"
        email = 'a@b.com'
        account_type = 'publisher'
        password = 'pass'
        result = self.aum.create_user(full_name, email, account_type, password=password)
        group = result.groups.all()[0]
        self.assertEqual(group.name, account_type)



    def test_user_group_advertiser(self):
        """If we create a user as an advertiser does it get added to the advertiser group?"""

        full_name = "bubba"
        email = 'a@b.com'
        account_type = 'advertiser'
        password = 'pass'
        result = self.aum.create_user(full_name, email, account_type, password=password)
        group = result.groups.all()[0]
        self.assertEqual(group.name, account_type)



