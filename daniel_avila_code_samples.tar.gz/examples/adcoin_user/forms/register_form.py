from django.forms import ModelForm
import adcoin_user.models as register


class RegisterForm(ModelForm):
    class Meta:
        model = register
        fields = ['name', 'email', 'acount_type', 'password']
