from django import forms
from django.http import HttpResponse


class RecoveryForm(forms.Form):
    email = forms.CharField()
    message = forms.CharField(widget=forms.Textarea)

    def send_email(self):
        # send email using the self.cleaned_data dictionary

        pass