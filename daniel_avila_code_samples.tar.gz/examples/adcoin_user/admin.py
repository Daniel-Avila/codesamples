from django import forms
from django.contrib import admin
from django.contrib.auth.admin import UserAdmin
from models import AdcoinUser


class UserCreationForm(forms.ModelForm):

    class Meta:
        model = AdcoinUser
        fields = ('email', 'account_type')


class AdcoinUserAdmin(UserAdmin):
    fieldsets = (['Username and Password',
                  {'fields': ('email', 'password')}],
                 ['Adcoin Type', {'fields': ('account_type',)}])
    add_fieldsets = (
        ('Username & Password', {
            'classes': ('wide',),
            'fields': ('email', 'password', 'account_type'),
        }),)
    list_display = ['email', 'account_type']
    ordering = ['email', 'account_type']
    add_form = UserCreationForm


# Register your models here.
admin.site.register(AdcoinUser, AdcoinUserAdmin)
