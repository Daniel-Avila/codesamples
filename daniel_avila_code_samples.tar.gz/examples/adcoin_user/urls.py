from django.conf.urls import patterns, url
from views.login_view import LoginView
from views.register_view import RegisterView


urlpatterns = patterns('',
                       url('^$', LoginView.as_view()),
                       url('^register', RegisterView.as_view())

                       )
