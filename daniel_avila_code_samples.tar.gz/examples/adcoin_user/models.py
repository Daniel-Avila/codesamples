"""
Since we need to add some members to a user then we need a custom
user model.
"""
from django.contrib.auth.models import (AbstractBaseUser, BaseUserManager,
                                        PermissionsMixin, Group)
from django.db import models


def get_group(account_type):
    group, _ = Group.objects.get_or_create(name=account_type)
    return group


class AdcoinUserManager(BaseUserManager):

    def create_user(self, full_name, email, account_type, password=None):
        """
        Args:
            full_name (str): users full name
            email (str): A valid email used as a unique identifier
            account_type (str): one of the valid account types defined
                in settings.ACCOUNT_TYPES
            password (str): the password for the account

        Returns:
            user (AdcoinUser): The user just created
        """
        if not password:
            raise ValueError('Password must be set')
        user = AdcoinUser(full_name=full_name, email=self.normalize_email(email),
                          account_type=account_type)

        user.save()
        group = get_group(account_type)
        group.save()
        user.groups.add(group)
        user.set_password(password)
        user.save()
        return user

    def create_superuser(self, email, password):
        """
        Args:
            email (str): A valid email used as a unique identifier
            account_type (str): one of the valid account types defined
                in settings.ACCOUNT_TYPES
            password (str): the password for the account

        Returns:
            superuser (AdcoinUser): The user just created
        """
        email = self.normalize_email(email)
        u = self.model(email=email, is_staff=True, is_active=True,
                       is_superuser=True)
        u.is_admin = True
        u.set_password(password)
        u.save(using=self._db)
        return u


class AdcoinUser(AbstractBaseUser, PermissionsMixin):

    full_name = models.CharField(default="", max_length=256)
    email = models.EmailField(blank=False, unique=True)
    account_type = models.CharField(max_length=15)

    USERNAME_FIELD = 'email'

    # Required by Django
    is_admin = models.BooleanField(default=False)
    is_staff = models.BooleanField(default=False)
    is_active = models.BooleanField(default=True)
    objects = AdcoinUserManager()
    # End required by Django

    class Meta:
        verbose_name = 'Adcoin User'
        verbose_name_plural = 'Adcoin Users'

    def get_short_name(self):
        return self.email

    @property
    def is_publisher(self):
        pub_group = Group.objects.get(name='publisher')
        if pub_group in self.groups.all():
            return True
        return False

    @property
    def is_advertiser(self):
        print self.groups.all()
        adv_group = Group.objects.get(name='advertiser')
        if adv_group in self.groups.all():
            return True
        return False
