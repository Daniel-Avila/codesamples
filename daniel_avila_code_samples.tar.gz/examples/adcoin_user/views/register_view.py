from django.shortcuts import render
from django.contrib.auth import get_user_model
from django.views.generic import View
from django.http import HttpResponse


class RegisterView(View):

    def get(self, request):
        return render(request, 'adcoin_user/register.html', {})

    def post(self, request):
        full_name = request.POST['name']
        email = request.POST['email']
        account_type = request.POST['account_type']
        password = request.POST['password']

        user_model = get_user_model()
        try:
            user_model.objects.get(email=email)
        except:
            user_model.objects.create_user(full_name, email, account_type,
                                           password)
            return HttpResponse("Success")
        return HttpResponse("Nope")
