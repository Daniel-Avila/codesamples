from django.shortcuts import render
from django.views.generic import View
from django.contrib.auth import authenticate, login
from django.http import HttpResponse

class LoginView(View):

    def get(self, request):
        return render(request, 'adcoin_user/login.html', {})

    def post(self, request):
        email = request.POST['email']
        password = request.POST['password']

        user = authenticate(email=email, password=password)
        if user is not None:
            if user.is_active:
                login(request, user)
                msg = "logged in %s" % user.email
                return HttpResponse(msg)
        return render(request, 'adcoin_user/login.html', {})
