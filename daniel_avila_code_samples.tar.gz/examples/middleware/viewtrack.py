import time

from boomers.apps.config.models import ConfigEntry, ConfigNamespace


class CookieViewTracker(object):

    def process_response(self, request, response):
        """just set the views in a cookie"""

        total_views = request.session.get('numvc', 1)  # Comes from views.MeteredView.
        response.set_cookie('numvc', value=total_views, max_age=31536000)

        first_visit = request.COOKIES.get('numfv', None)
        if first_visit is None:
            first_visit = int(time.time())
        response.set_cookie('numfv', value=first_visit)

        namespace = ConfigNamespace.objects.filter(name='metering')
        s_delta = ConfigEntry.objects.get(namespace=namespace, key='sessiondelta_seconds')
        session_delta = int(s_delta.value)

        total_sessions = request.COOKIES.get('numsc', None)

        # If we don't have a numsessions cookie then this is the first
        if total_sessions is None:  # It is the first session so we just need to record it
            total_sessions = 1
        # It might be a second session so sort this out.
        else:
            # A lastView should exist since this is not our first session. Default to 0 just in case.
            last_view = request.session.get('lastView', 0)
            real_delta = int(time.time()) - last_view

            # If the real difference between now and the last view is larger than
            # The configured session limit increment the session
            if real_delta > session_delta:
                total_sessions = int(total_sessions) + 1

        request.session['lastView'] = int(time.time())  # Reset our last view to now.
        response.set_cookie('numsc', value=total_sessions)

        return response
