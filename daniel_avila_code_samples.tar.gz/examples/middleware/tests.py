
from django.test import TestCase
from model_mommy import mommy

from boomers.apps.config.models import ConfigEntry, ConfigNamespace


class TestCookieViewTracker(TestCase):

    def setUp(self):
        ns = mommy.make(ConfigNamespace, name='metering')
        ns.save()
        ce = mommy.make(ConfigEntry, namespace=ns, key='sessiondelta_seconds', value='3600')
        ce.save()

    def test_process_response(self):

        expected_key = "numvc"
        expected_value = "Set-Cookie: numvc=1;"
        response = self.client.get('article/')

        msg = "Expected %s in response.cookies.keys" % expected_key
        self.assertTrue(expected_key in response.cookies.keys(), msg)

        msg = "Expected %s got %s" % (expected_value, response.cookies[expected_key])
        self.assertTrue(expected_value in str(response.cookies[expected_key]), msg)

    def test_process_response_total_sessions(self):
        """Do we set a total sessions cookie?"""

        response = self.client.get('article/')
        expected_key = 'numsc'
        results = response.cookies.keys()

        msg = "Expected %s in response.cookies.keys %s" % (expected_key, results)
        self.assertTrue(expected_key in response.cookies.keys(), msg)

    def test_process_response_first_visted(self):
        """Do we set a first visited cookie if none exists?"""

        response = self.client.get('article/')
        expected_key = "numfv"
        results = response.cookies.keys()

        msg = "Expected %s in response.cookies.keys %s" % (expected_key, results)
        self.assertTrue(expected_key in response.cookies.keys(), msg)

    def test_process_response_second_visit_inside_delta(self):
        """Do we get 1 for the numsc if we visist an article twice inside of the sessiondelta?"""

        response = self.client.get('article/')
        response = self.client.get('article/')

        numsc = response.cookies.get('numsc').value

        msg = "Expected a session count of 1. Got %s." % numsc
        self.assertEqual(numsc, '1', msg)

    def test_process_response_second_visit_outside_delta(self):
        """Do we get 2 for the numsc if we visit an article twice outside of the sessiondelta?"""

        # Set the delta to a negative value so that even if 0 seconds pass we should have two sessions.
        namespace = ConfigNamespace.objects.filter(name='metering')
        s_delta = ConfigEntry.objects.get(namespace=namespace, key='sessiondelta_seconds')
        s_delta.value = -1
        s_delta.save()

        response = self.client.get('article/')
        response = self.client.get('article/')

        numsc = response.cookies.get('numsc').value

        msg = "Expected a session count of 2. Got %s." % numsc
        self.assertEqual(numsc, '2', msg)
