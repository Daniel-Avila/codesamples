class LastVisitedMiddleware(object):

    def process_request(self, request):

        IGNORE = ['/login/facebook',
                  '/complete/facebook',
                  '/api',
                  '/googleanalytics/most-popular/',
                  '/favicon.ico']

        path = request.get_full_path()

        for ignore in IGNORE:
            if path.startswith(ignore):
                return

        try:
            request.session['last_visited'] = request.session.get(
                'currently_visiting', '/')
            request.session['currently_visiting'] = request.get_full_path()
        except:
            pass
