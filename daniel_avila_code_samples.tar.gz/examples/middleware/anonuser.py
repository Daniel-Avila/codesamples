from boomers.apps.users.models import NowUAnonymousUser

class AnonymousUserMiddleware(object):

    def process_request(self, request):
        if request.user.is_anonymous():
            request.user = NowUAnonymousUser(
                request.COOKIES.get('numg', None))
